
-- Function: auto-attach the "depot-commun" aggregator to a merchant
CREATE OR REPLACE FUNCTION public.attach_depot_commun()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_provider_id uuid;
BEGIN
  SELECT id INTO v_provider_id FROM public.providers WHERE slug = 'depot-commun' LIMIT 1;
  IF v_provider_id IS NULL THEN
    RETURN NEW;
  END IF;

  INSERT INTO public.merchant_provider_connections
    (merchant_id, provider_id, environment, status, credentials, credentials_masked, last_test_status, last_test_message)
  VALUES
    (NEW.id, v_provider_id, 'live', 'active', '{}'::jsonb, '{}'::jsonb, 'ok', 'Compte agrégé ZbossPay activé automatiquement')
  ON CONFLICT DO NOTHING;

  RETURN NEW;
END;
$$;

-- Trigger on profiles insert
DROP TRIGGER IF EXISTS attach_depot_commun_on_profile ON public.profiles;
CREATE TRIGGER attach_depot_commun_on_profile
AFTER INSERT ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.attach_depot_commun();

-- Backfill: attach to all existing merchants
INSERT INTO public.merchant_provider_connections
  (merchant_id, provider_id, environment, status, credentials, credentials_masked, last_test_status, last_test_message)
SELECT p.id, pr.id, 'live', 'active', '{}'::jsonb, '{}'::jsonb, 'ok', 'Compte agrégé ZbossPay activé automatiquement'
FROM public.profiles p
CROSS JOIN public.providers pr
WHERE pr.slug = 'depot-commun'
  AND NOT EXISTS (
    SELECT 1 FROM public.merchant_provider_connections c
    WHERE c.merchant_id = p.id AND c.provider_id = pr.id
  );
