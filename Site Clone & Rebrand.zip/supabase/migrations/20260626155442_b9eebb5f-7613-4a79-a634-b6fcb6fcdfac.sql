
-- Defense-in-depth: FORCE RLS so even table-owner sessions respect policies
ALTER TABLE public.transactions FORCE ROW LEVEL SECURITY;
ALTER TABLE public.profiles FORCE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_provider_connections FORCE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles FORCE ROW LEVEL SECURITY;

-- Admins can view all transactions (defense-in-depth; admin server fns also use service role)
DROP POLICY IF EXISTS "Admins view all transactions" ON public.transactions;
CREATE POLICY "Admins view all transactions"
  ON public.transactions FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Admins can view all merchant connections
DROP POLICY IF EXISTS "Admins view all merchant connections" ON public.merchant_provider_connections;
CREATE POLICY "Admins view all merchant connections"
  ON public.merchant_provider_connections FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Admins can view all roles
DROP POLICY IF EXISTS "Admins view all roles" ON public.user_roles;
CREATE POLICY "Admins view all roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Block self-mutation of sensitive Stripe/billing columns on profiles
-- (only service_role via server functions may change these — FORCE RLS makes this effective)
CREATE OR REPLACE FUNCTION public.guard_profile_sensitive_columns()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.id IS DISTINCT FROM OLD.id
     OR NEW.email IS DISTINCT FROM OLD.email
     OR NEW.stripe_account_id IS DISTINCT FROM OLD.stripe_account_id
     OR NEW.stripe_charges_enabled IS DISTINCT FROM OLD.stripe_charges_enabled
     OR NEW.stripe_payouts_enabled IS DISTINCT FROM OLD.stripe_payouts_enabled
     OR NEW.stripe_details_submitted IS DISTINCT FROM OLD.stripe_details_submitted
  THEN
    RAISE EXCEPTION 'Modification interdite des colonnes sensibles du profil';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS guard_profile_sensitive_columns_trg ON public.profiles;
CREATE TRIGGER guard_profile_sensitive_columns_trg
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  WHEN (current_setting('role', true) NOT IN ('service_role','postgres','supabase_admin'))
  EXECUTE FUNCTION public.guard_profile_sensitive_columns();
