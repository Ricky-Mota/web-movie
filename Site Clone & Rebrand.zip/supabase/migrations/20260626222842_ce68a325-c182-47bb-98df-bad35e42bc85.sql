DO $$ BEGIN
  CREATE TYPE public.kyc_status AS ENUM ('pending', 'approved', 'rejected');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE public.merchant_kyc (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  entity_type text NOT NULL CHECK (entity_type IN ('individual','company')),
  legal_name text NOT NULL,
  rccm_number text NOT NULL,
  nif_number text NOT NULL,
  id_number text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  country text NOT NULL DEFAULT 'CD',
  rccm_doc_url text,
  nif_doc_url text,
  id_doc_url text,
  selfie_url text,
  status public.kyc_status NOT NULL DEFAULT 'pending',
  rejection_reason text,
  reviewed_by uuid,
  reviewed_at timestamptz,
  submitted_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.merchant_kyc TO authenticated;
GRANT ALL ON public.merchant_kyc TO service_role;

ALTER TABLE public.merchant_kyc ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_kyc FORCE ROW LEVEL SECURITY;

CREATE POLICY "kyc_select_own" ON public.merchant_kyc
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "kyc_insert_own" ON public.merchant_kyc
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "kyc_update_own_pending" ON public.merchant_kyc
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id AND status IN ('pending','rejected'))
  WITH CHECK (auth.uid() = user_id AND status IN ('pending','rejected'));

CREATE POLICY "kyc_admin_update" ON public.merchant_kyc
  FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_merchant_kyc_updated_at
  BEFORE UPDATE ON public.merchant_kyc
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.guard_kyc_status_columns()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    IF NEW.status IS DISTINCT FROM OLD.status
       OR NEW.reviewed_by IS DISTINCT FROM OLD.reviewed_by
       OR NEW.reviewed_at IS DISTINCT FROM OLD.reviewed_at
       OR NEW.rejection_reason IS DISTINCT FROM OLD.rejection_reason
    THEN
      RAISE EXCEPTION 'Seul un administrateur peut modifier le statut KYC';
    END IF;
    IF OLD.status = 'rejected' THEN
      NEW.status := 'pending';
      NEW.rejection_reason := NULL;
    END IF;
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_guard_kyc_status
  BEFORE UPDATE ON public.merchant_kyc
  FOR EACH ROW EXECUTE FUNCTION public.guard_kyc_status_columns();

CREATE POLICY "kyc_storage_select_own"
  ON storage.objects FOR SELECT TO authenticated
  USING (
    bucket_id = 'kyc-documents'
    AND (auth.uid()::text = (storage.foldername(name))[1]
         OR public.has_role(auth.uid(), 'admin'))
  );

CREATE POLICY "kyc_storage_insert_own"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'kyc-documents'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "kyc_storage_update_own"
  ON storage.objects FOR UPDATE TO authenticated
  USING (
    bucket_id = 'kyc-documents'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "kyc_storage_delete_own"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'kyc-documents'
    AND (auth.uid()::text = (storage.foldername(name))[1]
         OR public.has_role(auth.uid(), 'admin'))
  );