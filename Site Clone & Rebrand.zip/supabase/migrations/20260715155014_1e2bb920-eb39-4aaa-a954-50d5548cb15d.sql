-- 1) exchange_rates table
CREATE TABLE public.exchange_rates (
  id BIGSERIAL PRIMARY KEY,
  from_currency VARCHAR(3) NOT NULL,
  to_currency VARCHAR(3) NOT NULL,
  base_rate NUMERIC(14, 8) NOT NULL,
  applied_rate NUMERIC(14, 8) NOT NULL,
  spread NUMERIC(6, 4) NOT NULL DEFAULT 0.02,
  provider TEXT NOT NULL DEFAULT 'EXCHANGE_RATE_API',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_exchange_rates_pair_time ON public.exchange_rates(from_currency, to_currency, created_at DESC);

GRANT SELECT ON public.exchange_rates TO anon, authenticated;
GRANT ALL ON public.exchange_rates TO service_role;

ALTER TABLE public.exchange_rates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Exchange rates readable by anyone"
  ON public.exchange_rates FOR SELECT
  USING (true);

-- 2) profiles: webhook fields
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS webhook_url TEXT,
  ADD COLUMN IF NOT EXISTS webhook_secret TEXT;