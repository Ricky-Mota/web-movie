
-- Provider-side transactions (mobile money, banks, etc.) - separate from Stripe transactions
CREATE TYPE public.provider_tx_status AS ENUM ('pending','processing','succeeded','failed','cancelled');

CREATE TABLE public.provider_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  merchant_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES public.providers(id) ON DELETE RESTRICT,
  environment TEXT NOT NULL DEFAULT 'sandbox',
  external_reference TEXT,             -- our reference sent to provider
  provider_reference TEXT,             -- provider's transaction id
  customer_msisdn TEXT NOT NULL,
  amount NUMERIC(14,2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'CDF',
  status public.provider_tx_status NOT NULL DEFAULT 'pending',
  description TEXT,
  provider_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  last_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_provider_tx_merchant ON public.provider_transactions(merchant_id, created_at DESC);
CREATE INDEX idx_provider_tx_external_ref ON public.provider_transactions(external_reference);
CREATE INDEX idx_provider_tx_provider_ref ON public.provider_transactions(provider_reference);

GRANT SELECT ON public.provider_transactions TO authenticated;
GRANT ALL ON public.provider_transactions TO service_role;

ALTER TABLE public.provider_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.provider_transactions FORCE ROW LEVEL SECURITY;

CREATE POLICY "merchants_select_own_provider_tx"
  ON public.provider_transactions FOR SELECT TO authenticated
  USING (merchant_id = auth.uid());

CREATE TRIGGER trg_provider_tx_updated_at
  BEFORE UPDATE ON public.provider_transactions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Extend Airtel Money RDC credential fields with base URL and callback secret
UPDATE public.providers
SET credential_fields = '[
  {"key":"merchant_id","label":"ID marchand","type":"text","required":true},
  {"key":"client_id","label":"Client ID","type":"text","required":true},
  {"key":"client_secret","label":"Client Secret","type":"password","required":true},
  {"key":"base_url","label":"URL de base API (ex: https://openapiuat.airtel.africa)","type":"text","required":true},
  {"key":"callback_secret","label":"Secret de callback (HMAC SHA-256)","type":"password","required":true}
]'::jsonb
WHERE slug = 'airtel-money-cd';
