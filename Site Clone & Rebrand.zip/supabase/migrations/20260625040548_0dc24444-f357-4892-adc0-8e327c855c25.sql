
-- =========================================
-- PROVIDERS (public catalog)
-- =========================================
CREATE TYPE public.provider_type AS ENUM ('mobile_money', 'bank', 'card_network');
CREATE TYPE public.provider_status AS ENUM ('live', 'coming_soon');
CREATE TYPE public.provider_region AS ENUM ('rdc', 'africa', 'international');

CREATE TABLE public.providers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  type public.provider_type NOT NULL,
  region public.provider_region NOT NULL,
  country TEXT,                -- ISO-2 code or NULL for multi
  logo_emoji TEXT,
  brand_color TEXT,
  status public.provider_status NOT NULL DEFAULT 'live',
  docs_url TEXT,
  credential_fields JSONB NOT NULL DEFAULT '[]'::jsonb,
  -- e.g. [{"key":"api_key","label":"Clé API","type":"password","required":true}, ...]
  sort_order INTEGER NOT NULL DEFAULT 100,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_providers_region_type ON public.providers(region, type, sort_order);

-- Catalog is public read-only
GRANT SELECT ON public.providers TO anon, authenticated;
GRANT ALL ON public.providers TO service_role;

ALTER TABLE public.providers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Providers are publicly readable"
  ON public.providers FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE TRIGGER set_providers_updated_at
  BEFORE UPDATE ON public.providers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================
-- MERCHANT CONNECTIONS (credentials private)
-- =========================================
CREATE TYPE public.connection_status AS ENUM ('active', 'disabled', 'pending');
CREATE TYPE public.connection_env AS ENUM ('sandbox', 'live');
CREATE TYPE public.connection_test_status AS ENUM ('untested', 'ok', 'failed');

CREATE TABLE public.merchant_provider_connections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  merchant_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES public.providers(id) ON DELETE CASCADE,
  environment public.connection_env NOT NULL DEFAULT 'sandbox',
  status public.connection_status NOT NULL DEFAULT 'pending',
  credentials JSONB NOT NULL DEFAULT '{}'::jsonb,
  -- masked hint kept readable: e.g. {"api_key":"sk_***xyz"}
  credentials_masked JSONB NOT NULL DEFAULT '{}'::jsonb,
  last_test_status public.connection_test_status NOT NULL DEFAULT 'untested',
  last_test_message TEXT,
  last_tested_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (merchant_id, provider_id)
);

CREATE INDEX idx_mpc_merchant ON public.merchant_provider_connections(merchant_id);

-- NOTE: credentials column is NEVER granted to authenticated.
-- Merchants read metadata only via column-level grants below.
-- Mutations go through server functions (service_role).
GRANT SELECT
  (id, merchant_id, provider_id, environment, status, credentials_masked,
   last_test_status, last_test_message, last_tested_at, created_at, updated_at)
  ON public.merchant_provider_connections
  TO authenticated;
GRANT ALL ON public.merchant_provider_connections TO service_role;

ALTER TABLE public.merchant_provider_connections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Merchant reads own connections"
  ON public.merchant_provider_connections FOR SELECT
  TO authenticated
  USING (auth.uid() = merchant_id);

CREATE TRIGGER set_mpc_updated_at
  BEFORE UPDATE ON public.merchant_provider_connections
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================
-- SEED catalog
-- =========================================
INSERT INTO public.providers (slug, name, type, region, country, logo_emoji, brand_color, status, sort_order, credential_fields) VALUES
-- RDC mobile money
('orange-money-cd', 'Orange Money RDC', 'mobile_money', 'rdc', 'CD', '🟠', '#FF7900', 'live', 10,
  '[{"key":"merchant_code","label":"Code marchand","type":"text","required":true},{"key":"api_key","label":"Clé API","type":"password","required":true},{"key":"api_secret","label":"Secret API","type":"password","required":true},{"key":"callback_url","label":"URL de callback","type":"text","required":false}]'::jsonb),
('airtel-money-cd', 'Airtel Money RDC', 'mobile_money', 'rdc', 'CD', '🔴', '#E2231A', 'live', 11,
  '[{"key":"merchant_id","label":"ID marchand","type":"text","required":true},{"key":"client_id","label":"Client ID","type":"text","required":true},{"key":"client_secret","label":"Client Secret","type":"password","required":true}]'::jsonb),
('mpesa-vodacom-cd', 'M-Pesa Vodacom RDC', 'mobile_money', 'rdc', 'CD', '🟢', '#00A859', 'live', 12,
  '[{"key":"shortcode","label":"Shortcode","type":"text","required":true},{"key":"consumer_key","label":"Consumer Key","type":"password","required":true},{"key":"consumer_secret","label":"Consumer Secret","type":"password","required":true},{"key":"passkey","label":"Passkey","type":"password","required":true}]'::jsonb),
('afrimoney-cd', 'Afrimoney RDC', 'mobile_money', 'rdc', 'CD', '🟡', '#FFD100', 'coming_soon', 13,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true},{"key":"merchant_code","label":"Code marchand","type":"text","required":true}]'::jsonb),

-- RDC banks
('equity-bcdc', 'Equity BCDC', 'bank', 'rdc', 'CD', '🏦', '#D71920', 'live', 20,
  '[{"key":"client_id","label":"Client ID","type":"text","required":true},{"key":"client_secret","label":"Client Secret","type":"password","required":true},{"key":"merchant_account","label":"Compte marchand","type":"text","required":true},{"key":"api_base_url","label":"URL API","type":"text","required":false}]'::jsonb),
('rawbank', 'Rawbank', 'bank', 'rdc', 'CD', '🏦', '#003F87', 'live', 21,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true},{"key":"merchant_account","label":"Compte marchand","type":"text","required":true}]'::jsonb),
('tmb', 'Trust Merchant Bank (TMB)', 'bank', 'rdc', 'CD', '🏦', '#00563F', 'live', 22,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true},{"key":"merchant_account","label":"Compte marchand","type":"text","required":true}]'::jsonb),
('ecobank-cd', 'Ecobank RDC', 'bank', 'rdc', 'CD', '🏦', '#0066B3', 'live', 23,
  '[{"key":"client_id","label":"Client ID","type":"text","required":true},{"key":"client_secret","label":"Client Secret","type":"password","required":true},{"key":"merchant_account","label":"Compte marchand","type":"text","required":true}]'::jsonb),
('fbn-bank-cd', 'FBN Bank RDC', 'bank', 'rdc', 'CD', '🏦', '#003366', 'coming_soon', 24,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true}]'::jsonb),
('access-bank-cd', 'Access Bank RDC', 'bank', 'rdc', 'CD', '🏦', '#F47B20', 'coming_soon', 25,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true}]'::jsonb),
('bgfi-bank-cd', 'BGFI Bank RDC', 'bank', 'rdc', 'CD', '🏦', '#005DAA', 'coming_soon', 26,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true}]'::jsonb),
('uba-cd', 'UBA Congo (RDC)', 'bank', 'rdc', 'CD', '🏦', '#D11317', 'coming_soon', 27,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true}]'::jsonb),

-- Africa expanded
('mtn-momo', 'MTN Mobile Money', 'mobile_money', 'africa', NULL, '🟡', '#FFCC00', 'live', 50,
  '[{"key":"subscription_key","label":"Subscription Key","type":"password","required":true},{"key":"api_user","label":"API User","type":"text","required":true},{"key":"api_key","label":"API Key","type":"password","required":true}]'::jsonb),
('wave', 'Wave', 'mobile_money', 'africa', NULL, '🌊', '#1DCBEF', 'live', 51,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true},{"key":"webhook_secret","label":"Webhook Secret","type":"password","required":false}]'::jsonb),
('moov-money', 'Moov Money', 'mobile_money', 'africa', NULL, '🔵', '#003DA5', 'coming_soon', 52,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true}]'::jsonb),
('stanbic-bank', 'Stanbic Bank', 'bank', 'africa', NULL, '🏦', '#0033A0', 'coming_soon', 60,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true}]'::jsonb),
('standard-bank', 'Standard Bank', 'bank', 'africa', NULL, '🏦', '#0033A0', 'coming_soon', 61,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true}]'::jsonb),
('attijariwafa', 'Attijariwafa Bank', 'bank', 'africa', NULL, '🏦', '#C8102E', 'coming_soon', 62,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true}]'::jsonb),

-- International
('visa-direct', 'Visa Direct', 'card_network', 'international', NULL, '💳', '#1A1F71', 'coming_soon', 80,
  '[{"key":"api_key","label":"Clé API","type":"password","required":true},{"key":"user_id","label":"User ID","type":"text","required":true},{"key":"cert_password","label":"Certificate Password","type":"password","required":false}]'::jsonb),
('mastercard-send', 'Mastercard Send', 'card_network', 'international', NULL, '💳', '#EB001B', 'coming_soon', 81,
  '[{"key":"consumer_key","label":"Consumer Key","type":"password","required":true},{"key":"signing_key","label":"Signing Key","type":"password","required":true}]'::jsonb),
('paypal', 'PayPal', 'card_network', 'international', NULL, '🅿️', '#003087', 'coming_soon', 82,
  '[{"key":"client_id","label":"Client ID","type":"text","required":true},{"key":"client_secret","label":"Client Secret","type":"password","required":true}]'::jsonb),
('wise', 'Wise (TransferWise)', 'bank', 'international', NULL, '🌐', '#9FE870', 'coming_soon', 83,
  '[{"key":"api_token","label":"API Token","type":"password","required":true},{"key":"profile_id","label":"Profile ID","type":"text","required":true}]'::jsonb),
('swift', 'SWIFT', 'bank', 'international', NULL, '🌐', '#1A1A1A', 'coming_soon', 84,
  '[{"key":"bic","label":"BIC / SWIFT Code","type":"text","required":true},{"key":"api_key","label":"Clé API","type":"password","required":true}]'::jsonb);
