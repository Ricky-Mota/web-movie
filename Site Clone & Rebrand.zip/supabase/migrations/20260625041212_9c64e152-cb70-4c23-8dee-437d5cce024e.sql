DROP POLICY IF EXISTS "Providers are publicly readable" ON public.providers;
REVOKE SELECT ON public.providers FROM anon;
GRANT SELECT ON public.providers TO authenticated;
CREATE POLICY "Providers readable by authenticated users" ON public.providers FOR SELECT TO authenticated USING (true);