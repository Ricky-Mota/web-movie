
REVOKE EXECUTE ON FUNCTION public.attach_depot_commun() FROM PUBLIC, anon, authenticated;
