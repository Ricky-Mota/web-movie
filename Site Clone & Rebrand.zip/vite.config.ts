import path from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { loadEnv, type UserConfig } from "vite";
import { visualizer } from "rollup-plugin-visualizer";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
const baseConfig = defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
});


function isViteTsconfigPathsPlugin(value: unknown): boolean {
  return (
    typeof value === "object" &&
    value !== null &&
    "name" in value &&
    (value as { name: string }).name === "vite-tsconfig-paths"
  );
}

function filterPlugins(
  plugins: NonNullable<UserConfig["plugins"]>
): NonNullable<UserConfig["plugins"]> {
  const result = plugins.flatMap((plugin) => {
    if (Array.isArray(plugin)) {
      return [filterPlugins(plugin)];
    }
    if (isViteTsconfigPathsPlugin(plugin)) {
      return [];
    }
    return [plugin];
  });
  return result as NonNullable<UserConfig["plugins"]>;
}

export default async function config(env: {
  command: "build" | "serve";
  mode: string;
}): Promise<UserConfig> {
  const resolved = await baseConfig(env);
  // Vite 8 resolves tsconfig paths natively; the vite-tsconfig-paths plugin now only emits a
  // deprecation warning. Remove it and enable the native resolver instead.
  resolved.plugins = filterPlugins(resolved.plugins ?? []);
  resolved.resolve = {
    ...(resolved.resolve ?? {}),
    tsconfigPaths: true,
    alias: {
      ...((resolved.resolve as any)?.alias ?? {}),
      "entities/lib/decode.js": path.resolve(__dirname, "node_modules/entities/lib/decode.js"),
      "entities/lib/encode.js": path.resolve(__dirname, "node_modules/entities/lib/encode.js"),
      "entities": path.resolve(__dirname, "node_modules/entities"),
    },
  };

  // Load all (non VITE_) env vars into process.env for server-side routes (do NOT add to client define).
  const serverEnv = loadEnv(env.mode, process.cwd(), "");
  Object.assign(process.env, serverEnv);

  // Bundle analyzer — enabled on build when ANALYZE=1 (or always in build mode below).
  // Writes dist/stats.html with an interactive treemap (gzip + brotli sizes).
  if (env.command === "build" && process.env.ANALYZE === "1") {
    resolved.plugins.push(
      visualizer({
        filename: "dist/stats.html",
        template: "treemap",
        gzipSize: true,
        brotliSize: true,
        open: false,
      })
    );
  }
  return resolved;
}

