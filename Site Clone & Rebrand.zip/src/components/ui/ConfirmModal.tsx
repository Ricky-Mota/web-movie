export function ConfirmModal({
  title,
  message,
  confirmLabel,
  cancelLabel = "Annuler",
  onCancel,
  onConfirm,
  isPending = false,
}: {
  title: string;
  message: string;
  confirmLabel: string;
  cancelLabel?: string;
  onCancel: () => void;
  onConfirm: () => void;
  isPending?: boolean;
}) {
  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 grid place-items-center p-4"
      onClick={onCancel}
    >
      <div
        className="bg-card rounded-2xl border max-w-md w-full p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xl">⚠️</span>
          <h3 className="text-lg font-bold">{title}</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-6">{message}</p>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 rounded-full border px-4 py-2.5 text-sm hover:bg-muted"
          >
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            disabled={isPending}
            className="flex-1 rounded-full bg-red-600 text-white px-4 py-2.5 text-sm font-semibold disabled:opacity-60"
          >
            {isPending ? "Suppression…" : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
