import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Menu, X, User as UserIcon, ChevronDown, LogOut, LayoutDashboard, Shield } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { getMyRoles } from "@/lib/admin.functions";

const nav = [
  { to: "/about", label: "Pourquoi" },
  { to: "/products", label: "Produits" },
  { to: "/solutions", label: "Solutions" },
  { to: "/payments", label: "Paiements" },
  { to: "/faq", label: "FAQ" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setAuthed(!!data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) =>
      setAuthed(!!session),
    );
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [menuOpen]);

  const fetchRoles = useServerFn(getMyRoles);
  const rolesQ = useQuery({
    queryKey: ["my-roles"],
    queryFn: () => fetchRoles(),
    enabled: authed,
    staleTime: 60_000,
  });
  const isAdmin = (rolesQ.data ?? []).includes("admin");

  async function handleSignOut() {
    setMenuOpen(false);
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/login", replace: true });
  }

  return (
    <header className="sticky top-0 z-50 gradient-brand text-white">
      <div className="container-page flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-bold text-lg">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-white/15 backdrop-blur">
            <span className="text-white font-black">Z</span>
          </span>
          <span>ZbossPay</span>
        </Link>
        <nav className="hidden md:flex items-center gap-7 text-sm">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="opacity-90 hover:opacity-100 transition"
              activeProps={{ className: "opacity-100 underline underline-offset-8" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="hidden md:flex items-center gap-3">
          {authed ? (
            <div ref={menuRef} className="relative">
              <button
                onClick={() => setMenuOpen((o) => !o)}
                className="flex items-center gap-2 rounded-full bg-white/15 hover:bg-white/25 backdrop-blur px-3 py-1.5 text-sm font-medium transition"
                aria-haspopup="menu"
                aria-expanded={menuOpen}
              >
                <span className="grid h-7 w-7 place-items-center rounded-full bg-white/20">
                  <UserIcon size={14} />
                </span>
                <span>Mon compte</span>
                <ChevronDown size={14} className={menuOpen ? "rotate-180 transition" : "transition"} />
              </button>
              {menuOpen && (
                <div
                  role="menu"
                  className="absolute right-0 mt-2 w-56 rounded-xl border bg-card text-foreground shadow-xl overflow-hidden"
                >
                  <Link
                    to="/dashboard"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-muted"
                  >
                    <LayoutDashboard size={16} /> Tableau de bord
                  </Link>
                  {isAdmin && (
                    <Link
                      to="/admin"
                      onClick={() => setMenuOpen(false)}
                      className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-muted border-t"
                    >
                      <Shield size={16} /> Admin
                    </Link>
                  )}
                  <button
                    onClick={handleSignOut}
                    className="w-full flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-muted border-t text-red-600"
                  >
                    <LogOut size={16} /> Se déconnecter
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link
              to="/login"
              className="flex items-center gap-2 rounded-full bg-white/15 hover:bg-white/25 backdrop-blur px-4 py-2 text-sm font-semibold transition"
            >
              <UserIcon size={14} /> Mon compte
            </Link>

          )}
        </div>
        <button
          className="md:hidden p-2"
          onClick={() => setOpen((o) => !o)}
          aria-label="Menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
      {open && (
        <div className="md:hidden border-t border-white/10 bg-[var(--brand)]">
          <div className="container-page py-4 flex flex-col gap-3 text-sm">
            {nav.map((n) => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="py-1">
                {n.label}
              </Link>
            ))}
            {authed ? (
              <>
                <Link to="/dashboard" onClick={() => setOpen(false)} className="py-1 border-t border-white/10 pt-3 flex items-center gap-2">
                  <LayoutDashboard size={16} /> Tableau de bord
                </Link>
                {isAdmin && (
                  <Link to="/admin" onClick={() => setOpen(false)} className="py-1 flex items-center gap-2">
                    <Shield size={16} /> Admin
                  </Link>
                )}
                <button
                  onClick={() => { setOpen(false); handleSignOut(); }}
                  className="py-1 flex items-center gap-2 text-left text-white/90"
                >
                  <LogOut size={16} /> Se déconnecter
                </button>
              </>
            ) : (
              <Link
                to="/login"
                onClick={() => setOpen(false)}
                className="mt-2 rounded-full gradient-cta text-[var(--cta-foreground)] shadow-lg px-4 py-2 text-center font-semibold"
              >
                Connexion / Inscription
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
