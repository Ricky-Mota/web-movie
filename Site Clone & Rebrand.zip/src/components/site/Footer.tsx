import { Link } from "@tanstack/react-router";
import { APP_EMAIL } from "@/lib/site-config";

export function Footer() {
  return (
    <footer className="bg-[var(--brand)] text-white/80 mt-24">
      <div className="container-page py-14 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 font-bold text-lg text-white">
            <span className="grid h-9 w-9 place-items-center rounded-lg gradient-brand">Z</span>
            ZbossPay
          </div>
          <p className="mt-3 text-sm">
            Plateforme de paiement mobile pour la RDC — encaisser, disburser et payer en quelques secondes.
          </p>
        </div>
        <div>
          <h4 className="text-white font-semibold mb-3">Produit</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/products">Produits</Link></li>
            <li><Link to="/solutions">Solutions</Link></li>
            <li><Link to="/payments">Paiements</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-semibold mb-3">Entreprise</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/about">Pourquoi ZbossPay</Link></li>
            <li><Link to="/faq">FAQ</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-semibold mb-3">Contact</h4>
          <ul className="space-y-2 text-sm">
            <li>USSD : *5111#</li>
            <li>
              <a href={`mailto:${APP_EMAIL}`} className="hover:underline">
                {APP_EMAIL}
              </a>
            </li>
            <li>Kinshasa, RDC</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-white/60">
        © {new Date().getFullYear()} ZbossPay. Tous droits réservés.
      </div>
    </footer>
  );
}
