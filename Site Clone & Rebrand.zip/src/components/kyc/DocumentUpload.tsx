import { useRef, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export type DocumentKind = "rccm" | "nif" | "id" | "selfie";

const ACCEPTED_MIME: Record<DocumentKind, string[]> = {
  rccm: ["application/pdf", "image/jpeg", "image/png", "image/webp"],
  nif: ["application/pdf", "image/jpeg", "image/png", "image/webp"],
  id: ["image/jpeg", "image/png", "image/webp", "application/pdf"],
  selfie: ["image/jpeg", "image/png", "image/webp"],
};

const ACCEPTED_EXT: Record<DocumentKind, string[]> = {
  rccm: ["pdf", "jpg", "jpeg", "png", "webp"],
  nif: ["pdf", "jpg", "jpeg", "png", "webp"],
  id: ["pdf", "jpg", "jpeg", "png", "webp"],
  selfie: ["jpg", "jpeg", "png", "webp"],
};

const MAX_BYTES = 5 * 1024 * 1024; // 5 MB
const MIN_BYTES = 10 * 1024; // 10 KB — refuse empty/placeholder files

export interface DocumentUploadProps {
  kind: DocumentKind;
  label: string;
  help?: string;
  bucket?: string;
  path: string; // current stored object path (empty if none)
  disabled?: boolean;
  required?: boolean;
  onUploaded: (path: string, meta: { name: string; size: number; type: string }) => void;
  onCleared?: () => void;
}

function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} Ko`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
}

function validate(file: File, kind: DocumentKind): string | null {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  const mimeOk = ACCEPTED_MIME[kind].includes(file.type);
  const extOk = ACCEPTED_EXT[kind].includes(ext);
  if (!mimeOk && !extOk) {
    return `Format non accepté. Autorisés : ${ACCEPTED_EXT[kind].join(", ").toUpperCase()}.`;
  }
  if (file.size > MAX_BYTES) {
    return `Fichier trop volumineux (${formatSize(file.size)}). Maximum 5 Mo.`;
  }
  if (file.size < MIN_BYTES) {
    return `Fichier trop petit (${formatSize(file.size)}). Minimum 10 Ko.`;
  }
  return null;
}

export function DocumentUpload({
  kind,
  label,
  help,
  bucket = "kyc-documents",
  path,
  disabled,
  required,
  onUploaded,
  onCleared,
}: DocumentUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [meta, setMeta] = useState<{ name: string; size: number; type: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  async function handleFile(file: File) {
    setError(null);
    const validationError = validate(file, kind);
    if (validationError) {
      setError(validationError);
      toast.error(`${label} : ${validationError}`);
      return;
    }

    const { data: userRes } = await supabase.auth.getUser();
    const uid = userRes.user?.id;
    if (!uid) {
      setError("Session expirée, reconnectez-vous.");
      toast.error("Session expirée");
      return;
    }

    setUploading(true);
    setProgress(15);
    const ext = (file.name.split(".").pop() || "bin").toLowerCase();
    const objectPath = `${uid}/${kind}-${Date.now()}.${ext}`;

    // Fake smooth progress while the upload is in flight (Supabase JS v2 doesn't expose progress).
    const tick = setInterval(() => {
      setProgress((p) => (p < 85 ? p + 7 : p));
    }, 180);

    const { error: upErr } = await supabase.storage
      .from(bucket)
      .upload(objectPath, file, { upsert: true, contentType: file.type });

    clearInterval(tick);
    setUploading(false);

    if (upErr) {
      setProgress(0);
      setError(upErr.message);
      toast.error(`Échec de l'upload de ${label}`, { description: upErr.message });
      return;
    }

    setProgress(100);
    const info = { name: file.name, size: file.size, type: file.type };
    setMeta(info);
    onUploaded(objectPath, info);
    toast.success(`${label} téléversé`);
  }

  function clear() {
    if (inputRef.current) inputRef.current.value = "";
    setMeta(null);
    setProgress(0);
    setError(null);
    onCleared?.();
  }

  const hasFile = !!path || !!meta;

  return (
    <div
      className={`rounded-xl border p-4 space-y-2 transition ${
        dragOver ? "border-[var(--cta)] bg-[var(--cta)]/5" : "bg-background"
      } ${error ? "border-red-300" : ""}`}
      onDragOver={(e) => {
        if (disabled) return;
        e.preventDefault();
        setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragOver(false);
        if (disabled) return;
        const f = e.dataTransfer.files?.[0];
        if (f) void handleFile(f);
      }}
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm font-semibold">
          {label} {required && <span className="text-red-600">*</span>}
        </p>
        {hasFile && !uploading && (
          <span className="text-xs text-green-700">✓ envoyé</span>
        )}
      </div>
      {help && <p className="text-xs text-muted-foreground">{help}</p>}

      <label className="block">
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED_MIME[kind].join(",")}
          disabled={disabled || uploading}
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void handleFile(f);
          }}
          className="block w-full text-xs file:mr-3 file:rounded-md file:border-0 file:bg-muted file:px-3 file:py-1.5 file:text-xs file:font-semibold hover:file:bg-muted/80 disabled:opacity-50"
        />
      </label>

      <p className="text-[11px] text-muted-foreground">
        Formats : {ACCEPTED_EXT[kind].join(", ").toUpperCase()} · max 5 Mo · ou glissez-déposez le fichier ici.
      </p>

      {uploading && (
        <div className="space-y-1">
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full bg-[var(--cta)] transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground">Téléversement… {progress}%</p>
        </div>
      )}

      {meta && !uploading && (
        <div className="flex items-center justify-between rounded-md bg-muted/60 px-3 py-2 text-xs">
          <span className="truncate">
            📎 {meta.name} · {formatSize(meta.size)}
          </span>
          {!disabled && (
            <button
              type="button"
              onClick={clear}
              className="text-red-600 hover:underline ml-2 shrink-0"
            >
              Remplacer
            </button>
          )}
        </div>
      )}

      {!meta && path && !uploading && (
        <p className="text-xs text-muted-foreground">
          Document déjà fourni précédemment.
        </p>
      )}

      {error && <p className="text-xs text-red-600">{error}</p>}
    </div>
  );
}
