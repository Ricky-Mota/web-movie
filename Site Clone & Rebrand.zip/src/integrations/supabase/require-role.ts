import { createMiddleware } from "@tanstack/react-start";
import { requireSupabaseAuth } from "./auth-middleware";

export type AppRole = "admin" | "moderator" | "user";

/**
 * Server-side role guard. Use after `requireSupabaseAuth`.
 * Verifies the caller has the given role via the SECURITY DEFINER
 * `public.has_role` function (called with the service-role client so
 * regular users cannot invoke it directly).
 *
 * Usage:
 *   createServerFn({ method: "POST" })
 *     .middleware([requireSupabaseAuth, requireRole("admin")])
 *     .handler(...)
 */
export function requireRole(role: AppRole) {
  return createMiddleware({ type: "function" })
    .middleware([requireSupabaseAuth])
    .server(async ({ next, context }) => {
      const { supabaseAdmin } = await import("./client.server");
      const { data, error } = await supabaseAdmin.rpc("has_role", {
        _user_id: context.userId,
        _role: role,
      });
      if (error) {
        console.error("[requireRole] has_role failed:", error.message);
        throw new Error("Forbidden");
      }
      if (data !== true) {
        throw new Error("Forbidden: insufficient role");
      }
      return next({ context: { role } });
    });
}
