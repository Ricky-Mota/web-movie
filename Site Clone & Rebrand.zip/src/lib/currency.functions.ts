import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SPREAD = 0.02;
const FALLBACK_RATE = 0.00034;
const CACHE_TTL_MS = 60 * 60 * 1000;

const convertSchema = z.object({
  amount: z.number().positive(),
  from: z.enum(["CDF", "USD"]).default("CDF"),
  to: z.enum(["CDF", "USD"]).default("USD"),
});

/**
 * Public read: current applied CDF→USD (or USD→CDF) rate with 2% spread and 1h cache.
 */
export const getExchangeRate = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  // Try cache (< 1h)
  const { data: cached } = await supabaseAdmin
    .from("exchange_rates")
    .select("base_rate, applied_rate, created_at, provider")
    .eq("from_currency", "CDF")
    .eq("to_currency", "USD")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (cached && Date.now() - new Date(cached.created_at).getTime() < CACHE_TTL_MS) {
    return {
      baseRate: Number(cached.base_rate),
      appliedRate: Number(cached.applied_rate),
      spread: SPREAD,
      provider: cached.provider,
      cached: true,
      updatedAt: cached.created_at,
    };
  }

  // Fetch fresh rate
  let baseRate = FALLBACK_RATE;
  let provider = "FALLBACK";
  const apiKey = process.env.EXCHANGE_RATE_API_KEY;
  try {
    const url = apiKey
      ? `https://v6.exchangerate-api.com/v6/${apiKey}/pair/CDF/USD`
      : `https://open.er-api.com/v6/latest/CDF`;
    const res = await fetch(url);
    if (res.ok) {
      const j: any = await res.json();
      const rate = j.conversion_rate ?? j.rates?.USD;
      if (typeof rate === "number" && rate > 0) {
        baseRate = rate;
        provider = apiKey ? "EXCHANGE_RATE_API" : "OPEN_ER_API";
      }
    }
  } catch (err) {
    console.error("[currency] fetch failed", err);
  }

  const appliedRate = baseRate * (1 - SPREAD);

  const { data: inserted } = await supabaseAdmin
    .from("exchange_rates")
    .insert({
      from_currency: "CDF",
      to_currency: "USD",
      base_rate: baseRate,
      applied_rate: appliedRate,
      spread: SPREAD,
      provider,
    })
    .select("created_at")
    .single();

  return {
    baseRate,
    appliedRate,
    spread: SPREAD,
    provider,
    cached: false,
    updatedAt: inserted?.created_at ?? new Date().toISOString(),
  };
});

/** Convertit un montant selon le taux appliqué courant. */
export const convertAmount = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => convertSchema.parse(input))
  .handler(async ({ data }) => {
    const rate = await getExchangeRate();
    if (data.from === data.to) {
      return { converted: data.amount, rateApplied: 1, rate };
    }
    let converted: number;
    if (data.from === "CDF" && data.to === "USD") {
      converted = data.amount * rate.appliedRate;
    } else {
      // USD → CDF: divide by applied rate (spread already protects margin)
      converted = data.amount / rate.appliedRate;
    }
    return {
      converted: Number(converted.toFixed(2)),
      rateApplied: rate.appliedRate,
      rate,
    };
  });
