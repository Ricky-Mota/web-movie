import Stripe from "stripe";

let _stripe: Stripe | null = null;

export function getStripe(): Stripe {
  if (_stripe) return _stripe;
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    throw new Error(
      "STRIPE_SECRET_KEY is not configured. Add it in the project secrets.",
    );
  }
  _stripe = new Stripe(key, { typescript: true });
  return _stripe;
}

// Commission ZbossPay : 3% par transaction réussie
export const APPLICATION_FEE_PERCENT = 3;

export function computeFee(amountInCents: number): number {
  return Math.round((amountInCents * APPLICATION_FEE_PERCENT) / 100);
}
