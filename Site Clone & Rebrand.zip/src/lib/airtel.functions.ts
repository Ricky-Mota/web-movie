import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

function dbFail(scope: string, err: { message?: string } | null | undefined): never {
  console.error(`[airtel:${scope}]`, err?.message ?? err);
  throw new Error("Une erreur est survenue. Réessayez plus tard.");
}

const SLUG = "airtel-money-cd";

async function loadCreds(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: provider, error: pErr } = await supabaseAdmin
    .from("providers")
    .select("id")
    .eq("slug", SLUG)
    .maybeSingle();
  if (pErr) dbFail("provider", pErr);
  if (!provider) throw new Error("Connecteur Airtel introuvable.");

  const { data: conn, error: cErr } = await supabaseAdmin
    .from("merchant_provider_connections")
    .select("id, environment, status, credentials")
    .eq("merchant_id", userId)
    .eq("provider_id", provider.id)
    .maybeSingle();
  if (cErr) dbFail("connection", cErr);
  if (!conn) throw new Error("Vous devez d'abord configurer Airtel Money dans Intégrations.");
  if (conn.status !== "active") {
    throw new Error("Connecteur Airtel inactif. Activez-le dans Intégrations.");
  }

  const c = (conn.credentials ?? {}) as Record<string, string>;
  const required = ["merchant_id", "client_id", "client_secret", "base_url", "callback_secret"];
  for (const k of required) {
    if (!c[k]) throw new Error(`Champ Airtel manquant : ${k}.`);
  }
  return { providerId: provider.id, environment: conn.environment, creds: c };
}

const initiateSchema = z.object({
  amount: z.number().int().positive().max(10_000_000),
  msisdn: z.string().regex(/^\d{9,12}$/, "Numéro invalide (chiffres uniquement, sans +)"),
  description: z.string().max(160).optional(),
});

/** Initie un paiement Airtel Money pour le marchand connecté. */
export const initiateAirtelPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => initiateSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { initiateCollection } = await import("./airtel.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { providerId, environment, creds } = await loadCreds(context.userId);
    const externalReference = `ZBP-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    const { data: tx, error: insErr } = await supabaseAdmin
      .from("provider_transactions")
      .insert({
        merchant_id: context.userId,
        provider_id: providerId,
        environment,
        external_reference: externalReference,
        customer_msisdn: data.msisdn,
        amount: data.amount,
        currency: "CDF",
        description: data.description ?? null,
        status: "pending",
      })
      .select("id")
      .single();
    if (insErr) dbFail("insert", insErr);

    try {
      const result = await initiateCollection(
        creds as never,
        { amount: data.amount, msisdn: data.msisdn, externalReference, description: data.description },
      );
      await supabaseAdmin
        .from("provider_transactions")
        .update({
          provider_reference: result.providerReference ?? null,
          provider_payload: result.raw as never,
          last_message: result.message,
          status: result.ok ? "processing" : "failed",
        })
        .eq("id", tx.id);

      if (!result.ok) {
        return { ok: false, transactionId: tx.id, externalReference, message: result.message };
      }
      return { ok: true, transactionId: tx.id, externalReference, message: result.message };
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Erreur Airtel";
      console.error("[airtel:initiate]", msg);
      await supabaseAdmin
        .from("provider_transactions")
        .update({ status: "failed", last_message: msg.slice(0, 500) })
        .eq("id", tx.id);
      throw new Error("Échec de l'initiation Airtel Money. Vérifiez les identifiants et réessayez.");
    }
  });

const statusSchema = z.object({ transactionId: z.string().uuid() });

/** Interroge Airtel pour mettre à jour le statut d'une transaction du marchand. */
export const refreshAirtelStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => statusSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { queryStatus } = await import("./airtel.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: tx, error } = await supabaseAdmin
      .from("provider_transactions")
      .select("id, merchant_id, external_reference, status")
      .eq("id", data.transactionId)
      .maybeSingle();
    if (error) dbFail("load", error);
    if (!tx || tx.merchant_id !== context.userId) {
      throw new Error("Transaction introuvable.");
    }
    if (!tx.external_reference) throw new Error("Référence externe manquante.");

    const { creds } = await loadCreds(context.userId);
    const result = await queryStatus(creds as never, tx.external_reference);

    await supabaseAdmin
      .from("provider_transactions")
      .update({
        status: result.status,
        last_message: result.message?.slice(0, 500) ?? null,
        provider_payload: result.raw as never,
      })
      .eq("id", tx.id);

    return { status: result.status, message: result.message };
  });

/** Liste les transactions Airtel du marchand connecté. */
export const listAirtelTransactions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: provider } = await supabaseAdmin
      .from("providers").select("id").eq("slug", SLUG).maybeSingle();
    if (!provider) return [];
    const { data, error } = await supabaseAdmin
      .from("provider_transactions")
      .select("id, external_reference, provider_reference, customer_msisdn, amount, currency, status, last_message, created_at, environment")
      .eq("merchant_id", context.userId)
      .eq("provider_id", provider.id)
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) dbFail("list", error);
    return data ?? [];
  });
