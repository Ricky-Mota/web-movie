import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

function dbFail(scope: string, err: { message?: string } | null | undefined): never {
  console.error(`[integrations:${scope}]`, err?.message ?? err);
  throw new Error("Une erreur est survenue. Réessayez plus tard.");
}

// ----- Types shared with the UI -----
export type CredentialField = {
  key: string;
  label: string;
  type: "text" | "password";
  required?: boolean;
};

// ----- Provider catalog (auth required) -----
export const listProviders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("providers")
      .select(
        "id, slug, name, type, region, country, logo_emoji, brand_color, status, docs_url, credential_fields, sort_order",
      )
      .order("region", { ascending: true })
      .order("sort_order", { ascending: true });
    if (error) dbFail("query", error);
    return data ?? [];
  });

// ----- Merchant connections -----
export const listMyConnections = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("merchant_provider_connections")
      .select(
        "id, provider_id, environment, status, credentials_masked, last_test_status, last_test_message, last_tested_at, created_at",
      )
      .eq("merchant_id", context.userId);
    if (error) dbFail("query", error);
    return data ?? [];
  });

function mask(value: string, type: "text" | "password"): string {
  if (!value) return "";
  if (type === "text") return value;
  if (value.length <= 4) return "•".repeat(value.length);
  return "•".repeat(Math.max(4, value.length - 4)) + value.slice(-4);
}

const upsertSchema = z.object({
  provider_id: z.string().uuid(),
  environment: z.enum(["sandbox", "live"]),
  credentials: z.record(z.string(), z.string()),
});

export const upsertConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => upsertSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );

    // 🔒 Activation en production réservée aux marchands KYC approuvés
    if (data.environment === "live") {
      const { assertKycApproved } = await import("./kyc.server");
      await assertKycApproved(context.userId);
    }

    // Load provider to validate required fields + compute masks
    const { data: provider, error: pErr } = await supabaseAdmin
      .from("providers")
      .select("slug, credential_fields, status, name")
      .eq("id", data.provider_id)
      .maybeSingle();
    if (pErr) dbFail("provider", pErr);
    if (!provider) throw new Error("Connecteur introuvable.");
    if (provider.status === "coming_soon") {
      throw new Error(
        `${provider.name} n'est pas encore disponible — partenariat en cours.`,
      );
    }


    // Load existing connection to merge credentials (so a partial update keeps prior secrets)
    const { data: existing } = await supabaseAdmin
      .from("merchant_provider_connections")
      .select("credentials")
      .eq("merchant_id", context.userId)
      .eq("provider_id", data.provider_id)
      .maybeSingle();
    const prior = (existing?.credentials ?? {}) as Record<string, string>;

    const fields = (provider.credential_fields as CredentialField[]) ?? [];
    const cleaned: Record<string, string> = { ...prior };
    const masked: Record<string, string> = {};
    for (const f of fields) {
      const v = (data.credentials[f.key] ?? "").trim();
      if (v) cleaned[f.key] = v;
      if (f.required && !cleaned[f.key]) {
        throw new Error(`Le champ "${f.label}" est requis.`);
      }
      if (cleaned[f.key]) masked[f.key] = mask(cleaned[f.key], f.type);
    }

    // ----- Provider-specific activation guards -----
    if (provider.slug === "airtel-money-cd") {
      const required = ["client_id", "client_secret", "merchant_id", "base_url", "callback_secret"] as const;
      for (const k of required) {
        if (!cleaned[k]) {
          throw new Error(
            `Activation Airtel impossible : le champ « ${k} » est obligatoire.`,
          );
        }
      }
      let url: URL;
      try {
        url = new URL(cleaned.base_url);
      } catch {
        throw new Error("URL de base Airtel invalide (ex: https://openapiuat.airtel.africa).");
      }
      if (url.protocol !== "https:") {
        throw new Error("L'URL Airtel doit utiliser HTTPS.");
      }
      const host = url.hostname.toLowerCase();
      if (data.environment === "sandbox" && !host.includes("uat")) {
        throw new Error(
          "Environnement = Sandbox mais base_url ne pointe pas vers openapiuat.airtel.africa.",
        );
      }
      if (data.environment === "live" && host.includes("uat")) {
        throw new Error(
          "Environnement = Production mais base_url pointe vers le sandbox (UAT).",
        );
      }
      if (cleaned.callback_secret.length < 16) {
        throw new Error(
          "Le secret de callback doit faire au moins 16 caractères pour signer les webhooks.",
        );
      }
    }

    const { error } = await supabaseAdmin
      .from("merchant_provider_connections")
      .upsert(
        {
          merchant_id: context.userId,
          provider_id: data.provider_id,
          environment: data.environment,
          status: "active",
          credentials: cleaned,
          credentials_masked: masked,
          last_test_status: "untested",
          last_test_message: null,
          last_tested_at: null,
        },
        { onConflict: "merchant_id,provider_id" },
      );
    if (error) dbFail("query", error);
    return { ok: true };
  });

const toggleSchema = z.object({
  provider_id: z.string().uuid(),
  enabled: z.boolean(),
});

export const toggleConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => toggleSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );

    // 🔒 Réactivation en production = KYC approuvé requis
    if (data.enabled) {
      const { data: conn } = await supabaseAdmin
        .from("merchant_provider_connections")
        .select("environment")
        .eq("merchant_id", context.userId)
        .eq("provider_id", data.provider_id)
        .maybeSingle();
      if (conn?.environment === "live") {
        const { assertKycApproved } = await import("./kyc.server");
        await assertKycApproved(context.userId);
      }
    }

    const { error } = await supabaseAdmin
      .from("merchant_provider_connections")
      .update({ status: data.enabled ? "active" : "disabled" })
      .eq("merchant_id", context.userId)
      .eq("provider_id", data.provider_id);
    if (error) dbFail("query", error);
    return { ok: true };
  });


const deleteSchema = z.object({ provider_id: z.string().uuid() });

export const deleteConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => deleteSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { error } = await supabaseAdmin
      .from("merchant_provider_connections")
      .delete()
      .eq("merchant_id", context.userId)
      .eq("provider_id", data.provider_id);
    if (error) dbFail("query", error);
    return { ok: true };
  });

const testSchema = z.object({ provider_id: z.string().uuid() });

export const testConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => testSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );

    const { data: conn } = await supabaseAdmin
      .from("merchant_provider_connections")
      .select("credentials, environment")
      .eq("merchant_id", context.userId)
      .eq("provider_id", data.provider_id)
      .maybeSingle();

    // Placeholder test: real provider call goes here.
    // For now we just verify credentials exist.
    const hasCreds =
      conn && Object.keys(conn.credentials as object).length > 0;
    const status: "ok" | "failed" = hasCreds ? "ok" : "failed";
    const message = hasCreds
      ? "Identifiants enregistrés. Le test réel avec l'opérateur sera activé une fois le partenariat signé."
      : "Aucun identifiant configuré.";

    await supabaseAdmin
      .from("merchant_provider_connections")
      .update({
        last_test_status: status,
        last_test_message: message,
        last_tested_at: new Date().toISOString(),
      })
      .eq("merchant_id", context.userId)
      .eq("provider_id", data.provider_id);

    return { status, message };
  });
