export const APP_NAME = "ZbossPay";
export const APP_DOMAIN = "zbosspay.cd";
export const APP_URL = `https://${APP_DOMAIN}`;

/** Adresse email officielle affichée sur le site et utilisée comme contact. */
export const APP_EMAIL = "info@zbosspay.cd";

/** Expéditeur utilisé pour les emails transactionnels (doit être sur un domaine vérifié). */
export const APP_EMAIL_SENDER = "ZbossPay <noreply@infozbosspay.shop>";

/** Domaine d'envoi vérifié dans Lovable Cloud. */
export const APP_EMAIL_SENDER_DOMAIN = "notify.infozbosspay.shop";

/** Adresse de réponse utilisée dans les emails envoyés. */
export const APP_EMAIL_REPLY_TO = "info@zbosspay.cd";
