import * as React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'

interface ContactNotificationEmailProps {
  name: string
  email: string
  company?: string
  message: string
}

export const ContactNotificationEmail = ({
  name,
  email,
  company,
  message,
}: ContactNotificationEmailProps) => (
  <Html lang="fr" dir="ltr">
    <Head />
    <Preview>Nouveau message via le formulaire de contact ZbossPay</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={card}>
          <Heading style={h1}>Nouveau message de contact</Heading>
          <Text style={text}>
            <strong>Nom :</strong> {name}
          </Text>
          <Text style={text}>
            <strong>Email :</strong>{' '}
            <a href={`mailto:${email}`} style={link}>
              {email}
            </a>
          </Text>
          {company && (
            <Text style={text}>
              <strong>Entreprise :</strong> {company}
            </Text>
          )}
          <Text style={text}>
            <strong>Message :</strong>
          </Text>
          <Text style={messageStyle}>{message}</Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export default ContactNotificationEmail

const main = {
  backgroundColor: '#ffffff',
  fontFamily: "'Poppins', Arial, sans-serif",
  margin: 0,
  padding: 0,
}
const container = { maxWidth: '560px', margin: '0 auto', padding: '32px 16px' }
const card = {
  backgroundColor: '#ffffff',
  border: '1px solid #e5e7eb',
  borderRadius: '14px',
  padding: '32px 28px',
}
const h1 = {
  fontSize: '22px',
  fontWeight: 700 as const,
  color: '#0B1E3F',
  margin: '0 0 16px',
}
const text = {
  fontSize: '15px',
  color: '#374151',
  lineHeight: '1.6',
  margin: '0 0 12px',
}
const link = { color: '#0B1E3F', textDecoration: 'underline' }
const messageStyle = {
  fontSize: '15px',
  color: '#374151',
  lineHeight: '1.6',
  margin: 0,
  padding: '16px',
  backgroundColor: '#f9fafb',
  borderRadius: '10px',
  whiteSpace: 'pre-wrap' as const,
}
