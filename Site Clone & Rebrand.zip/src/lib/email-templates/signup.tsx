import * as React from 'react'

import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Link,
  Preview,
  Section,
  Text,
} from '@react-email/components'

interface SignupEmailProps {
  siteName: string
  siteUrl: string
  recipient: string
  confirmationUrl: string
}

export const SignupEmail = ({
  siteName,
  siteUrl,
  recipient,
  confirmationUrl,
}: SignupEmailProps) => (
  <Html lang="fr" dir="ltr">
    <Head />
    <Preview>Confirmez votre adresse pour activer votre compte {siteName}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Text style={brand}>{siteName}</Text>
          <Text style={tagline}>Paiement mobile en RDC</Text>
        </Section>
        <Section style={card}>
          <Heading style={h1}>Bienvenue sur {siteName} 👋</Heading>
          <Text style={text}>
            Merci d'avoir rejoint <strong>{siteName}</strong>. Pour activer votre compte
            et commencer à encaisser via Airtel Money, Orange Money, M-Pesa ou carte,
            confirmez votre adresse email <strong>{recipient}</strong>.
          </Text>
          <Section style={btnWrap}>
            <Button style={button} href={confirmationUrl}>
              Confirmer mon email
            </Button>
          </Section>
          <Text style={smallText}>
            Ou copiez ce lien dans votre navigateur :<br />
            <Link href={confirmationUrl} style={link}>{confirmationUrl}</Link>
          </Text>
          <Hr style={hr} />
          <Text style={footer}>
            Vous n'avez pas créé de compte ? Ignorez cet email en toute sécurité.
          </Text>
        </Section>
        <Text style={signature}>
          L'équipe {siteName} · <Link href={siteUrl} style={linkMuted}>{siteUrl.replace(/^https?:\/\//, '')}</Link>
        </Text>
      </Container>
    </Body>
  </Html>
)

export default SignupEmail

const main = { backgroundColor: '#ffffff', fontFamily: "'Poppins', Arial, sans-serif", margin: 0, padding: 0 }
const container = { maxWidth: '560px', margin: '0 auto', padding: '32px 16px' }
const header = { textAlign: 'center' as const, padding: '8px 0 24px' }
const brand = { fontSize: '26px', fontWeight: 800 as const, color: '#0B1E3F', margin: 0, letterSpacing: '0.5px' }
const tagline = { fontSize: '12px', color: '#6b7280', margin: '4px 0 0', textTransform: 'uppercase' as const, letterSpacing: '1.5px' }
const card = { backgroundColor: '#ffffff', border: '1px solid #e5e7eb', borderRadius: '14px', padding: '32px 28px' }
const h1 = { fontSize: '22px', fontWeight: 700 as const, color: '#0B1E3F', margin: '0 0 16px' }
const text = { fontSize: '15px', color: '#374151', lineHeight: '1.6', margin: '0 0 20px' }
const smallText = { fontSize: '12px', color: '#6b7280', lineHeight: '1.6', margin: '20px 0 0', wordBreak: 'break-all' as const }
const btnWrap = { textAlign: 'center' as const, margin: '8px 0 4px' }
const button = { background: 'linear-gradient(135deg, #D4A24C 0%, #B8862E 100%)', color: '#0B1E3F', fontSize: '15px', fontWeight: 700 as const, borderRadius: '10px', padding: '14px 28px', textDecoration: 'none', display: 'inline-block' }
const link = { color: '#0B1E3F', textDecoration: 'underline' }
const linkMuted = { color: '#6b7280', textDecoration: 'none' }
const hr = { borderColor: '#e5e7eb', margin: '24px 0 16px' }
const footer = { fontSize: '12px', color: '#9ca3af', margin: 0 }
const signature = { fontSize: '12px', color: '#9ca3af', textAlign: 'center' as const, margin: '20px 0 0' }
