import * as React from 'react'

import {
  Body, Button, Container, Head, Heading, Hr, Html, Link, Preview, Section, Text,
} from '@react-email/components'

interface InviteEmailProps {
  siteName: string
  siteUrl: string
  confirmationUrl: string
}

export const InviteEmail = ({ siteName, siteUrl, confirmationUrl }: InviteEmailProps) => (
  <Html lang="fr" dir="ltr">
    <Head />
    <Preview>Vous êtes invité à rejoindre {siteName}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Text style={brand}>{siteName}</Text>
          <Text style={tagline}>Paiement mobile en RDC</Text>
        </Section>
        <Section style={card}>
          <Heading style={h1}>Vous êtes invité ✨</Heading>
          <Text style={text}>
            Bonne nouvelle ! Vous avez été invité à rejoindre{' '}
            <Link href={siteUrl} style={link}><strong>{siteName}</strong></Link>.
            Acceptez l'invitation pour créer votre compte et démarrer.
          </Text>
          <Section style={btnWrap}>
            <Button style={button} href={confirmationUrl}>Accepter l'invitation</Button>
          </Section>
          <Text style={smallText}>
            Ou copiez ce lien :<br />
            <Link href={confirmationUrl} style={link}>{confirmationUrl}</Link>
          </Text>
          <Hr style={hr} />
          <Text style={footer}>Vous n'attendiez pas cette invitation ? Ignorez cet email.</Text>
        </Section>
        <Text style={signature}>L'équipe {siteName}</Text>
      </Container>
    </Body>
  </Html>
)

export default InviteEmail

const main = { backgroundColor: '#ffffff', fontFamily: "'Poppins', Arial, sans-serif", margin: 0, padding: 0 }
const container = { maxWidth: '560px', margin: '0 auto', padding: '32px 16px' }
const header = { textAlign: 'center' as const, padding: '8px 0 24px' }
const brand = { fontSize: '26px', fontWeight: 800 as const, color: '#0B1E3F', margin: 0, letterSpacing: '0.5px' }
const tagline = { fontSize: '12px', color: '#6b7280', margin: '4px 0 0', textTransform: 'uppercase' as const, letterSpacing: '1.5px' }
const card = { backgroundColor: '#ffffff', border: '1px solid #e5e7eb', borderRadius: '14px', padding: '32px 28px' }
const h1 = { fontSize: '22px', fontWeight: 700 as const, color: '#0B1E3F', margin: '0 0 16px' }
const text = { fontSize: '15px', color: '#374151', lineHeight: '1.6', margin: '0 0 20px' }
const smallText = { fontSize: '12px', color: '#6b7280', lineHeight: '1.6', margin: '20px 0 0', wordBreak: 'break-all' as const }
const btnWrap = { textAlign: 'center' as const, margin: '8px 0 4px' }
const button = { background: 'linear-gradient(135deg, #D4A24C 0%, #B8862E 100%)', color: '#0B1E3F', fontSize: '15px', fontWeight: 700 as const, borderRadius: '10px', padding: '14px 28px', textDecoration: 'none', display: 'inline-block' }
const link = { color: '#0B1E3F', textDecoration: 'underline' }
const hr = { borderColor: '#e5e7eb', margin: '24px 0 16px' }
const footer = { fontSize: '12px', color: '#9ca3af', margin: 0 }
const signature = { fontSize: '12px', color: '#9ca3af', textAlign: 'center' as const, margin: '20px 0 0' }
