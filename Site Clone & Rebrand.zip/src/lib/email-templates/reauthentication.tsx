import * as React from 'react'

import {
  Body, Container, Head, Heading, Hr, Html, Preview, Section, Text,
} from '@react-email/components'

interface ReauthenticationEmailProps {
  token: string
}

export const ReauthenticationEmail = ({ token }: ReauthenticationEmailProps) => (
  <Html lang="fr" dir="ltr">
    <Head />
    <Preview>Votre code de vérification ZbossPay</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Text style={brand}>ZbossPay</Text>
          <Text style={tagline}>Paiement mobile en RDC</Text>
        </Section>
        <Section style={card}>
          <Heading style={h1}>Code de vérification 🔢</Heading>
          <Text style={text}>Utilisez le code ci-dessous pour confirmer votre identité :</Text>
          <Text style={codeStyle}>{token}</Text>
          <Hr style={hr} />
          <Text style={footer}>
            Ce code expire dans quelques minutes. Vous n'êtes pas à l'origine de la demande ? Ignorez cet email.
          </Text>
        </Section>
        <Text style={signature}>L'équipe ZbossPay</Text>
      </Container>
    </Body>
  </Html>
)

export default ReauthenticationEmail

const main = { backgroundColor: '#ffffff', fontFamily: "'Poppins', Arial, sans-serif", margin: 0, padding: 0 }
const container = { maxWidth: '560px', margin: '0 auto', padding: '32px 16px' }
const header = { textAlign: 'center' as const, padding: '8px 0 24px' }
const brand = { fontSize: '26px', fontWeight: 800 as const, color: '#0B1E3F', margin: 0, letterSpacing: '0.5px' }
const tagline = { fontSize: '12px', color: '#6b7280', margin: '4px 0 0', textTransform: 'uppercase' as const, letterSpacing: '1.5px' }
const card = { backgroundColor: '#ffffff', border: '1px solid #e5e7eb', borderRadius: '14px', padding: '32px 28px', textAlign: 'center' as const }
const h1 = { fontSize: '22px', fontWeight: 700 as const, color: '#0B1E3F', margin: '0 0 16px' }
const text = { fontSize: '15px', color: '#374151', lineHeight: '1.6', margin: '0 0 16px' }
const codeStyle = { fontFamily: 'Courier, monospace', fontSize: '34px', fontWeight: 800 as const, color: '#0B1E3F', letterSpacing: '8px', background: '#FFF7E6', padding: '16px 20px', borderRadius: '10px', display: 'inline-block', margin: '8px 0 16px' }
const hr = { borderColor: '#e5e7eb', margin: '24px 0 16px' }
const footer = { fontSize: '12px', color: '#9ca3af', margin: 0 }
const signature = { fontSize: '12px', color: '#9ca3af', textAlign: 'center' as const, margin: '20px 0 0' }
