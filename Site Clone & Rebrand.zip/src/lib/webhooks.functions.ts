import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const configSchema = z.object({
  webhook_url: z.string().url().max(500).nullable(),
});

/** Charge la configuration webhook du marchand connecté. */
export const getMyWebhookConfig = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("profiles")
      .select("webhook_url, webhook_secret")
      .eq("id", context.userId)
      .maybeSingle();
    if (error) {
      console.error("[webhooks:get]", error.message);
      throw new Error("Impossible de charger la configuration webhook");
    }
    return {
      webhook_url: data?.webhook_url ?? null,
      has_secret: Boolean(data?.webhook_secret),
      // On expose le secret UNIQUEMENT au propriétaire authentifié.
      webhook_secret: data?.webhook_secret ?? null,
    };
  });

/** Enregistre l'URL webhook du marchand. */
export const setMyWebhookUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => configSchema.parse(input))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("profiles")
      .update({ webhook_url: data.webhook_url })
      .eq("id", context.userId);
    if (error) {
      console.error("[webhooks:setUrl]", error.message);
      throw new Error("Mise à jour impossible");
    }
    return { ok: true };
  });

/** (Re)génère un secret HMAC-SHA256 pour ce marchand. */
export const rotateMyWebhookSecret = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { randomBytes } = await import("node:crypto");
    const secret = "whsec_" + randomBytes(32).toString("hex");
    const { error } = await context.supabase
      .from("profiles")
      .update({ webhook_secret: secret })
      .eq("id", context.userId);
    if (error) {
      console.error("[webhooks:rotate]", error.message);
      throw new Error("Rotation impossible");
    }
    return { webhook_secret: secret };
  });

/**
 * Envoie un événement de test signé HMAC-SHA256 au webhook configuré.
 * Format signature: `t=<unix>,v1=<hex>` sur `${timestamp}.${payloadJson}`.
 */
export const sendTestWebhook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { createHmac } = await import("node:crypto");
    const { data: profile, error } = await context.supabase
      .from("profiles")
      .select("webhook_url, webhook_secret")
      .eq("id", context.userId)
      .maybeSingle();
    if (error) throw new Error("Impossible de charger le profil");
    if (!profile?.webhook_url || !profile.webhook_secret) {
      throw new Error("Configurez d'abord une URL et un secret webhook.");
    }

    const payload = {
      event: "test.ping",
      transaction_id: "tx_test_" + Math.random().toString(36).slice(2, 10),
      merchant_id: context.userId,
      amount: 1000,
      currency: "CDF",
      status: "SUCCESS",
      created_at: new Date().toISOString(),
    };
    const body = JSON.stringify(payload);
    const ts = Math.floor(Date.now() / 1000);
    const signature = createHmac("sha256", profile.webhook_secret)
      .update(`${ts}.${body}`)
      .digest("hex");

    try {
      const res = await fetch(profile.webhook_url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-ZbossPay-Signature": `t=${ts},v1=${signature}`,
        },
        body,
      });
      return { ok: res.ok, status: res.status, payload };
    } catch (err) {
      console.error("[webhooks:sendTest]", err);
      return { ok: false, status: 0, error: (err as Error).message, payload };
    }
  });
