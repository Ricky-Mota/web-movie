import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Allowlist of trusted application origins for Stripe redirect URLs.
// Never derived from request headers (Host/x-forwarded-proto are attacker-controllable).
const TRUSTED_ORIGINS = [
  "https://zbosspay.cd",
  "https://www.zbosspay.cd",
  "https://www.infozbosspay.shop",
  "https://infozbosspay.shop",
  "https://clone-champ-v2.lovable.app",
] as const;

function appOrigin(): string {
  const configured = process.env.APP_ORIGIN?.trim();
  if (configured && TRUSTED_ORIGINS.includes(configured as (typeof TRUSTED_ORIGINS)[number])) {
    return configured;
  }
  return TRUSTED_ORIGINS[0];
}

function dbFail(scope: string, err: { message?: string } | null | undefined): never {
  console.error(`[payments:${scope}]`, err?.message ?? err);
  throw new Error("Une erreur est survenue. Réessayez plus tard.");
}

/**
 * Crée (si besoin) un compte Stripe Connect Express pour le marchand connecté,
 * puis renvoie un lien d'onboarding Stripe.
 */
export const createConnectOnboardingLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { getStripe } = await import("./stripe.server");
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const stripe = getStripe();
    const userId = context.userId;

    const { data: profile, error: profErr } = await supabaseAdmin
      .from("profiles")
      .select("id, email, stripe_account_id")
      .eq("id", userId)
      .maybeSingle();
    if (profErr) dbFail("profile", profErr);

    let accountId = profile?.stripe_account_id ?? null;

    if (!accountId) {
      const account = await stripe.accounts.create({
        type: "express",
        email: profile?.email ?? undefined,
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        metadata: { merchant_user_id: userId },
      });
      accountId = account.id;
      await supabaseAdmin
        .from("profiles")
        .update({ stripe_account_id: accountId })
        .eq("id", userId);
    }

    const origin = appOrigin();
    const link = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: `${origin}/dashboard?onboarding=refresh`,
      return_url: `${origin}/dashboard?onboarding=complete`,
      type: "account_onboarding",
    });

    return { url: link.url, accountId };
  });

/**
 * Rafraîchit le statut du compte Stripe Connect dans la base.
 */
export const refreshConnectAccountStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { getStripe } = await import("./stripe.server");
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const stripe = getStripe();

    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("stripe_account_id")
      .eq("id", context.userId)
      .maybeSingle();

    if (!profile?.stripe_account_id) {
      return { connected: false };
    }

    const account = await stripe.accounts.retrieve(profile.stripe_account_id);
    await supabaseAdmin
      .from("profiles")
      .update({
        stripe_charges_enabled: account.charges_enabled,
        stripe_payouts_enabled: account.payouts_enabled,
        stripe_details_submitted: account.details_submitted,
      })
      .eq("id", context.userId);

    return {
      connected: true,
      charges_enabled: account.charges_enabled,
      payouts_enabled: account.payouts_enabled,
      details_submitted: account.details_submitted,
    };
  });

/**
 * Crée une Checkout Session Stripe avec commission ZbossPay (3%).
 * Le paiement est routé vers le compte Stripe du marchand connecté.
 */
const checkoutInputSchema = z.object({
  amount: z.number().positive().max(10_000_000), // en cents
  currency: z.string().min(3).max(3).default("eur"),
  description: z.string().min(1).max(200),
  customer_email: z.string().email().optional().nullable(),
});

export const createCheckoutSession = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => checkoutInputSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { getStripe, computeFee } = await import("./stripe.server");
    const { assertKycApproved } = await import("./kyc.server");
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );

    // 🔒 KYC requis pour tout encaissement réel
    await assertKycApproved(context.userId);

    const stripe = getStripe();

    const { data: profile, error: profErr } = await supabaseAdmin
      .from("profiles")
      .select("stripe_account_id, stripe_charges_enabled")
      .eq("id", context.userId)
      .maybeSingle();
    if (profErr) dbFail("profile", profErr);
    if (!profile?.stripe_account_id || !profile.stripe_charges_enabled) {
      throw new Error(
        "Votre compte Stripe Connect n'est pas encore prêt à encaisser. Terminez l'onboarding Stripe.",
      );
    }


    const fee = computeFee(data.amount);
    const origin = appOrigin();

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items: [
        {
          quantity: 1,
          price_data: {
            currency: data.currency,
            unit_amount: data.amount,
            product_data: { name: data.description },
          },
        },
      ],
      customer_email: data.customer_email ?? undefined,
      payment_intent_data: {
        application_fee_amount: fee,
        transfer_data: { destination: profile.stripe_account_id },
        metadata: {
          merchant_user_id: context.userId,
        },
      },
      success_url: `${origin}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/payment/cancel`,
      metadata: {
        merchant_user_id: context.userId,
      },
    });

    const { error: insErr } = await supabaseAdmin.from("transactions").insert({
      merchant_id: context.userId,
      description: data.description,
      customer_email: data.customer_email ?? null,
      amount_total: data.amount,
      application_fee_amount: fee,
      currency: data.currency,
      status: "pending",
      stripe_checkout_session_id: session.id,
    });
    if (insErr) dbFail("tx-insert", insErr);

    return { url: session.url, sessionId: session.id };
  });

export const listMyTransactions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("transactions")
      .select(
        "id, description, customer_email, amount_total, application_fee_amount, currency, status, created_at",
      )
      .eq("merchant_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) dbFail("query", error);
    return data ?? [];
  });

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("profiles")
      .select(
        "id, email, display_name, stripe_account_id, stripe_charges_enabled, stripe_payouts_enabled, stripe_details_submitted",
      )
      .eq("id", context.userId)
      .maybeSingle();
    if (error) dbFail("query", error);
    return data;
  });

/**
 * Compte commun ZbossPay (aggregator).
 * Garantit qu'une ligne `merchant_provider_connections` existe pour le marchand
 * connecté avec le provider `depot-commun`, puis renvoie son statut.
 * Permet au marchand d'encaisser dépôts/paiements via le compte agrégé sans
 * configuration partenaire.
 */
export const getDepotCommunStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );

    const { data: provider, error: pErr } = await supabaseAdmin
      .from("providers")
      .select("id, name, logo_emoji, brand_color")
      .eq("slug", "depot-commun")
      .maybeSingle();
    if (pErr) dbFail("provider", pErr);
    if (!provider) {
      return { available: false as const };
    }

    // Idempotent: insère la ligne si manquante (trigger handle_new_user
    // a pu être ajouté après l'inscription du marchand).
    const { data: existing, error: selErr } = await supabaseAdmin
      .from("merchant_provider_connections")
      .select("status, environment, last_test_status, last_test_message, created_at")
      .eq("merchant_id", context.userId)
      .eq("provider_id", provider.id)
      .maybeSingle();
    if (selErr) dbFail("conn-select", selErr);

    let conn = existing;
    if (!conn) {
      const { data: inserted, error: insErr } = await supabaseAdmin
        .from("merchant_provider_connections")
        .insert({
          merchant_id: context.userId,
          provider_id: provider.id,
          environment: "live",
          status: "active",
          credentials: {},
          credentials_masked: {},
          last_test_status: "ok",
          last_test_message: "Compte agrégé ZbossPay activé automatiquement",
        })
        .select("status, environment, last_test_status, last_test_message, created_at")
        .maybeSingle();
      if (insErr) dbFail("conn-insert", insErr);
      conn = inserted;
    }

    return {
      available: true as const,
      provider: {
        name: provider.name,
        logo_emoji: provider.logo_emoji,
        brand_color: provider.brand_color,
      },
      status: conn?.status ?? "active",
      environment: conn?.environment ?? "live",
      message:
        conn?.last_test_message ??
        "Compte agrégé ZbossPay opérationnel.",
      since: conn?.created_at ?? null,
    };
  });
