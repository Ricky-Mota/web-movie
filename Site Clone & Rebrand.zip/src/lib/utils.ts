import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const PENDING_REDIRECT_KEY = "zbosspay_pending_redirect";

type PendingRedirect = {
  message: string;
};

export function getPendingRedirect(): PendingRedirect | null {
  try {
    const raw = localStorage.getItem(PENDING_REDIRECT_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as PendingRedirect;
  } catch {
    return null;
  }
}

export function setPendingRedirect(message: string) {
  try {
    localStorage.setItem(PENDING_REDIRECT_KEY, JSON.stringify({ message }));
  } catch {
    // ignore storage errors
  }
}

export function clearPendingRedirect() {
  try {
    localStorage.removeItem(PENDING_REDIRECT_KEY);
  } catch {
    // ignore storage errors
  }
}
