/**
 * Airtel Money API helpers (server-only).
 * Doc: https://developers.airtel.africa/
 *
 * Endpoints utilisés :
 *  - POST {base}/auth/oauth2/token                       -> récupère le bearer token
 *  - POST {base}/merchant/v1/payments/                   -> initie une collection (USSD push)
 *  - GET  {base}/standard/v1/payments/{externalRef}      -> vérifie le statut
 */

export type AirtelCreds = {
  merchant_id: string;
  client_id: string;
  client_secret: string;
  base_url: string;        // ex: https://openapiuat.airtel.africa (sandbox) | https://openapi.airtel.africa (live)
  callback_secret: string; // HMAC SHA-256 partagé pour vérifier les webhooks
};

const COUNTRY = "CD";
const CURRENCY = "CDF";

function cleanBase(url: string): string {
  return url.replace(/\/+$/, "");
}

async function getAccessToken(creds: AirtelCreds): Promise<string> {
  const res = await fetch(`${cleanBase(creds.base_url)}/auth/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "*/*" },
    body: JSON.stringify({
      client_id: creds.client_id,
      client_secret: creds.client_secret,
      grant_type: "client_credentials",
    }),
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`Airtel auth failed (${res.status}): ${text.slice(0, 300)}`);
  }
  const json = JSON.parse(text) as { access_token?: string };
  if (!json.access_token) throw new Error("Airtel auth: pas de access_token reçu");
  return json.access_token;
}

export type InitiateInput = {
  amount: number;            // entier dans la devise (CDF)
  msisdn: string;            // numéro client, ex: 99XXXXXXX (sans +243)
  externalReference: string; // notre référence unique
  description?: string;
};

export type InitiateResult = {
  ok: boolean;
  httpStatus: number;
  providerReference?: string;
  message: string;
  raw: unknown;
};

export async function initiateCollection(
  creds: AirtelCreds,
  input: InitiateInput,
): Promise<InitiateResult> {
  const token = await getAccessToken(creds);
  const res = await fetch(`${cleanBase(creds.base_url)}/merchant/v1/payments/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "*/*",
      "X-Country": COUNTRY,
      "X-Currency": CURRENCY,
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      reference: input.description ?? "ZbossPay",
      subscriber: { country: COUNTRY, currency: CURRENCY, msisdn: input.msisdn },
      transaction: {
        amount: input.amount,
        country: COUNTRY,
        currency: CURRENCY,
        id: input.externalReference,
      },
    }),
  });
  const text = await res.text();
  let parsed: unknown = text;
  try { parsed = JSON.parse(text); } catch { /* keep raw */ }

  const p = parsed as { status?: { success?: boolean; message?: string; code?: string }; data?: { transaction?: { id?: string } } };
  return {
    ok: res.ok && (p?.status?.success ?? true),
    httpStatus: res.status,
    providerReference: p?.data?.transaction?.id,
    message: p?.status?.message ?? (res.ok ? "OK" : `HTTP ${res.status}`),
    raw: parsed,
  };
}

export type StatusResult = {
  httpStatus: number;
  status: "pending" | "processing" | "succeeded" | "failed" | "cancelled";
  message: string;
  raw: unknown;
};

export async function queryStatus(
  creds: AirtelCreds,
  externalReference: string,
): Promise<StatusResult> {
  const token = await getAccessToken(creds);
  const res = await fetch(
    `${cleanBase(creds.base_url)}/standard/v1/payments/${encodeURIComponent(externalReference)}`,
    {
      method: "GET",
      headers: {
        Accept: "*/*",
        "X-Country": COUNTRY,
        "X-Currency": CURRENCY,
        Authorization: `Bearer ${token}`,
      },
    },
  );
  const text = await res.text();
  let parsed: unknown = text;
  try { parsed = JSON.parse(text); } catch { /* keep raw */ }
  const p = parsed as {
    data?: { transaction?: { status?: string; message?: string } };
    status?: { message?: string };
  };
  const raw = (p?.data?.transaction?.status ?? "").toUpperCase();
  const status: StatusResult["status"] =
    raw === "TS" || raw === "SUCCESS" || raw === "SUCCESSFUL" ? "succeeded"
    : raw === "TF" || raw === "FAILED" ? "failed"
    : raw === "TA" || raw === "CANCELLED" || raw === "EXPIRED" ? "cancelled"
    : raw === "IN_PROGRESS" || raw === "PROCESSING" ? "processing"
    : "pending";
  return {
    httpStatus: res.status,
    status,
    message: p?.data?.transaction?.message ?? p?.status?.message ?? raw ?? "",
    raw: parsed,
  };
}

/** Vérifie une signature HMAC SHA-256 (hex) sur le corps brut du webhook. */
export async function verifyWebhookSignature(
  secret: string,
  rawBody: string,
  signatureHex: string,
): Promise<boolean> {
  if (!secret || !signatureHex) return false;
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(rawBody));
  const hex = Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  // timing-safe compare
  if (hex.length !== signatureHex.length) return false;
  let diff = 0;
  for (let i = 0; i < hex.length; i++) {
    diff |= hex.charCodeAt(i) ^ signatureHex.charCodeAt(i);
  }
  return diff === 0;
}
