import * as React from 'react'
import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import {
  APP_EMAIL,
  APP_EMAIL_SENDER,
  APP_EMAIL_SENDER_DOMAIN,
} from '@/lib/site-config'

const contactSchema = z.object({
  name: z.string().min(2, 'Votre nom doit faire au moins 2 caractères.'),
  email: z.string().email('Veuillez entrer une adresse email valide.'),
  company: z.string().optional(),
  message: z.string().min(10, 'Votre message doit faire au moins 10 caractères.'),
})

export const sendContactMessage = createServerFn({ method: 'POST' })
  .validator((input: unknown) => contactSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import(
      '@/integrations/supabase/client.server'
    )
    const [{ render }, { ContactNotificationEmail }] = await Promise.all([
      import('react-email'),
      import('@/lib/email-templates/contact-notification'),
    ])

    const html = await render(
      React.createElement(ContactNotificationEmail, data),
      { pretty: true }
    )
    const text = await render(
      React.createElement(ContactNotificationEmail, data),
      { plainText: true }
    )

    const messageId = crypto.randomUUID()
    const { error: enqueueError } = await supabaseAdmin.rpc('enqueue_email', {
      queue_name: 'transactional_emails',
      payload: {
        run_id: messageId,
        message_id: messageId,
        to: APP_EMAIL,
        from: APP_EMAIL_SENDER,
        sender_domain: APP_EMAIL_SENDER_DOMAIN,
        reply_to: data.email,
        subject: `Nouveau message de ${data.name} — ZbossPay`,
        html,
        text,
        purpose: 'transactional',
        label: 'contact_form',
        queued_at: new Date().toISOString(),
      },
    })

    if (enqueueError) {
      console.error(
        '[contact:send] Failed to enqueue contact email',
        enqueueError
      )
      throw new Error("Impossible d'envoyer le message. Réessayez plus tard.")
    }

    return { ok: true }
  })
