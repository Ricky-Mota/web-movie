import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requireRole } from "@/integrations/supabase/require-role";

function dbFail(scope: string, err: { message?: string } | null | undefined): never {
  console.error(`[admin:${scope}]`, err?.message ?? err);
  throw new Error("Une erreur est survenue. Réessayez plus tard.");
}

/** Returns the roles assigned to the current authenticated user. */
export const getMyRoles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", context.userId);
    if (error) dbFail("query", error);
    return (data ?? []).map((r) => r.role);
  });

/** Admin-only: list every transaction across all merchants. */
export const adminListAllTransactions = createServerFn({ method: "GET" })
  .middleware([requireRole("admin")])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("transactions")
      .select(
        "id, merchant_id, description, customer_email, amount_total, application_fee_amount, currency, status, created_at",
      )
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) dbFail("query", error);
    return data ?? [];
  });

const grantSchema = z.object({
  user_id: z.string().uuid(),
  role: z.enum(["admin", "moderator", "user"]),
});

/** Admin-only: grant a role to another user. */
export const adminGrantRole = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .validator((input: unknown) => grantSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: data.user_id, role: data.role });
    if (error && !/duplicate key/i.test(error.message)) dbFail("grant", error);
    return { ok: true };
  });

/** Admin-only: revoke a role from a user. */
export const adminRevokeRole = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .validator((input: unknown) => grantSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .delete()
      .eq("user_id", data.user_id)
      .eq("role", data.role);
    if (error) dbFail("revoke", error);
    return { ok: true };
  });
