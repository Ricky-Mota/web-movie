/**
 * Global security headers applied to every response served by the application.
 * These headers are intentionally set in code so that even if a CDN/HSTS
 * misconfiguration occurs, the application still instructs browsers to always
 * use HTTPS.
 */
export const SECURITY_HEADERS = {
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
} as const;

/**
 * Clone a response and inject the security headers.
 * Safe to call on responses that already include the headers (idempotent).
 */
export function applySecurityHeaders(response: Response): Response {
  const headers = new Headers(response.headers);
  for (const [name, value] of Object.entries(SECURITY_HEADERS)) {
    headers.set(name, value);
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

/**
 * Skip security headers on localhost to avoid breaking HTTP-only dev environments.
 */
export function isLocalhost(url: string): boolean {
  const { hostname } = new URL(url);
  return hostname === "localhost" || hostname === "127.0.0.1";
}
