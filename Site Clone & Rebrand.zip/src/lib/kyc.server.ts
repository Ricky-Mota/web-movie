// Server-only helper : vérifie que le marchand a un dossier KYC approuvé
// avant d'autoriser une activation/encaissement en production.

export async function assertKycApproved(userId: string): Promise<void> {
  const { supabaseAdmin } = await import(
    "@/integrations/supabase/client.server"
  );
  const { data, error } = await supabaseAdmin
    .from("merchant_kyc")
    .select("status")
    .eq("user_id", userId)
    .maybeSingle();

  if (error) {
    console.error("[kyc:assert]", error.message);
    throw new Error("Impossible de vérifier votre dossier KYC. Réessayez.");
  }

  if (!data) {
    throw new Error(
      "KYC requis : complétez votre dossier marchand (RCCM, NIF, pièce d'identité) avant d'activer les paiements réels.",
    );
  }

  if (data.status === "pending") {
    throw new Error(
      "Votre dossier KYC est en cours d'examen (24-48h ouvrées). L'activation des paiements réels sera débloquée dès l'approbation.",
    );
  }

  if (data.status === "rejected") {
    throw new Error(
      "Dossier KYC rejeté. Corrigez les informations sur /kyc et resoumettez avant d'activer les paiements réels.",
    );
  }

  if (data.status !== "approved") {
    throw new Error("KYC non approuvé.");
  }
}
