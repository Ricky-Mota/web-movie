import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requireRole } from "@/integrations/supabase/require-role";

function dbFail(scope: string, err: { message?: string } | null | undefined): never {
  console.error(`[kyc:${scope}]`, err?.message ?? err);
  throw new Error("Une erreur est survenue. Réessayez plus tard.");
}

/** Renvoie le dossier KYC du marchand connecté (ou null). */
export const getMyKyc = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("merchant_kyc")
      .select("*")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (error) dbFail("get", error);
    return data;
  });

const submitSchema = z.object({
  entity_type: z.enum(["individual", "company"]),
  legal_name: z.string().trim().min(2).max(150),
  rccm_number: z.string().trim().min(3).max(50),
  nif_number: z.string().trim().min(3).max(50),
  id_number: z.string().trim().min(3).max(50),
  phone: z.string().trim().min(7).max(20),
  address: z.string().trim().min(3).max(200),
  city: z.string().trim().min(2).max(80),
  country: z.string().trim().length(2).default("CD"),
  rccm_doc_url: z.string().trim().min(1).max(500),
  nif_doc_url: z.string().trim().min(1).max(500),
  id_doc_url: z.string().trim().min(1).max(500),
  selfie_url: z.string().trim().min(1).max(500),
});

/** Soumet ou met à jour le dossier KYC (statut repasse en pending). */
export const submitKyc = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => submitSchema.parse(input))
  .handler(async ({ data, context }) => {
    const payload = {
      ...data,
      user_id: context.userId,
      status: "pending" as const,
      rejection_reason: null,
      reviewed_by: null,
      reviewed_at: null,
      submitted_at: new Date().toISOString(),
    };
    const { error } = await context.supabase
      .from("merchant_kyc")
      .upsert(payload, { onConflict: "user_id" });
    if (error) dbFail("submit", error);
    return { ok: true };
  });

/** Admin : liste tous les dossiers KYC. */
export const adminListKyc = createServerFn({ method: "GET" })
  .middleware([requireRole("admin")])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("merchant_kyc")
      .select("*")
      .order("submitted_at", { ascending: false })
      .limit(200);
    if (error) dbFail("admin-list", error);
    return data ?? [];
  });

const reviewSchema = z.object({
  kyc_id: z.string().uuid(),
  decision: z.enum(["approved", "rejected"]),
  reason: z.string().trim().max(500).optional(),
});

/** Admin : approuve ou rejette un dossier. */
export const adminReviewKyc = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .validator((input: unknown) => reviewSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("merchant_kyc")
      .update({
        status: data.decision,
        rejection_reason: data.decision === "rejected" ? (data.reason ?? "Non précisé") : null,
        reviewed_by: context.userId,
        reviewed_at: new Date().toISOString(),
      })
      .eq("id", data.kyc_id);
    if (error) dbFail("review", error);
    return { ok: true };
  });

/** Admin : URL signée temporaire pour télécharger un document KYC. */
export const adminSignKycDoc = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .validator((input: unknown) =>
    z.object({ path: z.string().trim().min(1).max(500) }).parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: signed, error } = await supabaseAdmin.storage
      .from("kyc-documents")
      .createSignedUrl(data.path, 300);
    if (error || !signed) dbFail("sign", error);
    return { url: signed!.signedUrl };
  });
