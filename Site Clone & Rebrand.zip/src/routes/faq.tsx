import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "../components/site/Layout";
import ogImage from "../assets/og-faq.jpg";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — ZbossPay" },
      { name: "description", content: "Réponses aux questions fréquentes sur ZbossPay : intégration, sécurité, frais, opérateurs et plus." },
      { property: "og:title", content: "FAQ ZbossPay" },
      { property: "og:description", content: "Réponses aux questions fréquentes sur ZbossPay : intégration, sécurité, frais, opérateurs et plus." },
      { property: "og:url", content: "/faq" },
      { property: "og:image", content: ogImage },
      { property: "og:image:width", content: "1216" },
      { property: "og:image:height", content: "640" },
      { property: "og:image:alt", content: "FAQ ZbossPay" },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: "/faq" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: faqs.map(([q, a]) => ({
          "@type": "Question",
          name: q,
          acceptedAnswer: { "@type": "Answer", text: a },
        })),
      }),
    }],
  }),
  component: FaqPage,
});

const faqs = [
  ["Qu'est-ce que ZbossPay et à qui s'adresse-t-il ?", "ZbossPay est une plateforme de paiement conçue pour les entreprises, commerçants et institutions de la RDC. Elle permet d'encaisser des paiements (C2B) et de distribuer des fonds (B2C) via Airtel Money, Orange Money, M-Pesa, Afrimoney et carte bancaire."],
  ["Quels opérateurs mobile money sont pris en charge ?", "ZbossPay est connecté aux cinq réseaux actifs en RDC : Airtel Money, Orange Money, M-Pesa, Afrimoney et les paiements par carte (Visa / Mastercard) — accessibles via une seule intégration API."],
  ["Combien de temps faut-il pour commencer à accepter des paiements ?", "L'intégration standard prend moins de 48 heures : création de compte, validation KYB sous 24 h, génération des clés API et tests en sandbox, puis activation en production."],
  ["ZbossPay est-il sécurisé ?", "Toutes les transactions sont chiffrées en TLS 1.3, les clés API protégées par AES-256, et la plateforme hébergée sur des serveurs conformes ISO 27001."],
  ["Quels langages sont supportés par l'API ?", "L'API ZbossPay est REST/JSON, compatible avec tout langage HTTP : PHP, Python, Node.js, Java, Ruby, Go, .NET. Documentation et exemples disponibles."],
  ["Puis-je tester l'API sans impacter les vrais comptes ?", "Oui. ZbossPay fournit un environnement sandbox complet avec des clés séparées et des numéros de test simulant les réponses des opérateurs."],
  ["Comment fonctionnent les webhooks ?", "À chaque changement de statut, ZbossPay envoie un POST signé HMAC-SHA256 vers l'URL de votre choix, avec 3 tentatives en cas d'échec."],
  ["Y a-t-il des limites de débit (rate limiting) ?", "Le plan standard autorise 500 requêtes/minute. Les plans Entreprise peuvent monter jusqu'à 10 000 req/min."],
  ["Quels sont les frais de transaction ?", "Aucun frais d'installation ni d'abonnement. Vous ne payez que sur les transactions réussies. Contactez-nous pour un devis adapté à votre volume."],
  ["Dans quel délai les fonds sont-ils disponibles ?", "Les fonds sont disponibles en temps réel sur votre compte ZbossPay. Le virement bancaire s'effectue sous 24 à 48 heures ouvrées."],
  ["Quel niveau de support est inclus ?", "Support email et chat sous 4 h ouvrées pour tous. Les comptes Entreprise bénéficient d'un support 24/7 avec un responsable technique dédié."],
  ["Que se passe-t-il si une transaction échoue ?", "ZbossPay retourne un code d'erreur précis et aucun débit n'est effectué. Vous pouvez relancer depuis le portail ou via l'API."],
];

function FaqPage() {
  return (
    <SiteLayout>
      <section className="gradient-brand text-white">
        <div className="container-page py-16">
          <span className="chip bg-white/15 text-white border-white/20">FAQ</span>
          <h1 className="mt-4 text-4xl md:text-5xl font-bold">Questions fréquentes</h1>
        </div>
      </section>

      <section className="container-page py-14 max-w-3xl">
        <div className="divide-y rounded-2xl border bg-card">
          {faqs.map(([q, a]) => (
            <details key={q} className="group p-5 open:bg-[var(--muted)]">
              <summary className="cursor-pointer font-semibold list-none flex justify-between gap-4">
                {q}
                <span className="text-[var(--cta)] group-open:rotate-45 transition">+</span>
              </summary>
              <p className="mt-3 text-sm text-muted-foreground">{a}</p>
            </details>
          ))}
        </div>
        <div className="mt-10 text-center">
          <p className="text-muted-foreground">Vous avez une autre question ?</p>
          <Link to="/contact" className="mt-3 inline-block rounded-full gradient-brand text-white px-6 py-3 font-semibold">Nous contacter</Link>
        </div>
      </section>
    </SiteLayout>
  );
}
