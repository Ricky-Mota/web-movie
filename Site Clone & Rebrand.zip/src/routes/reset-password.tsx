import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "../components/site/Layout";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Nouveau mot de passe — ZbossPay" },
      { name: "description", content: "Définissez un nouveau mot de passe pour votre compte ZbossPay." },
      { name: "robots", content: "noindex" },
    ],
    links: [{ rel: "canonical", href: "/reset-password" }],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [validLink, setValidLink] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Supabase délivre une session de récupération via le hash de l'URL.
    // onAuthStateChange émet PASSWORD_RECOVERY quand le lien est valide.
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || (event === "SIGNED_IN" && session)) {
        setValidLink(true);
        setReady(true);
      }
    });
    // Fallback : vérifier une session existante (lien déjà consommé dans cette page)
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) setValidLink(true);
      setReady(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password.length < 6) return setError("Mot de passe trop court (6 caractères min).");
    if (password !== confirm) return setError("Les mots de passe ne correspondent pas.");
    setLoading(true);
    try {
      const { error: e2 } = await supabase.auth.updateUser({ password });
      if (e2) throw e2;
      router.navigate({ to: "/reset-confirmed", search: { type: "password" } as never });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SiteLayout>
      <section className="container-page py-16 max-w-md">
        <div className="rounded-2xl border bg-card p-7">
          <h1 className="text-2xl font-bold">Nouveau mot de passe</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Choisissez un nouveau mot de passe pour votre compte.
          </p>

          {!ready ? (
            <p className="mt-6 text-sm text-muted-foreground">Vérification du lien…</p>
          ) : !validLink ? (
            <div className="mt-6 space-y-4">
              <div className="rounded-lg border border-orange-200 bg-orange-50 p-4 text-sm text-orange-800">
                ⚠️ Lien invalide, expiré ou déjà utilisé. Demandez-en un nouveau.
              </div>
              <Link
                to="/forgot-password"
                className="block text-center rounded-full gradient-brand text-white px-6 py-3 font-semibold"
              >
                Demander un nouveau lien
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="grid gap-4 mt-6">
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Nouveau mot de passe</span>
                <input
                  required
                  type="password"
                  minLength={6}
                  autoFocus
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="rounded-lg border px-3 py-2.5 bg-background"
                />
              </label>
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Confirmer</span>
                <input
                  required
                  type="password"
                  minLength={6}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  className="rounded-lg border px-3 py-2.5 bg-background"
                />
              </label>
              <button
                disabled={loading}
                className="rounded-full gradient-brand text-white px-6 py-3 font-semibold disabled:opacity-60"
              >
                {loading ? "…" : "Mettre à jour"}
              </button>
              {error && <p className="text-sm text-red-600 text-center">{error}</p>}
            </form>
          )}
        </div>
      </section>
    </SiteLayout>
  );
}
