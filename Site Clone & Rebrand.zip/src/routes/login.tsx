import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { SiteLayout } from "../components/site/Layout";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { clearPendingRedirect, getPendingRedirect, setPendingRedirect } from "@/lib/utils";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Connexion — ZbossPay" },
      {
        name: "description",
        content:
          "Créez votre compte ZbossPay gratuit ou connectez-vous pour encaisser des paiements.",
      },
      { property: "og:title", content: "Connexion ZbossPay" },
      { property: "og:description", content: "Accédez à votre espace ZbossPay." },
      { property: "og:url", content: "/login" },
    ],
    links: [{ rel: "canonical", href: "/login" }],
  }),
  component: LoginPage,
});

function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [redirecting, setRedirecting] = useState(false);
  const [redirectMessage, setRedirectMessage] = useState("Connexion en cours…");

  const redirectAfterAuth = useCallback(async (userId: string, message: string) => {
    try {
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin")
        .maybeSingle();
      const target = data ? "/admin" : "/dashboard";
      setPendingRedirect(message);
      router.navigate({ to: target, replace: true });
    } catch {
      setPendingRedirect(message);
      router.navigate({ to: "/dashboard", replace: true });
    }
  }, [router]);

  useEffect(() => {
    let mounted = true;
    const pending = getPendingRedirect();
    supabase.auth.getUser().then(({ data, error }) => {
      if (!mounted) return;
      if (error || !data.user) {
        clearPendingRedirect();
        return;
      }
      if (pending) {
        setRedirecting(true);
        setRedirectMessage(pending.message);
        redirectAfterAuth(data.user.id, pending.message);
        return;
      }
      setRedirecting(true);
      setRedirectMessage("Vous êtes connecté. Redirection en cours…");
      redirectAfterAuth(data.user.id, "Vous êtes connecté. Redirection en cours…");
    });
    return () => {
      mounted = false;
    };
  }, [router, redirectAfterAuth]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || redirecting) return;
    setError(null);
    setLoading(true);
    try {
      if (mode === "signup") {
        const { data, error: e2 } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: { full_name: fullName || email.split("@")[0] },
          },
        });
        if (e2) {
          // Compte déjà existant → bascule automatiquement en connexion
          if (/already|exist|registered/i.test(e2.message)) {
            const { error: e3 } = await supabase.auth.signInWithPassword({ email, password });
            if (e3) throw new Error("Ce compte existe déjà. Mot de passe incorrect.");
          } else {
            throw e2;
          }
        } else if (!data?.session) {
          // Si l'auto-confirm est actif, signUp renvoie déjà une session, sinon on tente une connexion immédiate
          await supabase.auth.signInWithPassword({ email, password }).catch(() => null);
        }
      } else {
        const { error: e2 } = await supabase.auth.signInWithPassword({ email, password });
        if (e2) throw e2;
      }
      const { data: u } = await supabase.auth.getUser();
      if (u.user) {
        setRedirecting(true);
        const message =
          mode === "signup"
            ? "Compte créé avec succès. Préparation de votre espace…"
            : "Connexion réussie. Redirection vers votre espace…";
        setRedirectMessage(message);
        await redirectAfterAuth(u.user.id, message);
      } else {
        setRedirecting(true);
        const message = "Vérification de votre compte…";
        setRedirectMessage(message);
        setPendingRedirect(message);
        router.navigate({ to: "/dashboard", replace: true });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    if (redirecting) return;
    setError(null);
    setRedirecting(true);
    const message = "Connexion avec Google en cours…";
    setRedirectMessage(message);
    setPendingRedirect(message);
    try {
      await lovable.auth.signInWithOAuth("google", {
        redirect_uri: `${window.location.origin}/login`,
      });
    } catch (err) {
      clearPendingRedirect();
      setRedirecting(false);
      setError(err instanceof Error ? err.message : "Erreur Google");
    }
  };

  return (
    <SiteLayout>
      <section className="container-page py-16 max-w-md">
        <div className="relative rounded-2xl border bg-card p-7 overflow-hidden">
          {redirecting && (
            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-card/95 backdrop-blur-sm p-6 text-center">
              <div className="relative mb-4">
                <div className="w-12 h-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                <div className="absolute inset-0 m-auto w-5 h-5 text-primary">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
              </div>
              <p className="text-base font-semibold" aria-live="polite">
                {redirectMessage}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Veuillez patienter, nous préparons votre espace.
              </p>
            </div>
          )}
          <div className="flex gap-2 p-1 rounded-full bg-muted mb-6">
            <button
              onClick={() => setMode("login")}
              disabled={redirecting}
              className={`flex-1 py-2 rounded-full text-sm font-semibold disabled:opacity-50 ${mode === "login" ? "bg-card shadow" : ""}`}
            >
              Connexion
            </button>
            <button
              onClick={() => setMode("signup")}
              disabled={redirecting}
              className={`flex-1 py-2 rounded-full text-sm font-semibold disabled:opacity-50 ${mode === "signup" ? "bg-card shadow" : ""}`}
            >
              Inscription
            </button>
          </div>
          <h1 className="text-2xl font-bold">
            {mode === "login" ? "Bienvenue sur ZbossPay" : "Créer un compte gratuit"}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {mode === "login"
              ? "Accédez à votre tableau de bord marchand."
              : "Inscription gratuite. Aucune carte requise."}
          </p>

          <button
            type="button"
            onClick={handleGoogle}
            disabled={redirecting || loading}
            className="mt-6 w-full rounded-lg border px-4 py-2.5 text-sm font-medium hover:bg-muted disabled:opacity-60 flex items-center justify-center gap-2"
          >
            <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6.1 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.2 29.5 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.3-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16.1 19 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.2 29.5 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.4 0 10.3-2.1 14-5.4l-6.5-5.5c-2 1.4-4.6 2.3-7.5 2.3-5.2 0-9.6-3.3-11.2-8l-6.6 5.1C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.1 4.1-3.9 5.5l6.5 5.5C40.7 36.3 44 30.6 44 24c0-1.3-.1-2.3-.4-3.5z"/></svg>
            Continuer avec Google
          </button>

          <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex-1 h-px bg-border" />
            ou
            <span className="flex-1 h-px bg-border" />
          </div>

          <form onSubmit={handleSubmit} className="grid gap-4">
            {mode === "signup" && (
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Nom complet</span>
                <input
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  disabled={redirecting || loading}
                  className="rounded-lg border px-3 py-2.5 bg-background disabled:opacity-60"
                />
              </label>
            )}
            <label className="grid gap-1.5 text-sm">
              <span className="font-medium">Email</span>
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={redirecting || loading}
                className="rounded-lg border px-3 py-2.5 bg-background disabled:opacity-60"
              />
            </label>
            <label className="grid gap-1.5 text-sm">
              <div className="flex items-center justify-between">
                <span className="font-medium">Mot de passe</span>
                {mode === "login" && (
                  <Link to="/forgot-password" className="text-xs text-primary underline">
                    Oublié ?
                  </Link>
                )}
              </div>
              <input
                required
                type="password"
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={redirecting || loading}
                className="rounded-lg border px-3 py-2.5 bg-background disabled:opacity-60"
              />
            </label>
            <button
              disabled={loading || redirecting}
              className="rounded-full gradient-brand text-white px-6 py-3 font-semibold disabled:opacity-60"
            >
              {loading
                ? "…"
                : mode === "login"
                  ? "Se connecter"
                  : "Créer mon compte"}
            </button>
            {error && (
              <p className="text-sm text-red-600 text-center">{error}</p>
            )}
          </form>
          <p className="text-xs text-muted-foreground text-center mt-5">
            En continuant, vous acceptez nos conditions.{" "}
            <Link to="/contact" className="underline">
              Besoin d'aide ?
            </Link>
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
