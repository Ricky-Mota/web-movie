import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";

export const Route = createFileRoute("/docs/integration")({
  head: () => ({
    meta: [
      { title: "Guide d'intégration marchand — ZbossPay" },
      {
        name: "description",
        content:
          "Comment intégrer ZbossPay : initier un paiement, recevoir les webhooks signés HMAC-SHA256, vérifier la signature côté serveur.",
      },
      { property: "og:title", content: "Guide d'intégration ZbossPay" },
      { property: "og:description", content: "API paiement + vérification HMAC des webhooks." },
    ],
    links: [{ rel: "canonical", href: "/docs/integration" }],
  }),
  component: DocsPage,
});

const CURL_INITIATE = `curl -X POST https://api.zbosspay.com/v1/payments/initiate \\
  -H "Authorization: Bearer sk_live_..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "amount": 25000,
    "currency": "CDF",
    "operator": "MPESA",
    "customer_phone": "+243812345678",
    "merchant_reference": "INV-2026-0001"
  }'`;

const WEBHOOK_PAYLOAD = `POST https://votre-serveur.com/webhooks/zbosspay
Content-Type: application/json
X-ZbossPay-Signature: t=1734281234,v1=6f4a...c2

{
  "event": "payment.succeeded",
  "transaction_id": "tx_9f3a1c2b",
  "merchant_reference": "INV-2026-0001",
  "amount": 25000,
  "currency": "CDF",
  "status": "SUCCESS",
  "created_at": "2026-07-15T14:23:11Z"
}`;

const NODE_MIDDLEWARE = `// Node.js / Express — vérification HMAC-SHA256
const crypto = require('crypto');

function verifyZbossPayWebhook(req, res, next) {
  const header = req.headers['x-zbosspay-signature'];
  const secret = process.env.ZBOSSPAY_WEBHOOK_SECRET;
  if (!header) return res.status(401).send('Missing signature');

  const parts = Object.fromEntries(header.split(',').map(p => p.split('=')));
  const timestamp = parts.t;
  const signature = parts.v1;

  // Anti-rejeu : rejeter au-delà de 5 minutes
  if (Math.abs(Math.floor(Date.now() / 1000) - Number(timestamp)) > 300) {
    return res.status(400).send('Requête expirée');
  }

  const payload = JSON.stringify(req.body);
  const expected = crypto
    .createHmac('sha256', secret)
    .update(\`\${timestamp}.\${payload}\`)
    .digest('hex');

  const ok = crypto.timingSafeEqual(
    Buffer.from(signature, 'utf8'),
    Buffer.from(expected, 'utf8')
  );
  if (!ok) return res.status(403).send('Signature invalide');
  next();
}`;

const PHP_MIDDLEWARE = `<?php
// PHP — vérification HMAC-SHA256
$header = $_SERVER['HTTP_X_ZBOSSPAY_SIGNATURE'] ?? '';
$secret = getenv('ZBOSSPAY_WEBHOOK_SECRET');
$parts = [];
foreach (explode(',', $header) as $p) {
  [$k, $v] = explode('=', $p, 2);
  $parts[$k] = $v;
}
if (abs(time() - (int)$parts['t']) > 300) http_response_code(400);

$payload = file_get_contents('php://input');
$expected = hash_hmac('sha256', $parts['t'] . '.' . $payload, $secret);
if (!hash_equals($expected, $parts['v1'])) http_response_code(403);`;

function DocsPage() {
  return (
    <SiteLayout>
      <section className="gradient-brand text-white">
        <div className="container-page py-16">
          <span className="chip bg-white/15 text-white border-white/20">Développeurs</span>
          <h1 className="mt-4 text-4xl md:text-5xl font-bold">Guide d'intégration marchand</h1>
          <p className="mt-4 text-white/90 max-w-2xl">
            Initiez un paiement, recevez la confirmation via webhook signé, vérifiez la signature côté serveur.
          </p>
        </div>
      </section>

      <section className="container-page py-14 space-y-10">
        <div>
          <h2 className="text-2xl font-bold">1. Authentification</h2>
          <p className="mt-2 text-muted-foreground">
            Toutes les requêtes API utilisent l'en-tête{" "}
            <code className="px-1.5 py-0.5 rounded bg-muted">Authorization: Bearer sk_live_...</code>.
            Chaque marchand dispose d'une clé test (<code>sk_test_...</code>) et d'une clé live.
          </p>
        </div>

        <div>
          <h2 className="text-2xl font-bold">2. Initier un paiement</h2>
          <pre className="mt-4 rounded-xl border bg-neutral-950 text-neutral-100 p-6 overflow-x-auto text-xs leading-relaxed">
{CURL_INITIATE}
          </pre>
        </div>

        <div>
          <h2 className="text-2xl font-bold">3. Recevoir le webhook</h2>
          <p className="mt-2 text-muted-foreground">
            À chaque changement d'état, ZbossPay envoie un POST signé à l'URL configurée dans votre espace marchand.
          </p>
          <pre className="mt-4 rounded-xl border bg-neutral-950 text-neutral-100 p-6 overflow-x-auto text-xs leading-relaxed">
{WEBHOOK_PAYLOAD}
          </pre>
          <p className="mt-3 text-sm text-muted-foreground">
            L'en-tête <code>X-ZbossPay-Signature</code> a la forme{" "}
            <code>t=&lt;unix&gt;,v1=&lt;hex&gt;</code> — HMAC-SHA256 calculé sur{" "}
            <code>&lt;timestamp&gt;.&lt;payload_json&gt;</code>.
          </p>
        </div>

        <div>
          <h2 className="text-2xl font-bold">4. Vérifier la signature (Node.js)</h2>
          <pre className="mt-4 rounded-xl border bg-neutral-950 text-neutral-100 p-6 overflow-x-auto text-xs leading-relaxed">
{NODE_MIDDLEWARE}
          </pre>
        </div>

        <div>
          <h2 className="text-2xl font-bold">5. Vérifier la signature (PHP)</h2>
          <pre className="mt-4 rounded-xl border bg-neutral-950 text-neutral-100 p-6 overflow-x-auto text-xs leading-relaxed">
{PHP_MIDDLEWARE}
          </pre>
        </div>

        <div className="rounded-2xl border bg-card p-6">
          <h3 className="font-bold">Bonnes pratiques</h3>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground list-disc pl-5">
            <li>Comparez toujours les signatures en temps constant (<code>timingSafeEqual</code> / <code>hash_equals</code>).</li>
            <li>Rejetez les requêtes dont le timestamp est plus vieux que 5 minutes (protection contre les rejeux).</li>
            <li>Répondez <code>2xx</code> uniquement après persistance ; ZbossPay retentera sinon avec backoff exponentiel.</li>
            <li>Stockez le secret webhook côté serveur (variable d'environnement), jamais côté client.</li>
          </ul>
          <p className="mt-4 text-sm">
            Récupérez votre secret et configurez votre URL depuis{" "}
            <Link to="/dashboard" className="text-[var(--cta)] font-semibold">votre espace marchand</Link>.
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
