import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "../components/site/Layout";
import { ArrowDownToLine, ArrowUpFromLine, Check } from "lucide-react";
import ogImage from "../assets/og-payments.jpg";

export const Route = createFileRoute("/payments")({
  head: () => ({
    meta: [
      { title: "Paiements ZbossPay — C2B & B2C" },
      { name: "description", content: "Collecte client (C2B) et paiements aux bénéficiaires (B2C) via mobile money en RDC." },
      { property: "og:title", content: "Paiements ZbossPay" },
      { property: "og:description", content: "Collecte client (C2B) et paiements aux bénéficiaires (B2C) via mobile money en RDC." },
      { property: "og:url", content: "/payments" },
      { property: "og:image", content: ogImage },
      { property: "og:image:width", content: "1216" },
      { property: "og:image:height", content: "640" },
      { property: "og:image:alt", content: "Paiements ZbossPay C2B & B2C" },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: "/payments" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Service",
        serviceType: "Paiements C2B & B2C",
        name: "Paiements ZbossPay",
        url: "/payments",
        image: ogImage,
        provider: { "@type": "Organization", name: "ZbossPay" },
        areaServed: { "@type": "Country", name: "Congo, République démocratique du" },
        description: "Collecte client (C2B) et paiements aux bénéficiaires (B2C) via Airtel Money, Orange Money, M-Pesa, Afrimoney et carte bancaire.",
      }),
    }],
  }),
  component: PaymentsPage,
});

function PaymentsPage() {
  return (
    <SiteLayout>
      <section className="gradient-brand text-white">
        <div className="container-page py-16">
          <span className="chip bg-white/15 text-white border-white/20">Flux de paiement</span>
          <h1 className="mt-4 text-4xl md:text-5xl font-bold">Paiements C2B & B2C</h1>
          <p className="mt-4 text-white/90 max-w-2xl">
            Encaissez vos clients et distribuez vos fonds depuis une seule plateforme.
          </p>
        </div>
      </section>

      <section className="container-page py-16 grid md:grid-cols-2 gap-6">
        <div className="rounded-2xl border bg-card p-7">
          <ArrowDownToLine className="text-[var(--cta)]" />
          <span className="chip mt-3">C2B — Customer to Business</span>
          <h2 className="mt-3 text-2xl font-bold">Collecte client</h2>
          <p className="mt-2 text-muted-foreground">
            Recevez des paiements directement depuis les portefeuilles mobile money de vos clients —
            via API, portail web ou lien de paiement partageable.
          </p>
          <ul className="mt-5 space-y-3 text-sm">
            <li className="flex gap-2"><Check className="text-[var(--cta)] flex-none" size={18} /><span><b>Paiement USSD</b> — *5111# à tout moment</span></li>
            <li className="flex gap-2"><Check className="text-[var(--cta)] flex-none" size={18} /><span><b>Paiement en ligne</b> — checkout web & mobile</span></li>
            <li className="flex gap-2"><Check className="text-[var(--cta)] flex-none" size={18} /><span><b>Confirmation automatique</b> — reçu instantané</span></li>
            <li className="flex gap-2"><Check className="text-[var(--cta)] flex-none" size={18} /><span><b>Multi-opérateur</b> — Airtel · Orange · M-Pesa</span></li>
          </ul>
          <Link to="/contact" className="mt-6 inline-block rounded-full gradient-brand text-white px-5 py-2.5 font-semibold">Démarrer la collecte</Link>
        </div>

        <div className="rounded-2xl border bg-card p-7">
          <ArrowUpFromLine className="text-[var(--cta)]" />
          <span className="chip mt-3">B2C — Business to Customer</span>
          <h2 className="mt-3 text-2xl font-bold">Paiement aux bénéficiaires</h2>
          <p className="mt-2 text-muted-foreground">
            Distribuez des fonds vers les portefeuilles mobile money de vos employés, agents ou fournisseurs —
            unitairement ou en masse.
          </p>
          <ul className="mt-5 space-y-3 text-sm">
            <li className="flex gap-2"><Check className="text-[var(--cta)] flex-none" size={18} /><span><b>Décaissements instantanés</b> — salaires & commissions</span></li>
            <li className="flex gap-2"><Check className="text-[var(--cta)] flex-none" size={18} /><span><b>Paiements groupés</b> — jusqu'à 10 000 destinataires</span></li>
            <li className="flex gap-2"><Check className="text-[var(--cta)] flex-none" size={18} /><span><b>Automatisation API</b> — déclenchez via REST</span></li>
            <li className="flex gap-2"><Check className="text-[var(--cta)] flex-none" size={18} /><span><b>Conformité totale</b> — BCC · KYC · LBC</span></li>
          </ul>
          <Link to="/contact" className="mt-6 inline-block rounded-full gradient-brand text-white px-5 py-2.5 font-semibold">Activer les paiements B2C</Link>
        </div>
      </section>
    </SiteLayout>
  );
}
