import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  initiateAirtelPayment,
  refreshAirtelStatus,
  listAirtelTransactions,
} from "@/lib/airtel.functions";

export const Route = createFileRoute("/_authenticated/airtel-test")({
  head: () => ({ meta: [{ title: "Test Airtel Money — ZbossPay" }] }),
  component: AirtelTestPage,
});

function AirtelTestPage() {
  const initiate = useServerFn(initiateAirtelPayment);
  const refresh = useServerFn(refreshAirtelStatus);
  const list = useServerFn(listAirtelTransactions);

  const [amount, setAmount] = useState("1000");
  const [msisdn, setMsisdn] = useState("");
  const [description, setDescription] = useState("Test ZbossPay");
  const [submitting, setSubmitting] = useState(false);

  const txQuery = useQuery({
    queryKey: ["airtel-tx"],
    queryFn: () => list(),
    refetchInterval: 5000,
  });

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await initiate({
        data: {
          amount: Number(amount),
          msisdn: msisdn.replace(/\D/g, ""),
          description,
        },
      });
      if (res.ok) {
        toast.success("Paiement initié — le client doit confirmer sur son téléphone.");
      } else {
        toast.error(res.message || "Échec de l'initiation");
      }
      txQuery.refetch();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Erreur");
    } finally {
      setSubmitting(false);
    }
  }

  async function onRefresh(id: string) {
    try {
      const r = await refresh({ data: { transactionId: id } });
      toast.info(`Statut: ${r.status}`);
      txQuery.refetch();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Erreur");
    }
  }

  const origin = typeof window !== "undefined" ? window.location.origin : "https://clone-champ-v2.lovable.app";
  const webhookUrl = `${origin}/api/public/airtel-callback`;

  return (
    <div className="container mx-auto max-w-4xl px-4 py-10">
      <Link to="/dashboard" className="text-sm text-[var(--cta)] hover:underline">← Retour au tableau de bord</Link>
      <h1 className="mt-3 text-3xl font-bold">Test Airtel Money RDC</h1>
      <p className="mt-2 text-sm opacity-80">
        Initiez un paiement réel via votre connecteur Airtel Money configuré dans{" "}
        <Link to="/integrations" className="underline">Intégrations</Link>.
      </p>

      <div className="mt-6 rounded-lg border bg-amber-50 p-4 text-sm text-amber-900">
        <div className="font-semibold">URL de webhook à fournir à Airtel :</div>
        <code className="mt-1 block break-all rounded bg-white px-2 py-1">{webhookUrl}</code>
        <div className="mt-2 text-xs">
          Airtel doit signer le corps brut JSON avec HMAC-SHA256 (clé = <code>callback_secret</code>) et envoyer
          la signature hex dans l'en-tête <code>X-Auth-Signature</code>.
        </div>
      </div>

      <form onSubmit={onSubmit} className="mt-6 space-y-4 rounded-lg border p-6">
        <div>
          <label className="block text-sm font-medium">Numéro client (sans +243)</label>
          <input
            value={msisdn}
            onChange={(e) => setMsisdn(e.target.value)}
            placeholder="990000000"
            required
            className="mt-1 w-full rounded border px-3 py-2"
          />
        </div>
        <div>
          <label className="block text-sm font-medium">Montant (CDF)</label>
          <input
            type="number"
            min={1}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
            className="mt-1 w-full rounded border px-3 py-2"
          />
        </div>
        <div>
          <label className="block text-sm font-medium">Description</label>
          <input
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            maxLength={160}
            className="mt-1 w-full rounded border px-3 py-2"
          />
        </div>
        <button
          type="submit"
          disabled={submitting}
          className="rounded bg-[var(--cta)] px-4 py-2 font-semibold text-white disabled:opacity-50"
        >
          {submitting ? "Envoi…" : "Initier le paiement"}
        </button>
      </form>

      <h2 className="mt-10 text-xl font-bold">Transactions récentes</h2>
      <div className="mt-3 overflow-x-auto rounded-lg border">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr className="text-left">
              <th className="p-2">Date</th>
              <th className="p-2">Réf</th>
              <th className="p-2">Numéro</th>
              <th className="p-2">Montant</th>
              <th className="p-2">Env.</th>
              <th className="p-2">Statut</th>
              <th className="p-2">Action</th>
            </tr>
          </thead>
          <tbody>
            {(txQuery.data ?? []).map((t) => (
              <tr key={t.id} className="border-t">
                <td className="p-2">{new Date(t.created_at).toLocaleString()}</td>
                <td className="p-2 font-mono text-xs">{t.external_reference}</td>
                <td className="p-2">{t.customer_msisdn}</td>
                <td className="p-2">{t.amount} {t.currency}</td>
                <td className="p-2">{t.environment}</td>
                <td className="p-2">
                  <span className={
                    t.status === "succeeded" ? "text-green-700" :
                    t.status === "failed" || t.status === "cancelled" ? "text-red-700" :
                    "text-amber-700"
                  }>{t.status}</span>
                </td>
                <td className="p-2">
                  <button
                    onClick={() => onRefresh(t.id)}
                    className="rounded border px-2 py-1 text-xs hover:bg-gray-50"
                  >
                    Vérifier
                  </button>
                </td>
              </tr>
            ))}
            {(txQuery.data ?? []).length === 0 && (
              <tr><td colSpan={7} className="p-4 text-center opacity-60">Aucune transaction pour l'instant.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
