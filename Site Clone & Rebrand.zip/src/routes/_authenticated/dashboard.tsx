import { createFileRoute, useRouter, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { SiteLayout } from "@/components/site/Layout";
import { supabase } from "@/integrations/supabase/client";
import {
  createConnectOnboardingLink,
  refreshConnectAccountStatus,
  createCheckoutSession,
  listMyTransactions,
  getMyProfile,
  getDepotCommunStatus,
} from "@/lib/payments.functions";
import { getMyKyc } from "@/lib/kyc.functions";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [{ title: "Tableau de bord — ZbossPay" }],
  }),
  validateSearch: z.object({
    unauthorized: z.string().optional(),
  }),
  component: DashboardPage,
});

function formatMoney(cents: number, currency: string) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: currency.toUpperCase(),
  }).format(cents / 100);
}

function DashboardPage() {
  const router = useRouter();
  const navigate = useNavigate({ from: "/_authenticated/dashboard" });
  const search = Route.useSearch();
  const [accessDenied, setAccessDenied] = useState<string | null>(null);

  useEffect(() => {
    if (search.unauthorized === "integrations") {
      const message =
        "Les Intégrations partenaires sont réservées au propriétaire de l'application. Vous avez été redirigé vers votre tableau de bord.";
      setAccessDenied(message);
      toast.error("Accès réservé", { description: message });
      navigate({ search: {} });
    }
  }, [search.unauthorized, navigate]);

  const profileFn = useServerFn(getMyProfile);
  const onboardingFn = useServerFn(createConnectOnboardingLink);
  const refreshFn = useServerFn(refreshConnectAccountStatus);
  const checkoutFn = useServerFn(createCheckoutSession);
  const txFn = useServerFn(listMyTransactions);

  const profileQ = useQuery({ queryKey: ["profile"], queryFn: () => profileFn() });
  const txQ = useQuery({ queryKey: ["transactions"], queryFn: () => txFn() });
  const depotFn = useServerFn(getDepotCommunStatus);
  const depotQ = useQuery({ queryKey: ["depot-commun"], queryFn: () => depotFn() });
  const kycFn = useServerFn(getMyKyc);
  const kycQ = useQuery({ queryKey: ["kyc", "me"], queryFn: () => kycFn() });


  const onboardMut = useMutation({
    mutationFn: () => onboardingFn(),
    onSuccess: (res) => {
      if (res.url) window.location.href = res.url;
    },
  });
  const refreshMut = useMutation({
    mutationFn: () => refreshFn(),
    onSuccess: () => profileQ.refetch(),
  });

  const [form, setForm] = useState({
    description: "",
    amount: "",
    currency: "eur",
    customer_email: "",
  });
  const checkoutMut = useMutation({
    mutationFn: () =>
      checkoutFn({
        data: {
          description: form.description,
          amount: Math.round(parseFloat(form.amount) * 100),
          currency: form.currency,
          customer_email: form.customer_email || null,
        },
      }),
    onSuccess: (res) => {
      if (res.url) window.location.href = res.url;
    },
  });

  const profile = profileQ.data;
  const connected = Boolean(profile?.stripe_account_id);
  const ready = profile?.stripe_charges_enabled;

  return (
    <SiteLayout>
      <section className="container-page py-10 grid gap-8">
        {accessDenied && (
          <div
            className="rounded-xl border-l-4 p-4 text-sm shadow-sm"
            style={{
              borderColor: "var(--cta)",
              backgroundColor: "color-mix(in srgb, var(--cta) 12%, transparent)",
            }}
          >
            <div className="flex items-start justify-between gap-3">
              <p className="font-medium">{accessDenied}</p>
              <button
                onClick={() => setAccessDenied(null)}
                className="shrink-0 text-muted-foreground hover:text-foreground"
                aria-label="Fermer"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        <KycBanner kyc={kycQ.data} />

        <header className="flex items-center justify-between flex-wrap gap-3">

          <div>
            <h1 className="text-3xl font-bold">Tableau de bord</h1>
            <p className="text-sm text-muted-foreground mt-1">
              {profile?.email}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={async () => {
                await supabase.auth.signOut();
                router.navigate({ to: "/" });
              }}
              className="text-sm rounded-full border px-4 py-2 hover:bg-muted"
            >
              Se déconnecter
            </button>
          </div>
        </header>

        {/* Compte commun ZbossPay (agrégateur) */}
        {depotQ.data?.available && (
          <div
            className="rounded-2xl border bg-card p-6 flex items-start gap-4"
            style={{
              borderColor: depotQ.data.provider.brand_color
                ? `${depotQ.data.provider.brand_color}55`
                : undefined,
            }}
          >
            <div
              className="grid h-12 w-12 place-items-center rounded-xl text-2xl shrink-0"
              style={{
                background: depotQ.data.provider.brand_color
                  ? `${depotQ.data.provider.brand_color}22`
                  : "var(--muted)",
              }}
            >
              <span>{depotQ.data.provider.logo_emoji ?? "🏦"}</span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-semibold">
                  {depotQ.data.provider.name}
                </h2>
                <span className="inline-flex items-center gap-1.5 text-[11px] uppercase tracking-wide rounded-full px-2 py-0.5 bg-green-100 text-green-700">
                  <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                  Opérationnel
                </span>
                <span className="text-[11px] uppercase tracking-wide rounded-full px-2 py-0.5 bg-muted text-muted-foreground">
                  {depotQ.data.environment}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Encaissez dépôts et paiements via le compte agrégé ZbossPay,
                sans configuration partenaire. {depotQ.data.message}
              </p>
            </div>
          </div>
        )}

        {/* Connect status */}
        <div className="rounded-2xl border bg-card p-6">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h2 className="text-lg font-semibold">Compte Stripe Connect</h2>
              <p className="text-sm text-muted-foreground mt-1">
                {ready
                  ? "✅ Votre compte est prêt à encaisser des paiements."
                  : connected
                    ? "⏳ Onboarding incomplet. Terminez la configuration Stripe."
                    : "Connectez Stripe pour commencer à recevoir des paiements."}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                Commission ZbossPay : <strong>3 %</strong> par transaction
                réussie.
              </p>
            </div>
            <div className="flex gap-2">
              {connected && (
                <button
                  onClick={() => refreshMut.mutate()}
                  disabled={refreshMut.isPending}
                  className="text-sm rounded-full border px-4 py-2 hover:bg-muted"
                >
                  Rafraîchir
                </button>
              )}
              <button
                onClick={() => onboardMut.mutate()}
                disabled={onboardMut.isPending}
                className="rounded-full gradient-cta text-[var(--cta-foreground)] px-5 py-2.5 font-semibold text-sm shadow"
              >
                {onboardMut.isPending
                  ? "Chargement…"
                  : connected
                    ? "Continuer l'onboarding"
                    : "Connecter Stripe"}
              </button>
            </div>
          </div>
          {onboardMut.isError && (
            <p className="text-sm text-red-600 mt-3">
              {(onboardMut.error as Error).message}
            </p>
          )}
        </div>

        {/* Create checkout */}
        <div className="rounded-2xl border bg-card p-6">
          <h2 className="text-lg font-semibold">Encaisser un paiement</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Générez un lien Stripe Checkout à envoyer à votre client.
          </p>

          <KycCheckoutGate kyc={kycQ.data} />

          {!kycBlocked(kycQ.data) && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                checkoutMut.mutate();
              }}
              className="mt-5 grid sm:grid-cols-2 gap-4"
            >
              <label className="grid gap-1.5 text-sm sm:col-span-2">
                <span className="font-medium">Description</span>
                <input
                  required
                  value={form.description}
                  onChange={(e) =>
                    setForm({ ...form, description: e.target.value })
                  }
                  placeholder="Ex: Commande #1234"
                  className="rounded-lg border px-3 py-2.5 bg-background"
                />
              </label>
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Montant</span>
                <input
                  required
                  type="number"
                  min="0.5"
                  step="0.01"
                  value={form.amount}
                  onChange={(e) => setForm({ ...form, amount: e.target.value })}
                  placeholder="0.00"
                  className="rounded-lg border px-3 py-2.5 bg-background"
                />
              </label>
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Devise</span>
                <select
                  value={form.currency}
                  onChange={(e) =>
                    setForm({ ...form, currency: e.target.value })
                  }
                  className="rounded-lg border px-3 py-2.5 bg-background"
                >
                  <option value="eur">EUR</option>
                  <option value="usd">USD</option>
                  <option value="gbp">GBP</option>
                </select>
              </label>
              <label className="grid gap-1.5 text-sm sm:col-span-2">
                <span className="font-medium">Email du client (optionnel)</span>
                <input
                  type="email"
                  value={form.customer_email}
                  onChange={(e) =>
                    setForm({ ...form, customer_email: e.target.value })
                  }
                  placeholder="client@exemple.com"
                  className="rounded-lg border px-3 py-2.5 bg-background"
                />
              </label>
              <div className="sm:col-span-2 flex items-center justify-between gap-3">
                <p className="text-xs text-muted-foreground">
                  {form.amount
                    ? `Commission ZbossPay (3 %) : ${(parseFloat(form.amount) * 0.03).toFixed(2)} ${form.currency.toUpperCase()}`
                    : ""}
                </p>
                <button
                  disabled={!ready || checkoutMut.isPending}
                  className="rounded-full gradient-brand text-white px-6 py-3 font-semibold disabled:opacity-50"
                >
                  {checkoutMut.isPending
                    ? "Création…"
                    : "Générer le lien de paiement"}
                </button>
              </div>
              {!ready && (
                <p className="sm:col-span-2 text-xs text-red-600">
                  Terminez l'onboarding Stripe avant de pouvoir encaisser.
                </p>
              )}
              {checkoutMut.isError && (
                <p className="sm:col-span-2 text-sm text-red-600">
                  {(checkoutMut.error as Error).message}
                </p>
              )}
            </form>
          )}
        </div>

        {/* Transactions */}
        <div className="rounded-2xl border bg-card p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Transactions récentes</h2>
            <button
              onClick={() => txQ.refetch()}
              className="text-sm text-muted-foreground hover:underline"
            >
              Rafraîchir
            </button>
          </div>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground border-b">
                <tr>
                  <th className="py-2 pr-3">Date</th>
                  <th className="py-2 pr-3">Description</th>
                  <th className="py-2 pr-3">Client</th>
                  <th className="py-2 pr-3 text-right">Total</th>
                  <th className="py-2 pr-3 text-right">Commission</th>
                  <th className="py-2 pr-3">Statut</th>
                </tr>
              </thead>
              <tbody>
                {(txQ.data ?? []).length === 0 && (
                  <tr>
                    <td
                      colSpan={6}
                      className="py-6 text-center text-muted-foreground"
                    >
                      Aucune transaction pour le moment.
                    </td>
                  </tr>
                )}
                {(txQ.data ?? []).map((t) => (
                  <tr key={t.id} className="border-b last:border-0">
                    <td className="py-2 pr-3 whitespace-nowrap">
                      {new Date(t.created_at).toLocaleString("fr-FR")}
                    </td>
                    <td className="py-2 pr-3">{t.description}</td>
                    <td className="py-2 pr-3">{t.customer_email ?? "—"}</td>
                    <td className="py-2 pr-3 text-right">
                      {formatMoney(t.amount_total, t.currency)}
                    </td>
                    <td className="py-2 pr-3 text-right text-muted-foreground">
                      {formatMoney(t.application_fee_amount, t.currency)}
                    </td>
                    <td className="py-2 pr-3">
                      <span
                        className={
                          t.status === "succeeded"
                            ? "text-green-600 font-medium"
                            : t.status === "failed"
                              ? "text-red-600"
                              : t.status === "refunded"
                                ? "text-orange-600"
                                : "text-muted-foreground"
                        }
                      >
                        {t.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}

function KycBanner({
  kyc,
}: {
  kyc:
    | {
        status: "pending" | "approved" | "rejected";
        rejection_reason: string | null;
      }
    | null
    | undefined;
}) {
  const status = kyc?.status;
  const styles =
    status === "approved"
      ? "bg-green-50 border-green-200 text-green-900"
      : status === "rejected"
        ? "bg-red-50 border-red-200 text-red-900"
        : "bg-amber-50 border-amber-200 text-amber-900";
  const title = !kyc
    ? "🔒 Vérification KYC requise"
    : status === "approved"
      ? "✅ KYC validé — paiements réels activés"
      : status === "rejected"
        ? "❌ Dossier KYC rejeté"
        : "⏳ KYC en cours d'examen";
  const desc = !kyc
    ? "Complétez votre dossier (RCCM, NIF, pièce d'identité) pour activer les paiements réels."
    : status === "rejected"
      ? kyc.rejection_reason || "Corrigez les informations et resoumettez."
      : status === "pending"
        ? "Délai habituel : 24-48h ouvrées."
        : "Vous pouvez encaisser des paiements en mode production.";
  return (
    <div className={`rounded-xl border px-4 py-3 text-sm flex flex-wrap items-center justify-between gap-3 ${styles}`}>
      <div>
        <p className="font-semibold">{title}</p>
        <p className="text-xs opacity-90">{desc}</p>
      </div>
      {status !== "approved" && (
        <Link
          to="/kyc"
          className="text-sm rounded-full bg-white/80 hover:bg-white px-4 py-1.5 font-semibold border"
        >
          {kyc ? "Modifier le dossier" : "Compléter mon KYC"}
        </Link>
      )}
    </div>
  );
}

function kycBlocked(kyc: { status: "pending" | "approved" | "rejected" } | null | undefined): boolean {
  return !kyc || kyc.status === "pending" || kyc.status === "rejected";
}

function KycCheckoutGate({
  kyc,
}: {
  kyc:
    | {
        status: "pending" | "approved" | "rejected";
        rejection_reason: string | null;
      }
    | null
    | undefined;
}) {
  const navigate = useNavigate({ from: "/_authenticated/dashboard" });
  const status = kyc?.status;
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    if (!kycBlocked(kyc)) return;

    toast.error("KYC requis", {
      description:
        status === "pending"
          ? "Votre dossier KYC est en cours d'examen. Redirection vers la page KYC..."
          : status === "rejected"
            ? "Votre dossier KYC a été rejeté. Corrigez-le pour encaisser."
            : "Vous devez compléter votre KYC pour encaisser des paiements.",
    });

    if (countdown <= 0) {
      navigate({ to: "/kyc" });
      return;
    }

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate({ to: "/kyc" });
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [kyc, status, navigate, countdown]);

  if (!kycBlocked(kyc)) return null;

  const isPending = status === "pending";
  const isRejected = status === "rejected";

  return (
    <div className="mt-5 rounded-xl border bg-amber-50 border-amber-200 p-5 text-amber-900">
      <div className="flex items-start gap-3">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-amber-100 text-amber-700 text-lg">
          🔒
        </div>
        <div className="flex-1">
          <p className="font-semibold text-base">
            {isPending
              ? "⏳ KYC en cours d'examen"
              : isRejected
                ? "❌ Dossier KYC rejeté"
                : "🔒 Vérification KYC requise"}
          </p>
          <p className="mt-1 text-sm text-amber-800/90">
            {isPending
              ? "Votre dossier KYC est en cours d'examen (24-48h ouvrées). Vous ne pouvez pas encore encaisser de paiements réels."
              : isRejected
                ? `Votre dossier KYC a été rejeté${kyc?.rejection_reason ? ` : ${kyc.rejection_reason}` : "."} Corrigez les informations et resoumettez pour débloquer les encaissements.`
                : "Complétez votre dossier KYC (RCCM, NIF, pièce d'identité) pour activer les encaissements en production."}
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <Link
              to="/kyc"
              className="inline-flex items-center rounded-full bg-amber-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-amber-800"
            >
              Aller à la page KYC
            </Link>
            <span className="text-sm text-amber-800/80">
              Redirection automatique dans {countdown}s
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}


