import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "../../components/site/Layout";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/account-phone")({
  head: () => ({
    meta: [
      { title: "Changer mon numéro — ZbossPay" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AccountPhonePage,
});

function AccountPhonePage() {
  const router = useRouter();
  const [currentPhone, setCurrentPhone] = useState<string | null>(null);
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setCurrentPhone(data.user?.phone ?? null);
    });
  }, []);

  const sendCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      // Format E.164 (ex: +243...). updateUser({ phone }) envoie un OTP à usage unique.
      const normalized = phone.trim().replace(/\s/g, "");
      if (!/^\+\d{8,15}$/.test(normalized)) {
        throw new Error("Format attendu : +243XXXXXXXXX");
      }
      const { error: e2 } = await supabase.auth.updateUser({ phone: normalized });
      if (e2) throw e2;
      setPhone(normalized);
      setInfo("Code à 6 chiffres envoyé par SMS. Il expire dans 5 minutes.");
      setStep("otp");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur");
    } finally {
      setLoading(false);
    }
  };

  const verifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { error: e2 } = await supabase.auth.verifyOtp({
        phone,
        token: code,
        type: "phone_change",
      });
      if (e2) throw e2;
      router.navigate({ to: "/reset-confirmed", search: { type: "phone" } as never });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Code invalide ou expiré");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SiteLayout>
      <section className="container-page py-16 max-w-md">
        <div className="rounded-2xl border bg-card p-7">
          <h1 className="text-2xl font-bold">Changer mon numéro</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {currentPhone ? `Numéro actuel : ${currentPhone}` : "Aucun numéro enregistré."}
          </p>

          {step === "phone" ? (
            <form onSubmit={sendCode} className="grid gap-4 mt-6">
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Nouveau numéro (format +243…)</span>
                <input
                  required
                  type="tel"
                  autoFocus
                  placeholder="+243812345678"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="rounded-lg border px-3 py-2.5 bg-background"
                />
              </label>
              <button
                disabled={loading}
                className="rounded-full gradient-brand text-white px-6 py-3 font-semibold disabled:opacity-60"
              >
                {loading ? "Envoi…" : "Envoyer le code SMS"}
              </button>
              {error && <p className="text-sm text-red-600 text-center">{error}</p>}
              <Link to="/dashboard" className="text-xs text-center text-muted-foreground underline">
                ← Retour
              </Link>
            </form>
          ) : (
            <form onSubmit={verifyCode} className="grid gap-4 mt-6">
              {info && (
                <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800">
                  {info}
                </div>
              )}
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Code reçu par SMS</span>
                <input
                  required
                  inputMode="numeric"
                  pattern="\d{6}"
                  maxLength={6}
                  autoFocus
                  placeholder="123456"
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
                  className="rounded-lg border px-3 py-2.5 bg-background text-center tracking-[0.5em] text-lg"
                />
              </label>
              <button
                disabled={loading}
                className="rounded-full gradient-brand text-white px-6 py-3 font-semibold disabled:opacity-60"
              >
                {loading ? "…" : "Confirmer le nouveau numéro"}
              </button>
              {error && <p className="text-sm text-red-600 text-center">{error}</p>}
              <button
                type="button"
                onClick={() => { setStep("phone"); setCode(""); setError(null); }}
                className="text-xs text-center text-muted-foreground underline"
              >
                ← Modifier le numéro
              </button>
            </form>
          )}
        </div>
      </section>
    </SiteLayout>
  );
}
