import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { SiteLayout } from "@/components/site/Layout";
import {
  getMyRoles,
  adminListAllTransactions,
  adminGrantRole,
  adminRevokeRole,
} from "@/lib/admin.functions";
import { adminListKyc, adminReviewKyc, adminSignKycDoc } from "@/lib/kyc.functions";


export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Administration — ZbossPay" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  beforeLoad: async () => {
    const roles = await getMyRoles();
    if (!roles.includes("admin")) {
      throw redirect({ to: "/dashboard" });
    }
  },
  component: AdminPage,
});

function formatMoney(cents: number, currency: string) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: currency.toUpperCase(),
  }).format(cents / 100);
}

function AdminPage() {
  const qc = useQueryClient();
  const listAll = useServerFn(adminListAllTransactions);
  const grant = useServerFn(adminGrantRole);
  const revoke = useServerFn(adminRevokeRole);

  const txs = useQuery({
    queryKey: ["admin", "transactions"],
    queryFn: () => listAll(),
  });

  const [userId, setUserId] = useState("");
  const [role, setRole] = useState<"admin" | "moderator" | "user">("moderator");
  const [feedback, setFeedback] = useState<string | null>(null);

  const grantMut = useMutation({
    mutationFn: () => grant({ data: { user_id: userId.trim(), role } }),
    onSuccess: () => {
      setFeedback(`Rôle ${role} attribué.`);
      setUserId("");
    },
    onError: (e: Error) => setFeedback(e.message),
  });

  const revokeMut = useMutation({
    mutationFn: () => revoke({ data: { user_id: userId.trim(), role } }),
    onSuccess: () => {
      setFeedback(`Rôle ${role} retiré.`);
      setUserId("");
    },
    onError: (e: Error) => setFeedback(e.message),
  });

  const totalVolume = (txs.data ?? []).reduce(
    (sum, t) => sum + (t.status === "succeeded" ? t.amount_total : 0),
    0,
  );
  const totalFees = (txs.data ?? []).reduce(
    (sum, t) => sum + (t.status === "succeeded" ? t.application_fee_amount : 0),
    0,
  );

  return (
    <SiteLayout>
      <section className="container-page py-10 space-y-10">
        <header className="space-y-2">
          <div className="flex items-start justify-between flex-wrap gap-3">
            <div className="space-y-2">
              <p className="text-xs uppercase tracking-widest text-[var(--cta)] font-semibold">
                Administration
              </p>
              <h1 className="text-3xl md:text-4xl font-extrabold">
                Console admin ZbossPay
              </h1>
              <p className="text-muted-foreground">
                Réservé aux comptes avec le rôle <code>admin</code>. Toutes les
                actions sont vérifiées côté serveur.
              </p>
            </div>
            <Link
              to="/integrations"
              className="text-sm rounded-full gradient-cta text-[var(--cta-foreground)] px-4 py-2 font-semibold shadow hover:opacity-90"
            >
              🔌 Intégrations partenaires
            </Link>
          </div>
        </header>

        {/* KPIs */}
        <div className="grid sm:grid-cols-3 gap-4">
          <Kpi label="Transactions" value={String(txs.data?.length ?? 0)} />
          <Kpi
            label="Volume encaissé"
            value={formatMoney(totalVolume, "eur")}
          />
          <Kpi
            label="Commissions ZbossPay"
            value={formatMoney(totalFees, "eur")}
          />
        </div>

        {/* Role management */}
        <div className="rounded-2xl border bg-card p-6 space-y-4">
          <h2 className="text-xl font-bold">Gestion des rôles</h2>
          <p className="text-sm text-muted-foreground">
            Renseigne l'UUID de l'utilisateur (visible dans la table profils)
            puis attribue ou retire un rôle.
          </p>
          <div className="grid md:grid-cols-[1fr_180px_auto_auto] gap-3 items-end">
            <label className="text-sm space-y-1">
              <span className="block font-medium">User ID</span>
              <input
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="00000000-0000-0000-0000-000000000000"
                className="w-full rounded-lg border px-3 py-2 text-sm font-mono"
              />
            </label>
            <label className="text-sm space-y-1">
              <span className="block font-medium">Rôle</span>
              <select
                value={role}
                onChange={(e) =>
                  setRole(e.target.value as "admin" | "moderator" | "user")
                }
                className="w-full rounded-lg border px-3 py-2 text-sm"
              >
                <option value="admin">admin</option>
                <option value="moderator">moderator</option>
                <option value="user">user</option>
              </select>
            </label>
            <button
              type="button"
              disabled={!userId.trim() || grantMut.isPending}
              onClick={() => {
                setFeedback(null);
                grantMut.mutate();
              }}
              className="btn-cta rounded-lg px-4 py-2 text-sm font-semibold disabled:opacity-50"
            >
              Attribuer
            </button>
            <button
              type="button"
              disabled={!userId.trim() || revokeMut.isPending}
              onClick={() => {
                setFeedback(null);
                revokeMut.mutate();
              }}
              className="rounded-lg border px-4 py-2 text-sm font-semibold hover:bg-muted disabled:opacity-50"
            >
              Retirer
            </button>
          </div>
          {feedback && (
            <p className="text-sm text-muted-foreground">{feedback}</p>
          )}
        </div>

        {/* KYC Review */}
        <KycReviewSection />

        {/* All transactions */}

        <div className="rounded-2xl border bg-card overflow-hidden">
          <div className="flex items-center justify-between p-6 border-b">
            <h2 className="text-xl font-bold">Toutes les transactions</h2>
            <button
              type="button"
              onClick={() =>
                qc.invalidateQueries({ queryKey: ["admin", "transactions"] })
              }
              className="text-sm rounded-lg border px-3 py-1.5 hover:bg-muted"
            >
              Rafraîchir
            </button>
          </div>
          {txs.isLoading ? (
            <p className="p-6 text-sm text-muted-foreground">Chargement…</p>
          ) : txs.error ? (
            <p className="p-6 text-sm text-red-600">
              {(txs.error as Error).message}
            </p>
          ) : !txs.data?.length ? (
            <p className="p-6 text-sm text-muted-foreground">
              Aucune transaction pour le moment.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-left">
                  <tr>
                    <th className="px-4 py-3 font-semibold">Date</th>
                    <th className="px-4 py-3 font-semibold">Marchand</th>
                    <th className="px-4 py-3 font-semibold">Client</th>
                    <th className="px-4 py-3 font-semibold">Description</th>
                    <th className="px-4 py-3 font-semibold text-right">
                      Montant
                    </th>
                    <th className="px-4 py-3 font-semibold text-right">
                      Commission
                    </th>
                    <th className="px-4 py-3 font-semibold">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  {txs.data.map((t) => (
                    <tr key={t.id} className="border-t">
                      <td className="px-4 py-3 whitespace-nowrap">
                        {new Date(t.created_at).toLocaleString("fr-FR")}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs">
                        {t.merchant_id.slice(0, 8)}…
                      </td>
                      <td className="px-4 py-3">{t.customer_email ?? "—"}</td>
                      <td className="px-4 py-3">{t.description}</td>
                      <td className="px-4 py-3 text-right">
                        {formatMoney(t.amount_total, t.currency)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {formatMoney(t.application_fee_amount, t.currency)}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={
                            "inline-block rounded-full px-2 py-0.5 text-xs font-medium " +
                            (t.status === "succeeded"
                              ? "bg-green-100 text-green-800"
                              : t.status === "pending"
                                ? "bg-amber-100 text-amber-800"
                                : "bg-red-100 text-red-800")
                          }
                        >
                          {t.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </SiteLayout>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border bg-card p-6">
      <p className="text-xs uppercase tracking-widest text-muted-foreground">
        {label}
      </p>
      <p className="mt-2 text-2xl font-extrabold">{value}</p>
    </div>
  );
}

function KycReviewSection() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListKyc);
  const reviewFn = useServerFn(adminReviewKyc);
  const signFn = useServerFn(adminSignKycDoc);

  const list = useQuery({ queryKey: ["admin", "kyc"], queryFn: () => listFn() });
  const [reason, setReason] = useState<Record<string, string>>({});

  const reviewMut = useMutation({
    mutationFn: (vars: { kyc_id: string; decision: "approved" | "rejected"; reason?: string }) =>
      reviewFn({ data: vars }),
    onSuccess: (_d, vars) => {
      toast.success(vars.decision === "approved" ? "Dossier approuvé" : "Dossier rejeté");
      qc.invalidateQueries({ queryKey: ["admin", "kyc"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function openDoc(path: string | null) {
    if (!path) return;
    try {
      const { url } = await signFn({ data: { path } });
      window.open(url, "_blank", "noopener,noreferrer");
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <div className="rounded-2xl border bg-card overflow-hidden">
      <div className="flex items-center justify-between p-6 border-b">
        <div>
          <h2 className="text-xl font-bold">Dossiers KYC marchands</h2>
          <p className="text-sm text-muted-foreground">
            Validez l'identité légale avant d'activer les paiements réels.
          </p>
        </div>
        <button
          type="button"
          onClick={() => qc.invalidateQueries({ queryKey: ["admin", "kyc"] })}
          className="text-sm rounded-lg border px-3 py-1.5 hover:bg-muted"
        >
          Rafraîchir
        </button>
      </div>
      {list.isLoading ? (
        <p className="p-6 text-sm text-muted-foreground">Chargement…</p>
      ) : !list.data?.length ? (
        <p className="p-6 text-sm text-muted-foreground">Aucun dossier soumis.</p>
      ) : (
        <ul className="divide-y">
          {list.data.map((k) => (
            <li key={k.id} className="p-6 space-y-3">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">
                    {k.legal_name}{" "}
                    <span className="text-xs font-normal text-muted-foreground">
                      ({k.entity_type === "company" ? "Société" : "Personne"})
                    </span>
                  </p>
                  <p className="text-xs text-muted-foreground font-mono">{k.user_id}</p>
                  <p className="text-xs text-muted-foreground">
                    Soumis le {new Date(k.submitted_at).toLocaleString("fr-FR")}
                  </p>
                </div>
                <span
                  className={
                    "inline-block rounded-full px-2 py-0.5 text-xs font-medium " +
                    (k.status === "approved"
                      ? "bg-green-100 text-green-800"
                      : k.status === "rejected"
                        ? "bg-red-100 text-red-800"
                        : "bg-amber-100 text-amber-800")
                  }
                >
                  {k.status}
                </span>
              </div>
              <div className="grid sm:grid-cols-2 gap-2 text-xs">
                <p><b>RCCM :</b> {k.rccm_number}</p>
                <p><b>NIF :</b> {k.nif_number}</p>
                <p><b>Pièce :</b> {k.id_number}</p>
                <p><b>Tél :</b> {k.phone}</p>
                <p className="sm:col-span-2"><b>Adresse :</b> {k.address}, {k.city} ({k.country})</p>
              </div>
              <div className="flex flex-wrap gap-2">
                {[
                  { p: k.rccm_doc_url, l: "RCCM" },
                  { p: k.nif_doc_url, l: "NIF" },
                  { p: k.id_doc_url, l: "Pièce" },
                  { p: k.selfie_url, l: "Selfie" },
                ].map((d) => (
                  <button
                    key={d.l}
                    type="button"
                    onClick={() => openDoc(d.p)}
                    disabled={!d.p}
                    className="text-xs rounded-md border px-3 py-1 hover:bg-muted disabled:opacity-40"
                  >
                    📄 {d.l}
                  </button>
                ))}
              </div>
              {k.status !== "approved" && (
                <div className="flex flex-wrap items-center gap-2 pt-2">
                  <input
                    type="text"
                    placeholder="Motif (si rejet)"
                    value={reason[k.id] ?? ""}
                    onChange={(e) => setReason((r) => ({ ...r, [k.id]: e.target.value }))}
                    className="flex-1 min-w-[200px] rounded-lg border px-3 py-1.5 text-sm"
                  />
                  <button
                    type="button"
                    disabled={reviewMut.isPending}
                    onClick={() =>
                      reviewMut.mutate({ kyc_id: k.id, decision: "approved" })
                    }
                    className="rounded-lg bg-green-600 text-white px-3 py-1.5 text-sm font-semibold hover:bg-green-700 disabled:opacity-50"
                  >
                    Approuver
                  </button>
                  <button
                    type="button"
                    disabled={reviewMut.isPending}
                    onClick={() =>
                      reviewMut.mutate({
                        kyc_id: k.id,
                        decision: "rejected",
                        reason: reason[k.id] || undefined,
                      })
                    }
                    className="rounded-lg bg-red-600 text-white px-3 py-1.5 text-sm font-semibold hover:bg-red-700 disabled:opacity-50"
                  >
                    Rejeter
                  </button>
                </div>
              )}
              {k.status === "rejected" && k.rejection_reason && (
                <p className="text-xs text-red-700">Motif : {k.rejection_reason}</p>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

