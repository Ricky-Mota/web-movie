import { createFileRoute, Link, notFound, redirect, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { SiteLayout } from "@/components/site/Layout";
import { getMyRoles } from "@/lib/admin.functions";
import {
  listProviders,
  listMyConnections,
  upsertConnection,
  type CredentialField,
} from "@/lib/integrations.functions";


export const Route = createFileRoute("/_authenticated/integrations/$slug/connect")({
  head: ({ params }) => ({
    meta: [
      { title: `Se connecter à ${params.slug} — ZbossPay` },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  beforeLoad: async () => {
    const roles = await getMyRoles();
    if (!roles.includes("admin")) {
      throw redirect({ to: "/dashboard" });
    }
  },
  component: ConnectPage,
  notFoundComponent: () => (
    <SiteLayout>
      <div className="container-page py-10">
        <p>Connecteur introuvable.</p>
        <Link to="/integrations" className="text-sm underline">
          ← Retour aux intégrations
        </Link>
      </div>
    </SiteLayout>
  ),
});

const TYPE_LABEL = {
  mobile_money: "Mobile Money",
  bank: "Banque",
  card_network: "Réseau de cartes",
  microfinance: "Microfinance",
  aggregator: "Compte agrégé",
} as const;

type AirtelCheck = {
  id: string;
  label: string;
  ok: boolean;
  message: string;
};

function useAirtelChecks(
  slug: string,
  env: "sandbox" | "live",
  values: Record<string, string>,
  masked: Record<string, string>,
) {
  return useMemo<AirtelCheck[]>(() => {
    if (slug !== "airtel-money-cd") return [];

    const clientId = (values.client_id ?? "").trim() || masked.client_id;
    const clientSecret = (values.client_secret ?? "").trim() || masked.client_secret;
    const merchantId = (values.merchant_id ?? "").trim() || masked.merchant_id;
    const baseUrl = (values.base_url ?? "").trim() || masked.base_url;
    const callbackSecret = (values.callback_secret ?? "").trim() || masked.callback_secret;

    const checks: AirtelCheck[] = [];

    checks.push({
      id: "client_id",
      label: "Client ID",
      ok: !!clientId,
      message: clientId ? "Client ID renseigné" : "Le Client ID est manquant — obtenez-le sur le portail Airtel.",
    });

    checks.push({
      id: "client_secret",
      label: "Client Secret",
      ok: !!clientSecret,
      message: clientSecret
        ? "Client Secret renseigné"
        : "Le Client Secret est manquant — il est requis pour l’authentification OAuth2.",
    });

    checks.push({
      id: "merchant_id",
      label: "Merchant ID",
      ok: !!merchantId,
      message: merchantId
        ? "Merchant ID renseigné"
        : "Le Merchant ID est manquant — c’est votre compte marchand Airtel.",
    });

    let urlCheck: AirtelCheck;
    let parsedHost = "";
    try {
      const url = new URL(baseUrl);
      parsedHost = url.hostname.toLowerCase();
      if (url.protocol !== "https:") {
        urlCheck = {
          id: "base_url",
          label: "URL de base",
          ok: false,
          message: "L’URL de base doit être en HTTPS (ex: https://openapiuat.airtel.africa).",
        };
      } else if (env === "sandbox" && !parsedHost.includes("uat")) {
        urlCheck = {
          id: "base_url",
          label: "URL de base",
          ok: false,
          message: `En sandbox, l’URL doit pointer vers l’UAT (openapiuat.airtel.africa), pas vers ${parsedHost}.`,
        };
      } else if (env === "live" && parsedHost.includes("uat")) {
        urlCheck = {
          id: "base_url",
          label: "URL de base",
          ok: false,
          message: `En production, l’URL ne doit pas pointer vers le sandbox UAT (${parsedHost}).`,
        };
      } else {
        urlCheck = {
          id: "base_url",
          label: "URL de base",
          ok: true,
          message: `URL conforme à l’environnement ${env === "sandbox" ? "sandbox" : "production"}.`,
        };
      }
    } catch {
      urlCheck = {
        id: "base_url",
        label: "URL de base",
        ok: false,
        message: baseUrl
          ? "L’URL de base n’est pas valide (ex: https://openapiuat.airtel.africa)."
          : "L’URL de base Airtel est manquante.",
      };
    }
    checks.push(urlCheck);

    const cbLen = callbackSecret.length;
    checks.push({
      id: "callback_secret",
      label: "Secret de callback",
      ok: cbLen >= 16,
      message:
        cbLen >= 16
          ? `Secret de callback sécurisé (${cbLen} caractères).`
          : cbLen === 0
            ? "Le secret de callback est manquant — il est requis pour vérifier les webhooks."
            : `Le secret de callback est trop court (${cbLen} caractères) — minimum 16 caractères requis.`,
    });

    return checks;
  }, [slug, env, values, masked]);
}

function ConnectPage() {
  const { slug } = Route.useParams();

  const navigate = useNavigate();
  const qc = useQueryClient();
  const providersFn = useServerFn(listProviders);
  const connectionsFn = useServerFn(listMyConnections);
  const upsertFn = useServerFn(upsertConnection);

  const provQ = useQuery({ queryKey: ["providers"], queryFn: () => providersFn() });
  const connQ = useQuery({ queryKey: ["my-connections"], queryFn: () => connectionsFn() });

  const provider = (provQ.data ?? []).find((p) => p.slug === slug);
  const conn = provider
    ? (connQ.data ?? []).find((c) => c.provider_id === provider.id)
    : undefined;

  const [values, setValues] = useState<Record<string, string>>({});
  const [env, setEnv] = useState<"sandbox" | "live">(
    (conn?.environment as "sandbox" | "live") ?? "sandbox",
  );

  if (provQ.isLoading) {
    return (
      <SiteLayout>
        <div className="container-page py-10">Chargement…</div>
      </SiteLayout>
    );
  }
  if (!provider) throw notFound();

  const fields = (provider.credential_fields as CredentialField[]) ?? [];
  const masked = (conn?.credentials_masked ?? {}) as Record<string, string>;
  const isConnected = conn?.status === "active";
  const checks = useAirtelChecks(slug, env, values, masked);
  const airtelBlockingCount = checks.filter((c) => !c.ok).length;


  const connectMut = useMutation({
    mutationFn: () =>
      upsertFn({
        data: {
          provider_id: provider.id,
          environment: env,
          credentials: values,
        },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["my-connections"] });
      navigate({ to: "/integrations/$slug", params: { slug } });
    },
  });

  return (
    <SiteLayout>
      <section className="container-page py-10 grid gap-6 max-w-xl">
        <Link
          to="/integrations/$slug"
          params={{ slug }}
          className="text-sm text-muted-foreground hover:underline"
        >
          ← Retour au connecteur
        </Link>

        <header className="flex items-center gap-4">
          <div
            className="grid h-16 w-16 place-items-center rounded-2xl text-3xl shrink-0"
            style={{
              background: provider.brand_color
                ? `${provider.brand_color}22`
                : "var(--muted)",
            }}
          >
            <span>{provider.logo_emoji ?? "🔌"}</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold">Se connecter à {provider.name}</h1>
            <p className="text-sm text-muted-foreground">
              {TYPE_LABEL[provider.type]}
              {provider.country ? ` · ${provider.country}` : ""}
            </p>
          </div>
        </header>

        {/* Required credentials overview */}
        <div className="rounded-2xl border bg-card p-5 grid gap-3">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Identifiants requis</h2>
            <span
              className={`text-xs rounded-full px-2 py-0.5 ${
                isConnected
                  ? "bg-green-100 text-green-700"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {isConnected ? "● Déjà connecté" : "○ Non connecté"}
            </span>
          </div>
          {fields.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Aucun identifiant requis — cliquez sur « Se connecter » pour activer.
            </p>
          ) : (
            <ul className="grid gap-1.5 text-sm">
              {fields.map((f) => (
                <li key={f.key} className="flex items-center gap-2">
                  <span
                    className={
                      masked[f.key]
                        ? "text-green-600"
                        : "text-muted-foreground"
                    }
                  >
                    {masked[f.key] ? "✓" : "○"}
                  </span>
                  <span className="font-medium">{f.label}</span>
                  <span className="text-[10px] uppercase text-muted-foreground">
                    {f.type}
                  </span>
                  {f.required && (
                    <span className="text-xs text-red-600">requis</span>
                  )}
                </li>
              ))}
            </ul>
          )}
          {provider.docs_url && (
            <a
              href={provider.docs_url}
              target="_blank"
              rel="noreferrer"
              className="text-xs underline text-muted-foreground"
            >
              Où obtenir ces identifiants ? ↗
            </a>
          )}
        </div>

        {/* Airtel activation diagnostic */}
        {provider.slug === "airtel-money-cd" && checks.length > 0 && (
          <div className="rounded-2xl border bg-card p-5 grid gap-3">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold flex items-center gap-2">
                Diagnostic d’activation Airtel
              </h2>
              {airtelBlockingCount === 0 ? (
                <span className="text-xs rounded-full px-2 py-0.5 bg-green-100 text-green-700">
                  ✓ Prêt à activer
                </span>
              ) : (
                <span className="text-xs rounded-full px-2 py-0.5 bg-red-100 text-red-700">
                  {airtelBlockingCount} blocage{airtelBlockingCount > 1 ? "s" : ""}
                </span>
              )}
            </div>
            <ul className="grid gap-2 text-sm">
              {checks.map((c) => (
                <li key={c.id} className="flex items-start gap-2">
                  <span className={c.ok ? "text-green-600 mt-0.5" : "text-red-600 mt-0.5"}>
                    {c.ok ? "✓" : "✕"}
                  </span>
                  <div className="grid gap-0.5">
                    <span className="font-medium">{c.label}</span>
                    <span className={c.ok ? "text-muted-foreground text-xs" : "text-red-600 text-xs"}>
                      {c.message}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Connect form */}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            connectMut.mutate();
          }}
          className="rounded-2xl border bg-card p-5 grid gap-3"
        >
          <fieldset className="grid gap-2 rounded-xl border p-4 bg-muted/30">
            <legend className="px-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Environnement
            </legend>
            <div className="grid grid-cols-2 gap-2">
              {(["sandbox", "live"] as const).map((opt) => (
                <button
                  type="button"
                  key={opt}
                  onClick={() => setEnv(opt)}
                  className={`rounded-lg border px-3 py-2 text-sm font-medium transition ${
                    env === opt
                      ? opt === "live"
                        ? "border-red-500 bg-red-50 text-red-700"
                        : "border-amber-500 bg-amber-50 text-amber-800"
                      : "bg-background text-muted-foreground hover:bg-muted"
                  }`}
                >
                  {opt === "sandbox" ? "🧪 Sandbox (test)" : "🚀 Production (live)"}
                </button>
              ))}
            </div>
            {provider.slug === "airtel-money-cd" && (
              <p className="text-[11px] text-muted-foreground">
                URL attendue : <code>https://openapiuat.airtel.africa</code> en sandbox,{" "}
                <code>https://openapi.airtel.africa</code> en production. Le secret de
                callback doit faire ≥ 16 caractères, sinon l'activation est bloquée.
              </p>
            )}
          </fieldset>


          {fields.map((f) => (
            <label key={f.key} className="grid gap-1.5 text-sm">
              <span className="font-medium">
                {f.label}
                {f.required ? " *" : ""}
              </span>
              <input
                type={f.type}
                value={values[f.key] ?? ""}
                onChange={(e) =>
                  setValues({ ...values, [f.key]: e.target.value })
                }
                placeholder={masked[f.key] || `Saisir ${f.label}`}
                className="rounded-lg border px-3 py-2 bg-background font-mono text-sm"
                required={f.required && !masked[f.key]}
              />
              {masked[f.key] && (
                <span className="text-[11px] text-muted-foreground">
                  Actuel : {masked[f.key]} — laissez vide pour conserver
                </span>
              )}
            </label>
          ))}

          {connectMut.isError && (
            <p className="text-sm text-red-600">
              {(connectMut.error as Error).message}
            </p>
          )}

          {airtelBlockingCount > 0 && (
            <p className="text-xs text-red-600">
              Corrigez les points marqués en rouge ci-dessus avant de pouvoir activer Airtel Money.
            </p>
          )}

          <button
            disabled={connectMut.isPending || airtelBlockingCount > 0}
            className="rounded-full gradient-cta text-[var(--cta-foreground)] px-5 py-3 text-sm font-semibold disabled:opacity-60"
          >
            {connectMut.isPending
              ? "Connexion…"
              : isConnected
                ? "🔄 Mettre à jour la connexion"
                : "🔌 Se connecter"}
          </button>

        </form>
      </section>
    </SiteLayout>
  );
}
