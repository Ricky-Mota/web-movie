import { createFileRoute, Link, notFound, redirect } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { SiteLayout } from "@/components/site/Layout";
import { ConfirmModal } from "@/components/ui/ConfirmModal";
import { getMyRoles } from "@/lib/admin.functions";

import {
  listProviders,
  listMyConnections,
  upsertConnection,
  toggleConnection,
  deleteConnection,
  testConnection,
  type CredentialField,
} from "@/lib/integrations.functions";

export const Route = createFileRoute("/_authenticated/integrations/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `Connecteur ${params.slug} — ZbossPay` },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  beforeLoad: async () => {
    const roles = await getMyRoles();
    if (!roles.includes("admin")) {
      throw redirect({ to: "/dashboard" });
    }
  },
  component: ProviderDetailPage,
  errorComponent: ({ error }) => (
    <SiteLayout>
      <div className="container-page py-10">
        <p className="text-red-600">{error.message}</p>
        <Link to="/integrations" className="text-sm underline">
          ← Retour aux intégrations
        </Link>
      </div>
    </SiteLayout>
  ),
  notFoundComponent: () => (
    <SiteLayout>
      <div className="container-page py-10">
        <p>Connecteur introuvable.</p>
        <Link to="/integrations" className="text-sm underline">
          ← Retour aux intégrations
        </Link>
      </div>
    </SiteLayout>
  ),
});

const REGION_LABEL = {
  rdc: "🇨🇩 RDC",
  africa: "🌍 Afrique",
  international: "🌐 International",
} as const;

const TYPE_LABEL = {
  mobile_money: "Mobile Money",
  bank: "Banque",
  card_network: "Réseau de cartes",
  microfinance: "Microfinance",
  aggregator: "Compte agrégé",
} as const;

const STATUS_BADGE: Record<string, { label: string; cls: string }> = {
  active: { label: "● Connecté", cls: "bg-green-100 text-green-700" },
  disabled: { label: "○ Désactivé", cls: "bg-muted text-muted-foreground" },
  pending: { label: "○ En attente", cls: "bg-yellow-100 text-yellow-700" },
  none: { label: "○ Non configuré", cls: "bg-muted text-muted-foreground" },
};

function ProviderDetailPage() {
  const { slug } = Route.useParams();
  const qc = useQueryClient();
  const providersFn = useServerFn(listProviders);
  const connectionsFn = useServerFn(listMyConnections);
  const upsertFn = useServerFn(upsertConnection);
  const toggleFn = useServerFn(toggleConnection);
  const deleteFn = useServerFn(deleteConnection);
  const testFn = useServerFn(testConnection);

  const provQ = useQuery({
    queryKey: ["providers"],
    queryFn: () => providersFn(),
  });
  const connQ = useQuery({
    queryKey: ["my-connections"],
    queryFn: () => connectionsFn(),
  });

  const provider = (provQ.data ?? []).find((p) => p.slug === slug);
  const conn = provider
    ? (connQ.data ?? []).find((c) => c.provider_id === provider.id)
    : undefined;

  const fields = (provider?.credential_fields as CredentialField[]) ?? [];
  const masked = (conn?.credentials_masked ?? {}) as Record<string, string>;

  const [values, setValues] = useState<Record<string, string>>({});
  const [env, setEnv] = useState<"sandbox" | "live">("sandbox");
  const [showDeleteModal, setShowDeleteModal] = useState(false);


  if (provQ.isLoading || connQ.isLoading) {
    return (
      <SiteLayout>
        <div className="container-page py-10">Chargement…</div>
      </SiteLayout>
    );
  }
  if (!provQ.isLoading && !provider) throw notFound();
  if (!provider) return null;

  const currentEnv = conn?.environment ?? env;

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["my-connections"] });
  };

  const saveMut = useMutation({
    mutationFn: () =>
      upsertFn({
        data: {
          provider_id: provider.id,
          environment: conn ? conn.environment : env,
          credentials: values,
        },
      }),
    onSuccess: () => {
      setValues({});
      invalidate();
    },
  });

  const toggleMut = useMutation({
    mutationFn: (enabled: boolean) =>
      toggleFn({ data: { provider_id: provider.id, enabled } }),
    onSuccess: invalidate,
  });

  const testMut = useMutation({
    mutationFn: () => testFn({ data: { provider_id: provider.id } }),
    onSuccess: (res) => {
      invalidate();
      alert(`Test ${res.status === "ok" ? "✅" : "❌"} — ${res.message}`);
    },
    onError: (err) => alert(`Test échoué : ${(err as Error).message}`),
  });

  const delMut = useMutation({
    mutationFn: () => deleteFn({ data: { provider_id: provider.id } }),
    onSuccess: invalidate,
  });

  const statusKey = conn ? conn.status : "none";
  const badge = STATUS_BADGE[statusKey] ?? STATUS_BADGE.none;

  return (
    <SiteLayout>
      <section className="container-page py-10 grid gap-6 max-w-3xl">
        <Link to="/integrations" className="text-sm text-muted-foreground hover:underline">
          ← Toutes les intégrations
        </Link>

        <header className="flex items-start gap-4">
          <div
            className="grid h-16 w-16 place-items-center rounded-2xl text-3xl shrink-0"
            style={{
              background: provider.brand_color
                ? `${provider.brand_color}22`
                : "var(--muted)",
            }}
          >
            <span>{provider.logo_emoji ?? "🔌"}</span>
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl font-bold">{provider.name}</h1>
              <span className={`text-xs rounded-full px-2 py-0.5 ${badge.cls}`}>
                {badge.label}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              {TYPE_LABEL[provider.type]} · {REGION_LABEL[provider.region]}
              {provider.country ? ` · ${provider.country}` : ""}
            </p>
            {provider.docs_url && (
              <a
                href={provider.docs_url}
                target="_blank"
                rel="noreferrer"
                className="text-xs underline text-muted-foreground"
              >
                Documentation officielle ↗
              </a>
            )}
          </div>
        </header>

        {/* Connection status panel */}
        <div className="rounded-2xl border bg-card p-5 grid gap-3">
          <h2 className="font-semibold">État de la connexion</h2>
          <dl className="grid sm:grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-muted-foreground">Statut</dt>
              <dd className="font-medium">{badge.label}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Environnement</dt>
              <dd className="font-medium capitalize">{currentEnv}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Dernier test</dt>
              <dd
                className={
                  conn?.last_test_status === "ok"
                    ? "text-green-600 font-medium"
                    : conn?.last_test_status === "failed"
                      ? "text-red-600 font-medium"
                      : "font-medium"
                }
              >
                {conn?.last_test_status ?? "—"}
              </dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Testé le</dt>
              <dd className="font-medium">
                {conn?.last_tested_at
                  ? new Date(conn.last_tested_at).toLocaleString()
                  : "—"}
              </dd>
            </div>
          </dl>
          {conn?.last_test_message && (
            <p className="text-xs text-muted-foreground border-t pt-2">
              {conn.last_test_message}
            </p>
          )}

          {conn && (
            <div className="flex gap-2 flex-wrap pt-1">
              <button
                onClick={() => testMut.mutate()}
                disabled={testMut.isPending}
                className="rounded-full border px-3 py-1.5 text-xs hover:bg-muted"
              >
                🔌 Tester la connexion
              </button>
              <button
                onClick={() => toggleMut.mutate(conn.status !== "active")}
                className="rounded-full border px-3 py-1.5 text-xs hover:bg-muted"
              >
                {conn.status === "active" ? "⏸ Désactiver" : "▶ Réactiver"}
              </button>
              <button
                onClick={() => setShowDeleteModal(true)}
                className="rounded-full border px-3 py-1.5 text-xs hover:bg-muted text-red-600"
              >
                🗑 Supprimer
              </button>
            </div>
          )}
        </div>

        {showDeleteModal && (
          <ConfirmModal
            title="Confirmer la suppression"
            message={`Vous êtes sur le point de supprimer la connexion à ${provider.name}. Cette action est irréversible et les identifiants associés seront définitivement effacés.`}
            confirmLabel="Confirmer la suppression"
            onCancel={() => setShowDeleteModal(false)}
            onConfirm={() => {
              setShowDeleteModal(false);
              delMut.mutate();
            }}
            isPending={delMut.isPending}
          />
        )}


        {/* Credentials panel */}
        <div className="rounded-2xl border bg-card p-5 grid gap-4">
          <div>
            <h2 className="font-semibold">Identifiants requis</h2>
            <p className="text-xs text-muted-foreground mt-1">
              Stockés de manière chiffrée. Les valeurs existantes sont masquées —
              laissez vide pour conserver.
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              saveMut.mutate();
            }}
            className="grid gap-3"
          >
            {!conn && (
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Environnement</span>
                <select
                  value={env}
                  onChange={(e) => setEnv(e.target.value as "sandbox" | "live")}
                  className="rounded-lg border px-3 py-2 bg-background"
                >
                  <option value="sandbox">Sandbox (test)</option>
                  <option value="live">Production</option>
                </select>
              </label>
            )}

            {fields.length === 0 && (
              <p className="text-sm text-muted-foreground">
                Aucun identifiant requis pour ce connecteur.
              </p>
            )}

            {fields.map((f) => (
              <label key={f.key} className="grid gap-1.5 text-sm">
                <span className="font-medium">
                  {f.label}
                  {f.required ? " *" : ""}
                  <span className="ml-2 text-[10px] uppercase text-muted-foreground">
                    {f.type}
                  </span>
                </span>
                <input
                  type={f.type}
                  value={values[f.key] ?? ""}
                  onChange={(e) =>
                    setValues({ ...values, [f.key]: e.target.value })
                  }
                  placeholder={masked[f.key] || `Saisir ${f.label}`}
                  className="rounded-lg border px-3 py-2 bg-background font-mono text-sm"
                  required={f.required && !masked[f.key]}
                />
                {masked[f.key] && (
                  <span className="text-[11px] text-muted-foreground">
                    Actuel : {masked[f.key]}
                  </span>
                )}
              </label>
            ))}

            {saveMut.isError && (
              <p className="text-sm text-red-600">
                {(saveMut.error as Error).message}
              </p>
            )}
            {saveMut.isSuccess && (
              <p className="text-sm text-green-600">
                ✓ Identifiants enregistrés.
              </p>
            )}

            {fields.length > 0 && (
              <button
                disabled={saveMut.isPending}
                className="rounded-full gradient-brand text-white px-4 py-2.5 text-sm font-semibold disabled:opacity-60"
              >
                {saveMut.isPending
                  ? "Enregistrement…"
                  : conn
                    ? "Mettre à jour"
                    : "Activer la connexion"}
              </button>
            )}
          </form>
        </div>
      </section>
    </SiteLayout>
  );
}
