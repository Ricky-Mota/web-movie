import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { SiteLayout } from "@/components/site/Layout";
import { ConfirmModal } from "@/components/ui/ConfirmModal";
import { getMyRoles } from "@/lib/admin.functions";

import {
  listProviders,
  listMyConnections,
  upsertConnection,
  toggleConnection,
  deleteConnection,
  testConnection,
  type CredentialField,
} from "@/lib/integrations.functions";

export const Route = createFileRoute("/_authenticated/integrations")({
  head: () => ({
    meta: [
      { title: "Intégrations — ZbossPay" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  beforeLoad: async () => {
    const roles = await getMyRoles();
    if (!roles.includes("admin")) {
      throw redirect({
        to: "/dashboard",
        search: { unauthorized: "integrations" },
      });
    }
  },
  component: IntegrationsPage,
});

type Provider = Awaited<ReturnType<typeof listProviders>>[number];
type Connection = Awaited<ReturnType<typeof listMyConnections>>[number];

const REGION_LABEL: Record<Provider["region"], string> = {
  rdc: "🇨🇩 République Démocratique du Congo",
  africa: "🌍 Afrique",
  international: "🌐 International",
};

const TYPE_LABEL: Record<Provider["type"], string> = {
  mobile_money: "Mobile Money",
  bank: "Banque",
  card_network: "Réseau de cartes",
  microfinance: "Microfinance",
  aggregator: "Compte agrégé",
};

function IntegrationsPage() {
  const qc = useQueryClient();
  const providersFn = useServerFn(listProviders);
  const connectionsFn = useServerFn(listMyConnections);

  const provQ = useQuery({
    queryKey: ["providers"],
    queryFn: () => providersFn(),
  });
  const connQ = useQuery({
    queryKey: ["my-connections"],
    queryFn: () => connectionsFn(),
  });

  const [filter, setFilter] = useState<"all" | Provider["region"]>("all");
  const [editing, setEditing] = useState<Provider | null>(null);

  const grouped = useMemo(() => {
    const list = (provQ.data ?? []).filter(
      (p) => filter === "all" || p.region === filter,
    );
    const byRegion = new Map<Provider["region"], Provider[]>();
    for (const p of list) {
      if (!byRegion.has(p.region)) byRegion.set(p.region, []);
      byRegion.get(p.region)!.push(p);
    }
    return byRegion;
  }, [provQ.data, filter]);

  const connByProvider = useMemo(() => {
    const map = new Map<string, Connection>();
    for (const c of connQ.data ?? []) map.set(c.provider_id, c);
    return map;
  }, [connQ.data]);

  const depotCommun = useMemo(
    () => (provQ.data ?? []).find((p) => p.slug === "depot-commun") ?? null,
    [provQ.data],
  );
  const depotConn = depotCommun ? connByProvider.get(depotCommun.id) : null;
  const depotActive = depotConn?.status === "active";

  const invalidate = () =>
    qc.invalidateQueries({ queryKey: ["my-connections"] });

  return (
    <SiteLayout>
      <section className="container-page py-10 grid gap-6">
        <header className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-3xl font-bold">Intégrations partenaires</h1>
            <p className="text-sm text-muted-foreground mt-1 max-w-2xl">
              Activez les opérateurs mobile money et banques que vous souhaitez
              proposer à vos clients. Vos identifiants partenaires sont stockés
              de manière chiffrée et ne sont jamais affichés en clair.
            </p>
          </div>
          <Link
            to="/dashboard"
            className="text-sm rounded-full border px-4 py-2 hover:bg-muted"
          >
            ← Tableau de bord
          </Link>
        </header>

        {depotCommun && (
          <Link
            to="/integrations/$slug"
            params={{ slug: depotCommun.slug }}
            className="rounded-2xl border bg-card p-4 flex items-center gap-4 hover:bg-muted/40 transition"
          >
            <div
              className="grid h-12 w-12 place-items-center rounded-xl text-2xl shrink-0"
              style={{
                background: depotCommun.brand_color
                  ? `${depotCommun.brand_color}22`
                  : "var(--muted)",
              }}
            >
              <span>{depotCommun.logo_emoji ?? "🏦"}</span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-semibold">{depotCommun.name}</h2>
                <span
                  className={`inline-flex items-center gap-1.5 text-[11px] uppercase tracking-wide rounded-full px-2 py-0.5 ${
                    depotActive
                      ? "bg-green-100 text-green-700"
                      : "bg-orange-100 text-orange-700"
                  }`}
                >
                  <span
                    className={`h-2 w-2 rounded-full ${
                      depotActive
                        ? "bg-green-500 animate-pulse"
                        : "bg-orange-500"
                    }`}
                  />
                  {depotActive ? "Actif" : "Inactif"}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                Compte agrégé ZbossPay — encaissez dépôts et paiements sans
                configuration. {depotConn?.environment === "live" ? "Production" : depotConn?.environment ?? ""}
                {depotConn?.last_test_message ? ` · ${depotConn.last_test_message}` : ""}
              </p>
            </div>
            <span className="text-sm text-muted-foreground shrink-0">
              Détails →
            </span>
          </Link>
        )}


        <div className="flex gap-2 flex-wrap">
          {(["all", "rdc", "africa", "international"] as const).map((k) => (
            <button
              key={k}
              onClick={() => setFilter(k)}
              className={`text-sm rounded-full px-4 py-2 border transition ${
                filter === k
                  ? "bg-foreground text-background border-foreground"
                  : "hover:bg-muted"
              }`}
            >
              {k === "all" ? "Tous" : REGION_LABEL[k]}
            </button>
          ))}
        </div>

        {provQ.isLoading && (
          <p className="text-sm text-muted-foreground">Chargement…</p>
        )}

        {[...grouped.entries()].map(([region, items]) => (
          <div key={region} className="grid gap-3">
            <h2 className="text-lg font-semibold mt-4">
              {REGION_LABEL[region]}
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {items.map((p) => {
                const conn = connByProvider.get(p.id);
                const isLive = p.status === "live";
                const isActive = conn?.status === "active";
                return (
                  <div
                    key={p.id}
                    className="rounded-2xl border bg-card p-4 flex flex-col gap-3"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className="grid h-11 w-11 place-items-center rounded-xl text-xl shrink-0"
                        style={{
                          background: p.brand_color
                            ? `${p.brand_color}22`
                            : "var(--muted)",
                        }}
                      >
                        <span>{p.logo_emoji ?? "🔌"}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-semibold truncate">{p.name}</h3>
                          {!isLive && (
                            <span className="text-[10px] uppercase tracking-wide rounded-full bg-orange-100 text-orange-700 px-2 py-0.5">
                              Bientôt
                            </span>
                          )}
                          {isActive ? (
                            <span className="text-[10px] uppercase tracking-wide rounded-full bg-green-100 text-green-700 px-2 py-0.5">
                              ● Actif
                            </span>
                          ) : isLive ? (
                            <Link
                              to="/integrations/$slug/connect"
                              params={{ slug: p.slug }}
                              className="text-[10px] uppercase tracking-wide rounded-full bg-[var(--cta)]/15 text-[var(--cta)] hover:bg-[var(--cta)]/25 px-2 py-0.5 font-semibold transition"
                            >
                              ⚡ Activer l'API
                            </Link>
                          ) : null}
                          {conn?.status === "disabled" && (
                            <span className="text-[10px] uppercase tracking-wide rounded-full bg-muted text-muted-foreground px-2 py-0.5">
                              Désactivé
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {TYPE_LABEL[p.type]}
                          {p.country ? ` · ${p.country}` : ""}
                        </p>
                      </div>
                    </div>

                    {conn && (
                      <div className="text-xs text-muted-foreground">
                        Env :{" "}
                        <span className="font-medium">{conn.environment}</span>
                        {conn.last_test_status !== "untested" && (
                          <>
                            {" · "}Test :{" "}
                            <span
                              className={
                                conn.last_test_status === "ok"
                                  ? "text-green-600"
                                  : "text-red-600"
                              }
                            >
                              {conn.last_test_status}
                            </span>
                          </>
                        )}
                      </div>
                    )}

                    <div className="flex items-center gap-2 mt-auto">
                      <Link
                        to="/integrations/$slug"
                        params={{ slug: p.slug }}
                        className="flex-1 text-center rounded-full border px-3 py-2 text-sm hover:bg-muted"
                      >
                        Détails & statut
                      </Link>
                      <Link
                        to="/integrations/$slug/connect"
                        params={{ slug: p.slug }}
                        disabled={!isLive}
                        className="flex-1 text-center rounded-full gradient-cta text-[var(--cta-foreground)] px-3 py-2 text-sm font-semibold aria-disabled:opacity-50"
                        aria-disabled={!isLive}
                      >
                        {conn ? "Reconnecter" : "Se connecter"}
                      </Link>
                      {conn && (
                        <ConnectionMenu
                          providerId={p.id}
                          enabled={isActive}
                          onChanged={invalidate}
                        />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {editing && (
          <CredentialModal
            provider={editing}
            existing={connByProvider.get(editing.id) ?? null}
            onClose={() => setEditing(null)}
            onSaved={() => {
              setEditing(null);
              invalidate();
            }}
          />
        )}
      </section>
    </SiteLayout>
  );
}

function ConnectionMenu({
  providerId,
  enabled,
  onChanged,
}: {
  providerId: string;
  enabled: boolean;
  onChanged: () => void;
}) {
  const toggleFn = useServerFn(toggleConnection);
  const deleteFn = useServerFn(deleteConnection);
  const testFn = useServerFn(testConnection);
  const toggleMut = useMutation({
    mutationFn: (v: boolean) =>
      toggleFn({ data: { provider_id: providerId, enabled: v } }),
    onSuccess: onChanged,
  });
  const delMut = useMutation({
    mutationFn: () => deleteFn({ data: { provider_id: providerId } }),
    onSuccess: onChanged,
  });
  const testMut = useMutation({
    mutationFn: () => testFn({ data: { provider_id: providerId } }),
    onSuccess: (res) => {
      onChanged();
      alert(`Test ${res.status === "ok" ? "✅" : "❌"} — ${res.message}`);
    },
    onError: (err) => alert(`Test échoué : ${(err as Error).message}`),
  });
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  return (

    <div className="flex gap-1">
      <button
        title={enabled ? "Désactiver" : "Réactiver"}
        onClick={() => toggleMut.mutate(!enabled)}
        className="rounded-full border px-2 py-2 text-xs hover:bg-muted"
      >
        {enabled ? "⏸" : "▶"}
      </button>
      <button
        title="Tester la connexion"
        onClick={() => testMut.mutate()}
        className="rounded-full border px-2 py-2 text-xs hover:bg-muted"
      >
        🔌
      </button>
      <button
        title="Supprimer"
        onClick={() => setShowDeleteModal(true)}
        className="rounded-full border px-2 py-2 text-xs hover:bg-muted text-red-600"
      >
        🗑
      </button>

      {showDeleteModal && (
        <ConfirmModal
          title="Confirmer la suppression"
          message="Cette action est irréversible. Les identifiants associés à ce partenaire seront définitivement effacés."
          confirmLabel="Confirmer la suppression"
          onCancel={() => setShowDeleteModal(false)}
          onConfirm={() => {
            setShowDeleteModal(false);
            delMut.mutate();
          }}
          isPending={delMut.isPending}
        />
      )}
    </div>
  );
}


function CredentialModal({
  provider,
  existing,
  onClose,
  onSaved,
}: {
  provider: Provider;
  existing: Connection | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const fields = (provider.credential_fields as CredentialField[]) ?? [];
  const masked = (existing?.credentials_masked ?? {}) as Record<string, string>;
  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    for (const f of fields) init[f.key] = "";
    return init;
  });
  const [env, setEnv] = useState<"sandbox" | "live">(
    existing?.environment ?? "sandbox",
  );
  const upsertFn = useServerFn(upsertConnection);
  const mut = useMutation({
    mutationFn: () =>
      upsertFn({
        data: {
          provider_id: provider.id,
          environment: env,
          credentials: values,
        },
      }),
    onSuccess: onSaved,
  });

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 grid place-items-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-card rounded-2xl border max-w-md w-full p-6 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 mb-1">
          <span className="text-2xl">{provider.logo_emoji}</span>
          <h2 className="text-xl font-bold">{provider.name}</h2>
        </div>
        <p className="text-xs text-muted-foreground mb-4">
          {TYPE_LABEL[provider.type]} · saisissez vos identifiants partenaires
          fournis par {provider.name}.
        </p>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            mut.mutate();
          }}
          className="grid gap-3"
        >
          <label className="grid gap-1.5 text-sm">
            <span className="font-medium">Environnement</span>
            <select
              value={env}
              onChange={(e) => setEnv(e.target.value as "sandbox" | "live")}
              className="rounded-lg border px-3 py-2 bg-background"
            >
              <option value="sandbox">Sandbox (test)</option>
              <option value="live">Production</option>
            </select>
          </label>

          {fields.map((f) => (
            <label key={f.key} className="grid gap-1.5 text-sm">
              <span className="font-medium">
                {f.label}
                {f.required ? " *" : ""}
              </span>
              <input
                type={f.type}
                value={values[f.key] ?? ""}
                onChange={(e) =>
                  setValues({ ...values, [f.key]: e.target.value })
                }
                placeholder={masked[f.key] || ""}
                className="rounded-lg border px-3 py-2 bg-background font-mono text-sm"
                required={f.required && !masked[f.key]}
              />
              {masked[f.key] && (
                <span className="text-[11px] text-muted-foreground">
                  Actuel : {masked[f.key]} — laissez vide pour conserver
                </span>
              )}
            </label>
          ))}

          {mut.isError && (
            <p className="text-sm text-red-600">
              {(mut.error as Error).message}
            </p>
          )}

          <div className="flex gap-2 mt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-full border px-4 py-2.5 text-sm hover:bg-muted"
            >
              Annuler
            </button>
            <button
              disabled={mut.isPending}
              className="flex-1 rounded-full gradient-brand text-white px-4 py-2.5 text-sm font-semibold disabled:opacity-60"
            >
              {mut.isPending ? "Enregistrement…" : "Enregistrer"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
