import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { SiteLayout } from "@/components/site/Layout";
import { getMyKyc, submitKyc } from "@/lib/kyc.functions";
import { DocumentUpload, type DocumentKind } from "@/components/kyc/DocumentUpload";

export const Route = createFileRoute("/_authenticated/kyc")({
  head: () => ({
    meta: [
      { title: "Vérification KYC — ZbossPay" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: KycPage,
});

type DocKey = "rccm_doc_url" | "nif_doc_url" | "id_doc_url" | "selfie_url";

const DOC_LABELS: Record<DocKey, { label: string; help: string }> = {
  rccm_doc_url: { label: "Document RCCM", help: "Registre du commerce (PDF ou image)" },
  nif_doc_url: { label: "Attestation NIF", help: "Numéro d'identification fiscale" },
  id_doc_url: { label: "Pièce d'identité", help: "Carte d'électeur, passeport ou permis" },
  selfie_url: { label: "Selfie avec pièce", help: "Photo claire de votre visage tenant la pièce" },
};

function KycPage() {
  const qc = useQueryClient();
  const getFn = useServerFn(getMyKyc);
  const submitFn = useServerFn(submitKyc);

  const kyc = useQuery({ queryKey: ["kyc", "me"], queryFn: () => getFn() });

  const existing = kyc.data;
  const locked = existing?.status === "approved";

  const [form, setForm] = useState({
    entity_type: (existing?.entity_type ?? "individual") as "individual" | "company",
    legal_name: existing?.legal_name ?? "",
    rccm_number: existing?.rccm_number ?? "",
    nif_number: existing?.nif_number ?? "",
    id_number: existing?.id_number ?? "",
    phone: existing?.phone ?? "",
    address: existing?.address ?? "",
    city: existing?.city ?? "",
  });

  const [docs, setDocs] = useState<Record<DocKey, string>>({
    rccm_doc_url: existing?.rccm_doc_url ?? "",
    nif_doc_url: existing?.nif_doc_url ?? "",
    id_doc_url: existing?.id_doc_url ?? "",
    selfie_url: existing?.selfie_url ?? "",
  });

  const DOC_KIND: Record<DocKey, DocumentKind> = {
    rccm_doc_url: "rccm",
    nif_doc_url: "nif",
    id_doc_url: "id",
    selfie_url: "selfie",
  };

  const mut = useMutation({
    mutationFn: async () => {
      for (const k of Object.keys(DOC_LABELS) as DocKey[]) {
        if (!docs[k]) throw new Error(`${DOC_LABELS[k].label} manquant`);
      }
      return submitFn({
        data: { ...form, country: "CD", ...docs },
      });
    },
    onSuccess: () => {
      toast.success("Dossier soumis", {
        description: "Un administrateur va l'examiner sous 24-48h.",
      });
      qc.invalidateQueries({ queryKey: ["kyc", "me"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <SiteLayout>
      <section className="container-page py-10 max-w-3xl space-y-8">
        <header className="space-y-2">
          <p className="text-xs uppercase tracking-widest text-[var(--cta)] font-semibold">
            Vérification d'identité
          </p>
          <h1 className="text-3xl md:text-4xl font-extrabold">
            Dossier KYC marchand
          </h1>
          <p className="text-muted-foreground">
            Ces informations sont exigées par la BCC pour activer les paiements
            réels. Vos documents sont chiffrés et accessibles uniquement par
            l'équipe conformité ZbossPay.
          </p>
        </header>

        {/* Status & actions */}
        <StatusCard
          status={existing?.status}
          reason={existing?.rejection_reason ?? null}
          submittedAt={existing?.submitted_at}
        />

        {/* Document checklist */}
        <div className="rounded-2xl border bg-card p-6 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h2 className="text-lg font-bold">Documents à fournir</h2>
            <span className="text-xs text-muted-foreground">
              {Object.values(docs).filter(Boolean).length} / {Object.keys(DOC_LABELS).length} fournis
            </span>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            {(Object.keys(DOC_LABELS) as DocKey[]).map((k) => (
              <div
                key={k}
                className={`flex items-start gap-3 rounded-xl border p-4 ${docs[k] ? "bg-green-50 border-green-200" : "bg-background"}`}
              >
                <div className={`mt-0.5 h-5 w-5 rounded-full border-2 flex items-center justify-center ${docs[k] ? "border-green-600 bg-green-600 text-white" : "border-muted-foreground/30"}`}>
                  {docs[k] ? "✓" : ""}
                </div>
                <div>
                  <p className="text-sm font-semibold">{DOC_LABELS[k].label}</p>
                  <p className="text-xs text-muted-foreground">{DOC_LABELS[k].help}</p>
                </div>
              </div>
            ))}
          </div>
          {locked && (
            <p className="text-sm text-green-800 bg-green-50 rounded-lg px-4 py-3">
              ✅ Votre dossier est approuvé. Vous n'avez plus besoin de modifier ces documents.
            </p>
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-3">
          {existing?.status === "approved" ? (
            <Link
              to="/dashboard"
              className="btn-cta rounded-full px-6 py-3 font-semibold inline-flex items-center"
            >
              Aller encaisser un paiement →
            </Link>
          ) : existing?.status === "rejected" ? (
            <button
              onClick={() => {
                const el = document.getElementById("kyc-form");
                el?.scrollIntoView({ behavior: "smooth" });
              }}
              className="btn-cta rounded-full px-6 py-3 font-semibold"
            >
              Corriger et resoumettre le dossier
            </button>
          ) : existing?.status === "pending" ? (
            <span className="inline-flex items-center gap-2 rounded-full border px-5 py-2.5 text-sm text-muted-foreground">
              <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse" />
              En attente de validation — inutile de resoumettre
            </span>
          ) : (
            <button
              onClick={() => {
                const el = document.getElementById("kyc-form");
                el?.scrollIntoView({ behavior: "smooth" });
              }}
              className="btn-cta rounded-full px-6 py-3 font-semibold"
            >
              Commencer la saisie du dossier
            </button>
          )}
          <Link to="/dashboard" className="text-sm underline">
            Retour au tableau de bord
          </Link>
        </div>

        <form
          id="kyc-form"
          onSubmit={(e) => {
            e.preventDefault();
            if (locked) return;
            mut.mutate();
          }}
          className="space-y-6"
        >
          <fieldset disabled={locked} className="space-y-6">
            <div className="rounded-2xl border bg-card p-6 space-y-4">
              <h2 className="text-lg font-bold">Identité légale</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Type d'entité">
                  <select
                    value={form.entity_type}
                    onChange={(e) =>
                      setForm((f) => ({
                        ...f,
                        entity_type: e.target.value as "individual" | "company",
                      }))
                    }
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                  >
                    <option value="individual">Personne physique</option>
                    <option value="company">Société</option>
                  </select>
                </Field>
                <Field label={form.entity_type === "company" ? "Raison sociale" : "Nom complet"}>
                  <Input
                    value={form.legal_name}
                    onChange={(v) => setForm((f) => ({ ...f, legal_name: v }))}
                    required
                  />
                </Field>
                <Field label="N° RCCM">
                  <Input
                    value={form.rccm_number}
                    onChange={(v) => setForm((f) => ({ ...f, rccm_number: v }))}
                    placeholder="CD/KIN/RCCM/..."
                    required
                  />
                </Field>
                <Field label="N° NIF (Impôt)">
                  <Input
                    value={form.nif_number}
                    onChange={(v) => setForm((f) => ({ ...f, nif_number: v }))}
                    required
                  />
                </Field>
                <Field label="N° pièce d'identité">
                  <Input
                    value={form.id_number}
                    onChange={(v) => setForm((f) => ({ ...f, id_number: v }))}
                    required
                  />
                </Field>
                <Field label="Téléphone">
                  <Input
                    value={form.phone}
                    onChange={(v) => setForm((f) => ({ ...f, phone: v }))}
                    placeholder="+243…"
                    required
                  />
                </Field>
                <Field label="Adresse">
                  <Input
                    value={form.address}
                    onChange={(v) => setForm((f) => ({ ...f, address: v }))}
                    required
                  />
                </Field>
                <Field label="Ville">
                  <Input
                    value={form.city}
                    onChange={(v) => setForm((f) => ({ ...f, city: v }))}
                    placeholder="Kinshasa"
                    required
                  />
                </Field>
              </div>
            </div>

            <div className="rounded-2xl border bg-card p-6 space-y-4">
              <h2 className="text-lg font-bold">Téléverser les documents</h2>
              <p className="text-sm text-muted-foreground">
                Formats acceptés : PDF, JPG, PNG · max 5 Mo par fichier.
              </p>
              <div className="grid sm:grid-cols-2 gap-4">
                {(Object.keys(DOC_LABELS) as DocKey[]).map((k) => (
                  <DocumentUpload
                    key={k}
                    kind={DOC_KIND[k]}
                    label={DOC_LABELS[k].label}
                    help={DOC_LABELS[k].help}
                    path={docs[k]}
                    required
                    disabled={locked}
                    onUploaded={(p) => setDocs((d) => ({ ...d, [k]: p }))}
                    onCleared={() => setDocs((d) => ({ ...d, [k]: "" }))}
                  />
                ))}
              </div>
            </div>
          </fieldset>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="submit"
              disabled={locked || mut.isPending}
              className="btn-cta rounded-full px-6 py-3 font-semibold disabled:opacity-50"
            >
              {mut.isPending ? "Envoi…" : existing ? "Mettre à jour le dossier" : "Soumettre le dossier"}
            </button>
          </div>
        </form>
      </section>
    </SiteLayout>
  );
}

function StatusCard({
  status,
  reason,
  submittedAt,
}: {
  status: "pending" | "approved" | "rejected" | undefined;
  reason: string | null;
  submittedAt: string | null | undefined;
}) {
  const configs = {
    approved: {
      icon: "✅",
      title: "Dossier approuvé",
      desc: "Votre identité marchand est validée. Vous pouvez maintenant encaisser des paiements réels.",
      className: "bg-green-50 border-green-200 text-green-900",
    },
    pending: {
      icon: "⏳",
      title: "Dossier en cours d'examen",
      desc: "Un administrateur examine votre dossier. Délai habituel : 24-48h ouvrées. Vous recevrez une notification par email.",
      className: "bg-amber-50 border-amber-200 text-amber-900",
    },
    rejected: {
      icon: "❌",
      title: "Dossier rejeté",
      desc: "Votre dossier ne peut pas être validé en l'état. Corrigez les informations ci-dessous et soumettez à nouveau.",
      className: "bg-red-50 border-red-200 text-red-900",
    },
  };

  if (!status) {
    return (
      <div className="rounded-2xl border bg-amber-50 border-amber-200 p-6 text-amber-900">
        <div className="flex items-start gap-4">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-amber-100 text-2xl">
            🔒
          </div>
          <div>
            <p className="text-lg font-bold">KYC non soumis</p>
            <p className="mt-1 text-sm text-amber-800/90">
              Complétez le formulaire ci-dessous et fournissez les 4 documents requis pour activer les paiements.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const cfg = configs[status];
  return (
    <div className={`rounded-2xl border p-6 ${cfg.className}`}>
      <div className="flex items-start gap-4">
        <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-white/70 text-2xl">
          {cfg.icon}
        </div>
        <div className="flex-1">
          <p className="text-lg font-bold">{cfg.title}</p>
          <p className="mt-1 text-sm opacity-90">{cfg.desc}</p>
          {status === "rejected" && reason && (
            <p className="mt-3 text-sm font-semibold">Motif du rejet : {reason}</p>
          )}
          {submittedAt && status !== "approved" && (
            <p className="mt-2 text-xs opacity-75">
              Dossier soumis le {new Date(submittedAt).toLocaleDateString("fr-FR", { dateStyle: "long" })}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="text-sm space-y-1 block">
      <span className="block font-medium">{label}</span>
      {children}
    </label>
  );
}

function Input({
  value,
  onChange,
  placeholder,
  required,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      required={required}
      className="w-full rounded-lg border px-3 py-2 text-sm"
    />
  );
}
