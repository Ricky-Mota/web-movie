import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { APP_EMAIL } from "@/lib/site-config";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import ogLogo from "../assets/og-home.jpg";
import { supabase } from "@/integrations/supabase/client";

// Paths anyone can reach without being signed in.
const PUBLIC_PATHS = new Set<string>([
  "/",
  "/about",
  "/products",
  "/solutions",
  "/payments",
  "/faq",
  "/contact",
  "/architecture",
  "/docs/integration",
  "/login",
  "/forgot-password",
  "/reset-password",
  "/reset-confirmed",
  "/payment/success",
  "/payment/cancel",
]);
const PUBLIC_PREFIXES = ["/api/", "/lovable/", "/sitemap.xml", "/robots.txt", "/llms.txt"];
// Authenticated areas live under /_authenticated and get their own gate.
// Everything else (marketing pages) is public.
const PROTECTED_PREFIXES = ["/dashboard", "/admin", "/integrations", "/airtel-test", "/account-phone"];
function isPublicPath(pathname: string) {
  if (PUBLIC_PATHS.has(pathname)) return true;
  if (PUBLIC_PREFIXES.some((p) => pathname.startsWith(p))) return true;
  return !PROTECTED_PREFIXES.some((p) => pathname === p || pathname.startsWith(p + "/"));
}


function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "ZbossPay — Paiement mobile en RDC" },
      { name: "description", content: "ZbossPay, la plateforme de paiement mobile de la RDC : encaissez, disbursez et payez via Airtel Money, Orange Money, M-Pesa, Afrimoney ou carte." },
      { property: "og:title", content: "ZbossPay — Paiement mobile en RDC" },
      { property: "og:description", content: "Encaissez vos clients en un tap. Orange, Airtel, M-Pesa, Afrimoney et carte — une seule intégration." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "ZbossPay" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "google-site-verification", content: "bq88CKFKt1OhhAy1FCWYedXcRtAJFsAOU7rgvxb-yPQ" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" },
      { rel: "stylesheet", href: appCss },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "ZbossPay",
          url: "/",
          logo: ogLogo,
          image: ogLogo,
          description: "Plateforme de paiement mobile de la RDC : encaissez, disbursez et payez via Airtel Money, Orange Money, M-Pesa, Afrimoney ou carte.",
          areaServed: { "@type": "Country", name: "Congo, République démocratique du" },
          contactPoint: [{
            "@type": "ContactPoint",
            contactType: "customer support",
            email: APP_EMAIL,
            telephone: "*5111#",
            availableLanguage: ["fr"],
          }],
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "ZbossPay",
          url: "/",
          inLanguage: "fr",
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [authReady, setAuthReady] = useState(false);
  const [authed, setAuthed] = useState(false);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setAuthed(!!data.session);
      setAuthReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setAuthed(!!session);
      setAuthReady(true);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!authReady) return;
    if (!authed && !isPublicPath(pathname)) {
      router.navigate({
        to: "/login",
        search: { redirect: pathname },
        replace: true,
      });
    }
  }, [authReady, authed, pathname, router]);

  const isPublic = isPublicPath(pathname);
  const blocked = authReady && !authed && !isPublic;
  const waiting = !authReady && !isPublic;

  return (
    <QueryClientProvider client={queryClient}>
      {blocked || waiting ? (
        <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
          Redirection vers la connexion…
        </div>
      ) : (
        /* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */
        <Outlet />
      )}
    </QueryClientProvider>
  );
}

