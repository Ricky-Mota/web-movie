import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "../components/site/Layout";
import { ShieldCheck, Award, Globe2, Activity } from "lucide-react";
import ogImage from "../assets/og-about.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Pourquoi ZbossPay — La fintech de la RDC" },
      { name: "description", content: "Découvrez pourquoi entreprises et particuliers choisissent ZbossPay pour leurs paiements mobiles en RDC." },
      { property: "og:title", content: "Pourquoi ZbossPay" },
      { property: "og:description", content: "Découvrez pourquoi entreprises et particuliers choisissent ZbossPay pour leurs paiements mobiles en RDC." },
      { property: "og:url", content: "/about" },
      { property: "og:image", content: ogImage },
      { property: "og:image:width", content: "1216" },
      { property: "og:image:height", content: "640" },
      { property: "og:image:alt", content: "Pourquoi ZbossPay — La fintech de la RDC" },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: "/about" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "AboutPage",
        name: "Pourquoi ZbossPay",
        url: "/about",
        about: {
          "@type": "Organization",
          name: "ZbossPay",
          description: "Établissement de paiement agréé par la Banque Centrale du Congo. Chiffrement TLS 1.3 / AES-256, conformité ISO 27001, uptime 99,9 %.",
        },
      }),
    }],
  }),
  component: AboutPage,
});

function AboutPage() {
  const points = [
    { icon: Award, t: "Agréé BCC", d: "Établissement de paiement agréé par la Banque Centrale du Congo." },
    { icon: ShieldCheck, t: "Chiffrement SSL/TLS", d: "TLS 1.3, AES-256 et conformité aux normes ISO 27001." },
    { icon: Globe2, t: "Leader fintech RDC", d: "Présent dans toutes les provinces de la République Démocratique du Congo." },
    { icon: Activity, t: "Uptime 99,9 %", d: "Infrastructure redondante avec SLA garanti pour les entreprises." },
  ];
  return (
    <SiteLayout>
      <section className="gradient-brand text-white">
        <div className="container-page py-20">
          <span className="chip bg-white/15 text-white border-white/20">À propos</span>
          <h1 className="mt-4 text-4xl md:text-5xl font-bold max-w-3xl">
            La plateforme de paiement mobile la plus complète de la RDC.
          </h1>
          <p className="mt-5 text-white/90 max-w-2xl">
            ZbossPay connecte tous les portefeuilles mobile money du pays — Airtel Money, Orange Money,
            M-Pesa, Afrimoney — ainsi que les cartes Visa et Mastercard, avec une seule intégration.
          </p>
        </div>
      </section>

      <section className="container-page py-16 grid md:grid-cols-2 lg:grid-cols-4 gap-5">
        {points.map((p) => (
          <div key={p.t} className="rounded-2xl border bg-card p-6">
            <p.icon className="text-[var(--cta)]" />
            <h3 className="mt-4 font-semibold">{p.t}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{p.d}</p>
          </div>
        ))}
      </section>

      <section className="container-page pb-20">
        <div className="rounded-3xl bg-[var(--muted)] p-10">
          <h2 className="text-2xl md:text-3xl font-bold">Notre mission</h2>
          <p className="mt-3 text-muted-foreground max-w-3xl">
            Rendre les paiements numériques accessibles à chaque Congolais et à chaque entreprise,
            partout, sécurisés et instantanés — avec ou sans connexion internet.
          </p>
          <div className="mt-6 flex gap-3 flex-wrap">
            <Link to="/contact" className="rounded-full gradient-brand text-white px-6 py-3 font-semibold">Nous contacter</Link>
            <Link to="/products" className="rounded-full border px-6 py-3 font-semibold">Voir les produits</Link>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
