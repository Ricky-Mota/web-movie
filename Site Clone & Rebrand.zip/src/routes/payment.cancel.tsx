import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";

export const Route = createFileRoute("/payment/cancel")({
  head: () => ({
    meta: [{ title: "Paiement annulé — ZbossPay" }],
  }),
  component: CancelPage,
});

function CancelPage() {
  return (
    <SiteLayout>
      <section className="container-page py-20 max-w-lg text-center">
        <h1 className="text-3xl font-bold">Paiement annulé</h1>
        <p className="mt-3 text-muted-foreground">
          Aucun montant n'a été débité. Vous pouvez réessayer à tout moment.
        </p>
        <Link
          to="/"
          className="inline-block mt-8 rounded-full border px-6 py-3 font-semibold hover:bg-muted"
        >
          Retour à l'accueil
        </Link>
      </section>
    </SiteLayout>
  );
}
