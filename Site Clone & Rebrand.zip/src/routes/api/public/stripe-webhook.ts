import { createFileRoute } from "@tanstack/react-router";
import type Stripe from "stripe";


export const Route = createFileRoute("/api/public/stripe-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.STRIPE_WEBHOOK_SECRET;
        const apiKey = process.env.STRIPE_SECRET_KEY;
        if (!secret || !apiKey) {
          return new Response("Stripe webhook not configured", { status: 500 });
        }
        const signature = request.headers.get("stripe-signature");
        if (!signature) {
          return new Response("Missing signature", { status: 400 });
        }
        const rawBody = await request.text();

        const StripeCtor = (await import("stripe")).default;
        const stripe = new StripeCtor(apiKey);

        let event: Stripe.Event;
        try {
          event = await stripe.webhooks.constructEventAsync(
            rawBody,
            signature,
            secret,
          );
        } catch (err) {
          console.error("Webhook signature verification failed", err);
          return new Response("Invalid signature", { status: 401 });
        }

        const { supabaseAdmin } = await import(
          "@/integrations/supabase/client.server"
        );

        try {
          switch (event.type) {
            case "checkout.session.completed": {
              const session = event.data.object as Stripe.Checkout.Session;
              await supabaseAdmin
                .from("transactions")
                .update({
                  status:
                    session.payment_status === "paid" ? "succeeded" : "pending",
                  stripe_payment_intent_id:
                    typeof session.payment_intent === "string"
                      ? session.payment_intent
                      : (session.payment_intent?.id ?? null),
                })
                .eq("stripe_checkout_session_id", session.id);
              break;
            }
            case "checkout.session.expired":
            case "checkout.session.async_payment_failed": {
              const session = event.data.object as Stripe.Checkout.Session;
              await supabaseAdmin
                .from("transactions")
                .update({ status: "failed" })
                .eq("stripe_checkout_session_id", session.id);
              break;
            }
            case "payment_intent.succeeded": {
              const pi = event.data.object as Stripe.PaymentIntent;
              await supabaseAdmin
                .from("transactions")
                .update({
                  status: "succeeded",
                  stripe_payment_intent_id: pi.id,
                })
                .eq("stripe_payment_intent_id", pi.id);
              break;
            }
            case "payment_intent.payment_failed": {
              const pi = event.data.object as Stripe.PaymentIntent;
              await supabaseAdmin
                .from("transactions")
                .update({ status: "failed" })
                .eq("stripe_payment_intent_id", pi.id);
              break;
            }
            case "charge.refunded": {
              const charge = event.data.object as Stripe.Charge;
              const piId =
                typeof charge.payment_intent === "string"
                  ? charge.payment_intent
                  : charge.payment_intent?.id;
              if (piId) {
                await supabaseAdmin
                  .from("transactions")
                  .update({ status: "refunded" })
                  .eq("stripe_payment_intent_id", piId);
              }
              break;
            }
            case "account.updated": {
              const account = event.data.object as Stripe.Account;
              await supabaseAdmin
                .from("profiles")
                .update({
                  stripe_charges_enabled: account.charges_enabled,
                  stripe_payouts_enabled: account.payouts_enabled,
                  stripe_details_submitted: account.details_submitted,
                })
                .eq("stripe_account_id", account.id);
              break;
            }
            default:
              break;
          }
        } catch (err) {
          console.error("Webhook handler error", event.type, err);
          return new Response("Handler error", { status: 500 });
        }

        return Response.json({ received: true });
      },
    },
  },
});
