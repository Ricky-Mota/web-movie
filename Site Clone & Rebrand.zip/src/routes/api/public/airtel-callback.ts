import { createFileRoute } from "@tanstack/react-router";

/**
 * Webhook public Airtel Money.
 *
 * Sécurité :
 *  - Le marchand doit configurer `callback_secret` côté ZbossPay ET côté Airtel.
 *  - Airtel doit envoyer la signature HMAC-SHA256 (hex) du corps brut dans
 *    l'en-tête `X-Auth-Signature` (compatible avec la doc Airtel "x-signature").
 *  - On retrouve le marchand via la référence externe `ZBP-...` stockée à l'init.
 */
export const Route = createFileRoute("/api/public/airtel-callback")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, {
          status: 204,
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, X-Auth-Signature, x-signature",
          },
        }),

      POST: async ({ request }) => {
        const rawBody = await request.text();
        const signature =
          request.headers.get("x-auth-signature") ??
          request.headers.get("x-signature") ??
          "";

        let payload: Record<string, unknown>;
        try {
          payload = JSON.parse(rawBody);
        } catch {
          return new Response(JSON.stringify({ error: "invalid_json" }), {
            status: 400,
            headers: { "Content-Type": "application/json" },
          });
        }

        const tx = (payload.transaction ?? payload) as {
          id?: string;
          reference?: string;
          status_code?: string;
          status?: string;
          message?: string;
          airtel_money_id?: string;
        };
        const externalRef =
          (typeof tx.id === "string" && tx.id) ||
          (typeof tx.reference === "string" && tx.reference) ||
          null;

        if (!externalRef) {
          return new Response(JSON.stringify({ error: "missing_reference" }), {
            status: 400,
            headers: { "Content-Type": "application/json" },
          });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: row, error } = await supabaseAdmin
          .from("provider_transactions")
          .select("id, merchant_id, provider_id")
          .eq("external_reference", externalRef)
          .maybeSingle();
        if (error || !row) {
          console.error("[airtel-callback] ref not found", externalRef, error?.message);
          return new Response(JSON.stringify({ error: "unknown_reference" }), {
            status: 404,
            headers: { "Content-Type": "application/json" },
          });
        }

        // Charger le secret du marchand pour vérifier la signature
        const { data: conn } = await supabaseAdmin
          .from("merchant_provider_connections")
          .select("credentials")
          .eq("merchant_id", row.merchant_id)
          .eq("provider_id", row.provider_id)
          .maybeSingle();
        const secret =
          ((conn?.credentials ?? {}) as Record<string, string>).callback_secret ?? "";

        const { verifyWebhookSignature } = await import("@/lib/airtel.server");
        const valid = await verifyWebhookSignature(secret, rawBody, signature);
        if (!valid) {
          console.warn("[airtel-callback] invalid signature for", externalRef);
          return new Response(JSON.stringify({ error: "invalid_signature" }), {
            status: 401,
            headers: { "Content-Type": "application/json" },
          });
        }

        const raw = (tx.status_code ?? tx.status ?? "").toString().toUpperCase();
        const status: "succeeded" | "failed" | "cancelled" | "processing" | "pending" =
          raw === "TS" || raw === "SUCCESS" || raw === "SUCCESSFUL" ? "succeeded"
          : raw === "TF" || raw === "FAILED" ? "failed"
          : raw === "TA" || raw === "CANCELLED" || raw === "EXPIRED" ? "cancelled"
          : raw === "IN_PROGRESS" || raw === "PROCESSING" ? "processing"
          : "pending";

        await supabaseAdmin
          .from("provider_transactions")
          .update({
            status,
            provider_reference: tx.airtel_money_id ?? undefined,
            last_message: (tx.message ?? raw).slice(0, 500),
            provider_payload: payload as never,
          })
          .eq("id", row.id);

        return new Response(JSON.stringify({ ok: true }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
