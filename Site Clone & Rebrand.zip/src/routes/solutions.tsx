import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "../components/site/Layout";
import { Code2, LayoutDashboard, Smartphone } from "lucide-react";
import ogImage from "../assets/og-solutions.jpg";

export const Route = createFileRoute("/solutions")({
  head: () => ({
    meta: [
      { title: "Solutions ZbossPay — API, Portail Web, Mobile" },
      { name: "description", content: "Trois façons d'intégrer ZbossPay : API publique pour développeurs, portail web pour entreprises, application mobile pour particuliers." },
      { property: "og:title", content: "Solutions ZbossPay" },
      { property: "og:description", content: "Trois façons d'intégrer ZbossPay : API publique pour développeurs, portail web pour entreprises, application mobile pour particuliers." },
      { property: "og:url", content: "/solutions" },
      { property: "og:image", content: ogImage },
      { property: "og:image:width", content: "1216" },
      { property: "og:image:height", content: "640" },
      { property: "og:image:alt", content: "Solutions ZbossPay — API, Portail Web, Mobile" },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: "/solutions" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Service",
        serviceType: "Plateforme de paiement",
        name: "Solutions ZbossPay",
        url: "/solutions",
        image: ogImage,
        provider: { "@type": "Organization", name: "ZbossPay" },
        areaServed: { "@type": "Country", name: "Congo, République démocratique du" },
        hasOfferCatalog: {
          "@type": "OfferCatalog",
          name: "Solutions d'intégration",
          itemListElement: [
            { "@type": "Offer", itemOffered: { "@type": "Service", name: "API publique" } },
            { "@type": "Offer", itemOffered: { "@type": "Service", name: "Portail Web" } },
            { "@type": "Offer", itemOffered: { "@type": "Service", name: "Application mobile" } },
          ],
        },
      }),
    }],
  }),
  component: SolutionsPage,
});

const blocks = [
  {
    icon: Code2,
    tag: "Développeurs & Intégration",
    title: "API ZbossPay — Puissante & simple à intégrer",
    text: "Notre API REST documentée vous permet d'intégrer les paiements mobile money dans n'importe quelle application en quelques heures.",
    bullets: [
      "Endpoints sécurisés HTTPS — OAuth 2.0, JWT, TLS 1.3",
      "Documentation exhaustive en ligne",
      "Webhooks en temps réel",
      "Sandbox de test disponible",
      "Transactions C2B & B2C unifiées",
    ],
  },
  {
    icon: LayoutDashboard,
    tag: "Équipes & Entreprises",
    title: "Portail Web — Gérez tout depuis votre navigateur",
    text: "Votre centre de contrôle pour gérer paiements, bulks, rapports et équipes — sans aucun code requis.",
    bullets: [
      "Tableau de bord analytique",
      "Paiements en masse (Bulk B2C)",
      "Gestion des transactions",
      "Rapports & exports comptables",
      "Gestion multi-utilisateurs",
    ],
  },
  {
    icon: Smartphone,
    tag: "Particuliers & Marchands",
    title: "Application Mobile — Payez & encaissez partout",
    text: "Payez, encaissez et gérez vos transactions depuis votre téléphone — avec ou sans internet via *5111#.",
    bullets: [
      "Paiements instantanés multi-opérateurs",
      "Gestion de compte complète",
      "Notifications push en temps réel",
      "Historique & reçus digitaux",
      "Fonctionne via USSD *5111#",
    ],
  },
];

function SolutionsPage() {
  return (
    <SiteLayout>
      <section className="gradient-brand text-white">
        <div className="container-page py-16">
          <span className="chip bg-white/15 text-white border-white/20">Nos solutions</span>
          <h1 className="mt-4 text-4xl md:text-5xl font-bold max-w-3xl">
            Trois façons d'intégrer ZbossPay à votre activité.
          </h1>
          <p className="mt-4 text-white/90 max-w-2xl">
            API publique, portail web et application mobile — choisissez le canal qui correspond à votre métier.
          </p>
        </div>
      </section>

      <section className="container-page py-16 space-y-10">
        {blocks.map((b, i) => (
          <div key={b.title} className={`grid lg:grid-cols-2 gap-8 items-center ${i % 2 ? "lg:[direction:rtl]" : ""}`}>
            <div className="[direction:ltr]">
              <span className="chip">{b.tag}</span>
              <h2 className="mt-3 text-2xl md:text-3xl font-bold">{b.title}</h2>
              <p className="mt-3 text-muted-foreground">{b.text}</p>
              <ul className="mt-5 space-y-2 text-sm">
                {b.bullets.map((x) => <li key={x}>• {x}</li>)}
              </ul>
              <Link to="/contact" className="inline-block mt-6 rounded-full gradient-brand text-white px-6 py-3 font-semibold">
                Demander une démo
              </Link>
            </div>
            <div className="[direction:ltr] rounded-3xl border bg-card p-8 grid place-items-center aspect-[4/3]">
              <b.icon size={120} className="text-[var(--cta)] opacity-80" />
            </div>
          </div>
        ))}
      </section>
    </SiteLayout>
  );
}
