import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { SiteLayout } from "../components/site/Layout";

type Search = { type?: "password" | "phone" };

export const Route = createFileRoute("/reset-confirmed")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    type: s.type === "phone" ? "phone" : "password",
  }),
  head: () => ({
    meta: [
      { title: "Réinitialisation confirmée — ZbossPay" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetConfirmedPage,
});

function ResetConfirmedPage() {
  const { type } = useSearch({ from: "/reset-confirmed" });
  const isPhone = type === "phone";
  return (
    <SiteLayout>
      <section className="container-page py-20 max-w-md">
        <div className="rounded-2xl border bg-card p-8 text-center">
          <div className="mx-auto h-14 w-14 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-3xl">
            ✓
          </div>
          <h1 className="text-2xl font-bold mt-5">
            {isPhone ? "Numéro mis à jour" : "Mot de passe mis à jour"}
          </h1>
          <p className="text-sm text-muted-foreground mt-2">
            {isPhone
              ? "Votre nouveau numéro de téléphone est désormais actif sur votre compte ZbossPay."
              : "Votre nouveau mot de passe est actif. Vous pouvez vous connecter dès maintenant."}
          </p>
          <Link
            to={isPhone ? "/dashboard" : "/login"}
            className="mt-6 inline-block rounded-full gradient-brand text-white px-6 py-3 font-semibold"
          >
            {isPhone ? "Retour au tableau de bord" : "Se connecter"}
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
