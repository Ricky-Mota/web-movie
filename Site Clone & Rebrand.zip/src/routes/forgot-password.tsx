import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "../components/site/Layout";
import { supabase } from "@/integrations/supabase/client";

const COOLDOWN_SECONDS = 60;
const COOLDOWN_KEY = "zbosspay_forgot_password_cooldown";

function getRemainingCooldown(): number {
  const stored = typeof window !== "undefined" ? localStorage.getItem(COOLDOWN_KEY) : null;
  if (!stored) return 0;
  const expiresAt = parseInt(stored, 10);
  if (Number.isNaN(expiresAt)) return 0;
  return Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000));
}

function startCooldown(): number {
  const expiresAt = Date.now() + COOLDOWN_SECONDS * 1000;
  localStorage.setItem(COOLDOWN_KEY, String(expiresAt));
  return COOLDOWN_SECONDS;
}

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Mot de passe oublié — ZbossPay" },
      { name: "description", content: "Recevez un lien à usage unique pour réinitialiser votre mot de passe ZbossPay." },
      { name: "robots", content: "noindex" },
    ],
    links: [{ rel: "canonical", href: "/forgot-password" }],
  }),
  component: ForgotPasswordPage,
});

function ForgotPasswordPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cooldownLeft, setCooldownLeft] = useState(0);

  useEffect(() => {
    setCooldownLeft(getRemainingCooldown());
    const timer = setInterval(() => {
      setCooldownLeft(getRemainingCooldown());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cooldownLeft > 0) return;

    setLoading(true);
    setError(null);
    try {
      const { error: e2 } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (e2) throw e2;
      setSent(true);
      setCooldownLeft(startCooldown());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur");
    } finally {
      setLoading(false);
    }
  };

  const isDisabled = loading || cooldownLeft > 0;

  return (
    <SiteLayout>
      <section className="container-page py-16 max-w-md">
        <div className="rounded-2xl border bg-card p-7">
          <h1 className="text-2xl font-bold">Mot de passe oublié</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Saisissez votre email — vous recevrez un lien à usage unique pour réinitialiser votre mot de passe.
          </p>

          {sent ? (
            <div className="mt-6 space-y-4">
              <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-sm text-green-800">
                ✉️ Lien envoyé à <strong>{email}</strong>. Vérifiez votre boîte de réception (et vos spams).
                Le lien expire dans 1 heure et ne fonctionne qu'une seule fois.
              </div>
              {cooldownLeft > 0 && (
                <p className="text-xs text-center text-muted-foreground">
                  Vous pourrez renvoyer un lien dans {cooldownLeft} seconde{cooldownLeft > 1 ? "s" : ""}.
                </p>
              )}
              <button
                type="button"
                onClick={() => router.navigate({ to: "/login" })}
                className="w-full rounded-full border px-6 py-3 font-semibold hover:bg-muted"
              >
                Retour à la connexion
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="grid gap-4 mt-6">
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Email</span>
                <input
                  required
                  type="email"
                  autoFocus
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="rounded-lg border px-3 py-2.5 bg-background"
                />
              </label>
              <button
                disabled={isDisabled}
                className="rounded-full gradient-brand text-white px-6 py-3 font-semibold disabled:opacity-60"
              >
                {loading ? "Envoi…" : cooldownLeft > 0 ? `Attendez ${cooldownLeft}s` : "Envoyer le lien"}
              </button>
              {error && <p className="text-sm text-red-600 text-center">{error}</p>}
              <Link to="/login" className="text-xs text-center text-muted-foreground underline">
                ← Retour à la connexion
              </Link>
            </form>
          )}
        </div>
      </section>
    </SiteLayout>
  );
}

