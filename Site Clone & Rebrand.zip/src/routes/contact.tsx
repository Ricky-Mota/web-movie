import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "../components/site/Layout";
import { Mail, Phone, MapPin, Loader2, Send } from "lucide-react";
import { useState } from "react";
import { sendContactMessage } from "@/lib/contact.functions";
import { APP_EMAIL } from "@/lib/site-config";
import ogImage from "../assets/og-contact.jpg";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — ZbossPay" },
      { name: "description", content: "Contactez l'équipe ZbossPay pour démarrer votre intégration de paiement mobile en RDC." },
      { property: "og:title", content: "Contact ZbossPay" },
      { property: "og:description", content: "Contactez l'équipe ZbossPay pour démarrer votre intégration de paiement mobile en RDC." },
      { property: "og:url", content: "/contact" },
      { property: "og:image", content: ogImage },
      { property: "og:image:width", content: "1216" },
      { property: "og:image:height", content: "640" },
      { property: "og:image:alt", content: "Contactez ZbossPay" },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "ContactPage",
        name: "Contact ZbossPay",
        url: "/contact",
        mainEntity: {
          "@type": "Organization",
          name: "ZbossPay",
          email: APP_EMAIL,
          telephone: "*5111#",
          address: { "@type": "PostalAddress", addressLocality: "Kinshasa", addressCountry: "CD" },
        },
      }),
    }],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", company: "", message: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    try {
      await sendContactMessage({ data: form });
      setSent(true);
      setForm({ name: "", email: "", company: "", message: "" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Une erreur est survenue.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <SiteLayout>
      <section className="gradient-brand text-white">
        <div className="container-page py-16">
          <span className="chip bg-white/15 text-white border-white/20">Contact</span>
          <h1 className="mt-4 text-4xl md:text-5xl font-bold">Parlons de votre projet</h1>
          <p className="mt-4 text-white/90 max-w-xl">Notre équipe vous répond sous 4 heures ouvrées.</p>
        </div>
      </section>

      <section className="container-page py-14 grid lg:grid-cols-3 gap-8">
        <div className="space-y-5">
          <a href="tel:*5111#" className="rounded-2xl border bg-card p-5 flex gap-3 hover:border-[var(--brand)] hover:shadow-md transition">
            <Phone className="text-[var(--brand)]" />
            <div>
              <div className="font-semibold">USSD</div>
              <div className="text-sm text-muted-foreground">*5111#</div>
            </div>
          </a>
          <a href={`mailto:${APP_EMAIL}`} className="rounded-2xl border bg-card p-5 flex gap-3 hover:border-[var(--brand)] hover:shadow-md transition">
            <Mail className="text-[var(--brand)]" />
            <div>
              <div className="font-semibold">Email</div>
              <div className="text-sm text-muted-foreground">{APP_EMAIL}</div>
            </div>
          </a>
          <a href="https://maps.google.com/?q=Kinshasa+RDC" target="_blank" rel="noreferrer" className="rounded-2xl border bg-card p-5 flex gap-3 hover:border-[var(--brand)] hover:shadow-md transition">
            <MapPin className="text-[var(--brand)]" />
            <div>
              <div className="font-semibold">Adresse</div>
              <div className="text-sm text-muted-foreground">Kinshasa, RDC</div>
            </div>
          </a>
        </div>

        <form
          onSubmit={handleSubmit}
          className="lg:col-span-2 rounded-2xl border bg-card p-7 grid gap-4"
        >
          <div className="grid md:grid-cols-2 gap-4">
            <label className="grid gap-1.5 text-sm">
              <span className="font-medium">Nom complet</span>
              <input
                required
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                className="rounded-lg border px-3 py-2.5 bg-background"
                placeholder="Votre nom"
              />
            </label>
            <label className="grid gap-1.5 text-sm">
              <span className="font-medium">Email</span>
              <input
                required
                type="email"
                value={form.email}
                onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                className="rounded-lg border px-3 py-2.5 bg-background"
                placeholder="vous@entreprise.cd"
              />
            </label>
          </div>
          <label className="grid gap-1.5 text-sm">
            <span className="font-medium">Entreprise</span>
            <input
              value={form.company}
              onChange={(e) => setForm((f) => ({ ...f, company: e.target.value }))}
              className="rounded-lg border px-3 py-2.5 bg-background"
              placeholder="Nom de votre société"
            />
          </label>
          <label className="grid gap-1.5 text-sm">
            <span className="font-medium">Message</span>
            <textarea
              required
              rows={5}
              value={form.message}
              onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
              className="rounded-lg border px-3 py-2.5 bg-background"
              placeholder="Parlez-nous de votre besoin..."
            />
          </label>
          <button
            disabled={isSubmitting}
            className="justify-self-start rounded-full gradient-brand text-white px-6 py-3 font-semibold inline-flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Envoi en cours...
              </>
            ) : (
              <>
                <Send className="h-4 w-4" />
                Envoyer le message
              </>
            )}
          </button>
          {sent && (
            <p className="text-sm text-green-600">
              Merci ! Votre message a été envoyé à {APP_EMAIL}. Nous vous recontactons sous 4 h ouvrées.
            </p>
          )}
          {error && <p className="text-sm text-red-600">{error}</p>}
        </form>
      </section>
    </SiteLayout>
  );
}
