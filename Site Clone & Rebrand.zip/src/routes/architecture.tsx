import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { Database, Shuffle, ShieldCheck, Webhook, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/architecture")({
  head: () => ({
    meta: [
      { title: "Architecture technique — ZbossPay" },
      {
        name: "description",
        content:
          "Architecture générale de la passerelle ZbossPay : Core API, moteur de change CDF↔USD, routage mobile money, webhooks HMAC-SHA256.",
      },
      { property: "og:title", content: "Architecture technique ZbossPay" },
      { property: "og:description", content: "Diagramme, schéma SQL et sécurité de la passerelle." },
    ],
    links: [{ rel: "canonical", href: "/architecture" }],
  }),
  component: ArchitecturePage,
});

const SQL = `CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Marchands
CREATE TABLE merchants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_name VARCHAR(150) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  phone VARCHAR(20) NOT NULL,
  kyc_status VARCHAR(20) DEFAULT 'PENDING'
    CHECK (kyc_status IN ('PENDING','APPROVED','REJECTED')),
  api_key_test VARCHAR(64) UNIQUE NOT NULL,
  api_key_live VARCHAR(64) UNIQUE NOT NULL,
  webhook_secret VARCHAR(64) NOT NULL,
  webhook_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. Historique des taux de change
CREATE TABLE exchange_rates (
  id SERIAL PRIMARY KEY,
  from_currency VARCHAR(3) NOT NULL,
  to_currency   VARCHAR(3) NOT NULL,
  base_rate     NUMERIC(12,6) NOT NULL,
  applied_rate  NUMERIC(12,6) NOT NULL,
  provider      VARCHAR(50)   DEFAULT 'EXCHANGE_RATE_API',
  updated_at    TIMESTAMPTZ   DEFAULT now()
);

-- 3. Transactions
CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  merchant_id UUID NOT NULL REFERENCES merchants(id) ON DELETE RESTRICT,
  original_amount NUMERIC(10,2) NOT NULL,
  original_currency VARCHAR(3) NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  currency VARCHAR(3) NOT NULL,
  exchange_rate_applied NUMERIC(12,6),
  operator VARCHAR(30) NOT NULL,
  customer_phone VARCHAR(20),
  status VARCHAR(20) DEFAULT 'PENDING'
    CHECK (status IN ('PENDING','SUCCESS','FAILED','EXPIRED')),
  merchant_reference VARCHAR(100) NOT NULL,
  operator_reference VARCHAR(100),
  fees NUMERIC(10,2) DEFAULT 0.00,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX idx_transactions_merchant ON transactions(merchant_id);`;

function ArchitecturePage() {
  return (
    <SiteLayout>
      <section className="gradient-brand text-white">
        <div className="container-page py-16">
          <span className="chip bg-white/15 text-white border-white/20">Documentation technique</span>
          <h1 className="mt-4 text-4xl md:text-5xl font-bold">Architecture générale</h1>
          <p className="mt-4 text-white/90 max-w-2xl">
            Vue d'ensemble de la passerelle ZbossPay : Core API, moteur de change CDF↔USD,
            routage mobile money & carte, et sécurité active par HMAC-SHA256.
          </p>
        </div>
      </section>

      {/* Diagramme */}
      <section className="container-page py-14">
        <h2 className="text-2xl font-bold">Diagramme de flux</h2>
        <div className="mt-6 rounded-2xl border bg-card p-6 overflow-x-auto">
          <div className="flex items-stretch gap-3 min-w-[900px] text-sm">
            <Block title="Portail client" sub="Widget HTML" />
            <Arrow label="HTTP POST /initiate" />
            <Block title="Core API" sub="TanStack Start" highlight />
            <Arrow label="Montant + devise" />
            <Block title="Currency Engine" sub="Spread 2% · cache 1h" />
            <Arrow label="Montant USD" />
            <Block title="Routage" sub="M-Pesa · Orange · Stripe" />
          </div>
          <div className="mt-4 flex items-stretch gap-3 min-w-[900px] text-sm">
            <Block title="PostgreSQL" sub="merchants · tx · rates" />
            <Arrow label="Validation opérateur" />
            <Block title="Webhook Issuer" sub="HMAC-SHA256 signé" highlight />
            <Arrow label="Notification signée" />
            <Block title="Serveur marchand" sub="Vérif. signature" />
          </div>
        </div>
      </section>

      {/* Piliers */}
      <section className="container-page py-14 grid md:grid-cols-2 gap-6">
        <Pillar
          icon={<Database className="text-[var(--cta)]" />}
          title="Cœur de données (PostgreSQL)"
          body="UUID pour la sécurité, NUMERIC pour la conformité financière, intégrité référentielle stricte entre marchands, taux et transactions."
        />
        <Pillar
          icon={<Shuffle className="text-[var(--cta)]" />}
          title="Moteur de change (DCC)"
          body="Marge de sécurité de 2% appliquée au taux CDF↔USD, cache horaire en base pour absorber la volatilité et limiter les appels externes."
        />
        <Pillar
          icon={<Webhook className="text-[var(--cta)]" />}
          title="Webhooks signés HMAC-SHA256"
          body="Chaque notification sortante est signée. Le marchand vérifie la signature côté serveur et rejette les rejeux (fenêtre de 5 minutes)."
        />
        <Pillar
          icon={<ShieldCheck className="text-[var(--cta)]" />}
          title="Sécurité active"
          body="Séparation clés test/live, secret webhook par marchand, comparaison en temps constant (timingSafeEqual), aucune donnée sensible en clair côté client."
        />
      </section>

      {/* SQL */}
      <section className="container-page py-14">
        <h2 className="text-2xl font-bold">Schéma SQL global</h2>
        <p className="mt-2 text-muted-foreground">
          Script d'initialisation des tables principales avec intégrité référentielle stricte.
        </p>
        <pre className="mt-6 rounded-xl border bg-neutral-950 text-neutral-100 p-6 overflow-x-auto text-xs leading-relaxed">
{SQL}
        </pre>
      </section>
    </SiteLayout>
  );
}

function Block({ title, sub, highlight }: { title: string; sub: string; highlight?: boolean }) {
  return (
    <div
      className={`flex-1 rounded-xl border p-4 ${
        highlight ? "gradient-brand text-white border-transparent" : "bg-background"
      }`}
    >
      <div className="font-semibold">{title}</div>
      <div className={`text-xs mt-1 ${highlight ? "text-white/80" : "text-muted-foreground"}`}>{sub}</div>
    </div>
  );
}

function Arrow({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center justify-center px-1 text-[10px] text-muted-foreground w-24 text-center">
      <ArrowRight size={20} />
      <span className="mt-1">{label}</span>
    </div>
  );
}

function Pillar({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <article className="rounded-2xl border bg-card p-6">
      <div className="flex items-center gap-2">{icon}<h3 className="font-bold">{title}</h3></div>
      <p className="mt-2 text-sm text-muted-foreground">{body}</p>
    </article>
  );
}
