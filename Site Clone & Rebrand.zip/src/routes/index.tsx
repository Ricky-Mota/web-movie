import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "../components/site/Layout";
import {
  Zap, Shield, Headphones, BadgePercent, Code2, BarChart3,
  ArrowRight, Check, Smartphone, Users, Repeat, Globe, Sparkles, ChevronLeft, ChevronRight
} from "lucide-react";
import heroImg from "../assets/hero.jpg";
import hero2Asset from "../assets/hero-2.jpg.asset.json";
import hero3Asset from "../assets/hero-3.jpg.asset.json";
import hero4Asset from "../assets/hero-4.jpg.asset.json";
import ogImage from "../assets/og-home.jpg";

type AssetPointer = { url: string };


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ZbossPay — Paiement mobile en RDC" },
      { name: "description", content: "La plateforme de paiement mobile la plus simple et sécurisée de RDC. Orange, Airtel, M-Pesa, Afrimoney et carte." },
      { property: "og:title", content: "ZbossPay — Paiement mobile en RDC" },
      { property: "og:description", content: "La plateforme de paiement mobile la plus simple et sécurisée de RDC. Orange, Airtel, M-Pesa, Afrimoney et carte." },
      { property: "og:url", content: "/" },
      { property: "og:image", content: ogImage },
      { property: "og:image:width", content: "1216" },
      { property: "og:image:height", content: "640" },
      { property: "og:image:alt", content: "ZbossPay — Paiement mobile en RDC" },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});

const slides = [
  {
    tag: "Merchant B2C · Encaissement Client",
    title: "Encaissez vos clients en un seul tap",
    desc: "Acceptez les paiements directement sur votre compte ZbossPay — Orange, Airtel, M-Pesa, Afrimoney ou carte bancaire, instantanément.",
    primary: "Démarrer l'encaissement",
    icon: Smartphone,
    image: heroImg,
    imageAlt: "Cliente ZbossPay heureuse de recevoir un paiement mobile",
  },
  {
    tag: "Bulk · Paiements en masse · Entreprises",
    title: "Disbursez des salaires en une opération",
    desc: "Envoyez des paiements groupés — salaires, commissions, remboursements — vers des centaines de bénéficiaires en quelques secondes.",
    primary: "Paiement en masse",
    icon: Users,
    image: (hero2Asset as AssetPointer).url,
    imageAlt: "Femme d'affaires utilisant ZbossPay pour payer des salaires",
  },
  {
    tag: "Polices · Assurance · Cotisations",
    title: "Collectez vos cotisations automatiquement",
    desc: "Gérez les paiements de polices, abonnements et cotisations périodiques via mobile money — automatisé, fiable et traçable.",
    primary: "Commencer maintenant",
    icon: Repeat,
    image: (hero3Asset as AssetPointer).url,
    imageAlt: "Homme payant une cotisation avec ZbossPay devant un bureau d'assurance",
  },
  {
    tag: "USSD *5111# · Sans Internet · Partout en RDC",
    title: "Payez partout, même sans internet",
    desc: "La première plate-forme de paiement mobile accessible sur tout le territoire via le code *5111#.",
    primary: "Composer *5111#",
    icon: Globe,
    image: (hero4Asset as AssetPointer).url,
    imageAlt: "Femme au marché utilisant le code USSD ZbossPay sur son téléphone",
  },
];

const features = [
  { icon: Zap, title: "Paiements rapides", text: "Encaissez et payez en moins de 3 secondes — sans friction.", tag: "≈ 3 s" },
  { icon: Shield, title: "Sécurité avancée", text: "Chiffrement bout en bout, 2FA et surveillance temps réel.", tag: "AES-256" },
  { icon: Headphones, title: "Support 24/7", text: "Une équipe dédiée, par téléphone, chat ou email.", tag: "*5111#" },
  { icon: BadgePercent, title: "Frais transparents", text: "Pas de frais cachés. Vous savez exactement ce que vous payez.", tag: "0 frais cachés" },
  { icon: Code2, title: "Intégration facile", text: "API REST documentée — branchez ZbossPay en quelques heures.", tag: "REST API" },
  { icon: BarChart3, title: "Tableau de bord", text: "Suivez transactions, rapports et KPIs en un seul espace.", tag: "Analytics" },
];

const partners = ["Orange Money", "Airtel Money", "M-Pesa", "Afrimoney", "Visa", "Mastercard", "ZbossPay USSD"];

function HomePage() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % slides.length), 9000);
    return () => clearInterval(t);
  }, []);
  const s = slides[i];
  const Icon = s.icon;
  const words = s.title.split(" ");
  const head = words.slice(0, -2).join(" ");
  const tail = words.slice(-2).join(" ");

  return (
    <SiteLayout>
      {/* HERO ROTATIF */}
      <section className="relative overflow-hidden gradient-hero text-white">
        <div className="container-page grid lg:grid-cols-2 gap-10 py-16 lg:py-24 items-center">
          <div key={i} className="animate-fade-in">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 border border-white/20 px-3 py-1 text-xs font-medium backdrop-blur">
              <span className="h-2 w-2 rounded-full bg-[var(--cta)] animate-pulse" />
              {s.tag}
            </span>
            <h1 className="mt-5 text-4xl md:text-6xl font-bold leading-[1.05]">
              {head} <span className="text-shine">{tail}</span>
            </h1>
            <p className="mt-5 text-white/85 text-lg max-w-xl">{s.desc}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/login" className="rounded-full gradient-cta text-[var(--cta-foreground)] shadow-xl shadow-black/30 px-6 py-3 font-semibold inline-flex items-center gap-2 hover:scale-105 transition-transform">
                {s.primary} <ArrowRight size={18} />
              </Link>
              <Link to="/contact" className="rounded-full border border-white/30 px-6 py-3 font-semibold hover:bg-white/10 transition">
                Découvrir nos solutions
              </Link>
            </div>

            <div className="mt-10 flex items-center gap-4">
              <button onClick={() => setI((p) => (p - 1 + slides.length) % slides.length)} className="h-10 w-10 grid place-items-center rounded-full bg-white/10 hover:bg-white/20 transition" aria-label="Précédent">
                <ChevronLeft size={18} />
              </button>
              <div className="flex gap-2">
                {slides.map((_, k) => (
                  <button key={k} onClick={() => setI(k)} aria-label={`Slide ${k + 1}`}
                    className={`h-2 rounded-full transition-all ${k === i ? "w-8 bg-[var(--cta)]" : "w-2 bg-white/40"}`} />
                ))}
              </div>
              <button onClick={() => setI((p) => (p + 1) % slides.length)} className="h-10 w-10 grid place-items-center rounded-full bg-white/10 hover:bg-white/20 transition" aria-label="Suivant">
                <ChevronRight size={18} />
              </button>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-6 rounded-[2rem] bg-gradient-to-tr from-[var(--cta)]/30 to-white/10 blur-2xl" aria-hidden />
            {/* Carrousel crossfade + Ken Burns (zoom/pan lent) */}
            <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl ring-1 ring-white/15">
              {slides.map((sl, k) => (
                <img
                  key={k}
                  src={sl.image}
                  alt={sl.imageAlt}
                  width={1600}
                  height={1200}
                  loading={k === 0 ? "eager" : "lazy"}
                  className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-[2000ms] ease-in-out ${
                    k === i ? "opacity-100 animate-kenburns" : "opacity-0"
                  }`}
                />
              ))}
              <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent pointer-events-none" aria-hidden />
            </div>


            <div className="absolute -bottom-5 -left-5 bg-white text-[var(--ink)] rounded-2xl shadow-xl p-4 hidden md:block animate-float">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Sparkles size={14} className="text-[var(--cta)]" /> Transaction réussie
              </div>
              <div className="font-bold text-lg">+ 120 000 CDF</div>
              <div className="text-xs text-[var(--cta)]">Orange Money · 2 s</div>
            </div>
            <div className="absolute -top-4 -right-4 bg-white/95 text-[var(--ink)] rounded-2xl shadow-xl p-3 hidden md:flex items-center gap-2 backdrop-blur">
              <span className="h-9 w-9 grid place-items-center rounded-xl gradient-cta">
                <Icon size={18} className="text-[var(--cta-foreground)]" />
              </span>
              <div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Cas d'usage</div>
                <div className="text-sm font-semibold">{s.tag.split("·")[0].trim()}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Partner marquee */}
        <div className="border-t border-white/10 bg-black/20 py-4 overflow-hidden">
          <div className="flex gap-12 animate-marquee whitespace-nowrap">
            {[...partners, ...partners].map((p, k) => (
              <span key={k} className="text-white/70 text-sm font-semibold tracking-wide">● {p}</span>
            ))}
          </div>
        </div>
      </section>

      {/* STATS + POURQUOI */}
      <section className="container-page py-16">
        <div className="text-center max-w-2xl mx-auto">
          <span className="chip">● Fintech · RDC · Agrégateur de paiement</span>
          <h2 className="mt-4 text-3xl md:text-4xl font-bold">
            Pourquoi choisir <span className="text-[var(--cta)]">ZbossPay ?</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            La plateforme de paiement mobile la plus simple, sécurisée et complète de la République Démocratique du Congo.
          </p>
        </div>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            ["500 000+", "Transactions traitées"],
            ["98%", "Satisfaction client"],
            ["< 3 s", "Temps moyen / transaction"],
            ["24/7", "Support disponible"],
          ].map(([n, l]) => (
            <div key={l} className="rounded-2xl border bg-card p-6 text-center hover:-translate-y-1 hover:shadow-lg transition">
              <div className="text-3xl font-bold text-[var(--cta)]">{n}</div>
              <div className="text-sm text-muted-foreground mt-1">{l}</div>
            </div>
          ))}
        </div>

        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f, idx) => {
            const dest = (["/payments", "/about", "/contact", "/products", "/solutions", "/products"] as const)[idx] ?? "/products";
            return (
              <Link
                to={dest}
                key={f.title}
                className="group rounded-2xl border bg-card p-6 hover:shadow-xl hover:-translate-y-1 transition relative overflow-hidden block"
              >
                <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-[var(--cta)]/10 group-hover:scale-150 transition-transform" aria-hidden />
                <div className="relative h-11 w-11 rounded-xl gradient-brand text-white grid place-items-center">
                  <f.icon size={20} />
                </div>
                <h3 className="relative mt-4 font-semibold text-lg">{f.title}</h3>
                <p className="relative mt-2 text-sm text-muted-foreground">{f.text}</p>
                <div className="relative mt-4 flex items-center justify-between">
                  <span className="chip">{f.tag}</span>
                  <span className="text-sm font-semibold text-[var(--brand)] inline-flex items-center gap-1 group-hover:gap-2 transition-all">
                    Découvrir {f.title} <ArrowRight size={14} />
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* PRODUITS */}
      <section className="bg-[var(--muted)] py-16">
        <div className="container-page">
          <div className="flex items-end justify-between flex-wrap gap-4">
            <div>
              <span className="chip">Catalogue</span>
              <h2 className="mt-3 text-3xl md:text-4xl font-bold">Nos produits</h2>
            </div>
            <Link to="/products" className="text-[var(--cta)] font-semibold inline-flex items-center gap-1">
              Voir tout <ArrowRight size={16} />
            </Link>
          </div>
          <div className="mt-8 grid md:grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              { t: "Paiements en ligne", d: "Acceptez Orange, Airtel, M-Pesa, Afrimoney et carte.", tag: "Populaire" },
              { t: "Virements instantanés", d: "Envoyez vers tout numéro mobile en < 3 s.", tag: "Nouveau" },
              { t: "Solutions marchands", d: "Caisse virtuelle et gestion des commandes.", tag: "" },
              { t: "Tableau analytics", d: "Flux temps réel, exports CSV/PDF.", tag: "" },
            ].map((p) => (
              <div key={p.t} className="rounded-2xl bg-card border p-6 flex flex-col hover:-translate-y-1 hover:shadow-xl transition">
                {p.tag && <span className="self-start chip mb-3">{p.tag}</span>}
                <h3 className="font-semibold text-lg">{p.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground flex-1">{p.d}</p>
                <Link to="/products" className="mt-4 text-sm font-semibold text-[var(--cta)] inline-flex items-center gap-1 group">
                  Découvrir <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="container-page py-20">
        <div className="relative overflow-hidden rounded-3xl gradient-hero text-white p-10 md:p-14 flex flex-col md:flex-row gap-6 justify-between items-center">
          <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-[var(--cta)]/20 blur-3xl" aria-hidden />
          <div className="relative">
            <h2 className="text-3xl md:text-4xl font-bold max-w-xl">Prêt à accepter des paiements en 48 h ?</h2>
            <p className="mt-3 text-white/85">Une seule intégration. Tous les opérateurs RDC. Aucun frais d'installation.</p>
          </div>
          <Link to="/contact" className="relative rounded-full gradient-cta text-[var(--cta-foreground)] shadow-xl px-7 py-3 font-semibold inline-flex items-center gap-2 whitespace-nowrap hover:scale-105 transition-transform">
            <Check size={18} /> Démarrer maintenant
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
