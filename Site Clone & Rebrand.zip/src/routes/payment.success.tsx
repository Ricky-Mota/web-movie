import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { Check } from "lucide-react";

export const Route = createFileRoute("/payment/success")({
  head: () => ({
    meta: [{ title: "Paiement réussi — ZbossPay" }],
  }),
  component: SuccessPage,
});

function SuccessPage() {
  return (
    <SiteLayout>
      <section className="container-page py-20 max-w-lg text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-green-100 text-green-700">
          <Check size={32} />
        </div>
        <h1 className="mt-6 text-3xl font-bold">Paiement réussi</h1>
        <p className="mt-3 text-muted-foreground">
          Merci ! Votre paiement a bien été traité. Vous recevrez un reçu par
          email.
        </p>
        <Link
          to="/"
          className="inline-block mt-8 rounded-full gradient-brand text-white px-6 py-3 font-semibold"
        >
          Retour à l'accueil
        </Link>
      </section>
    </SiteLayout>
  );
}
