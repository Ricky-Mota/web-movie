import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "../components/site/Layout";
import { Check } from "lucide-react";
import ogImage from "../assets/og-products.jpg";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "Produits ZbossPay — Paiements, virements, marchands" },
      { name: "description", content: "Toutes les solutions ZbossPay : paiements en ligne, virements instantanés, espace marchand et tableau de bord analytics." },
      { property: "og:title", content: "Produits ZbossPay" },
      { property: "og:description", content: "Toutes les solutions ZbossPay : paiements en ligne, virements instantanés, espace marchand et tableau de bord analytics." },
      { property: "og:url", content: "/products" },
      { property: "og:image", content: ogImage },
      { property: "og:image:width", content: "1216" },
      { property: "og:image:height", content: "640" },
      { property: "og:image:alt", content: "Produits ZbossPay" },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: "/products" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "ItemList",
        name: "Produits ZbossPay",
        url: "/products",
        itemListElement: products.map((p, i) => ({
          "@type": "ListItem",
          position: i + 1,
          item: {
            "@type": "Product",
            name: p.title,
            description: p.desc,
            image: ogImage,
            brand: { "@type": "Brand", name: "ZbossPay" },
          },
        })),
      }),
    }],
  }),
  component: ProductsPage,
});

const products = [
  {
    title: "Paiements en ligne",
    badge: "Le plus populaire",
    desc: "Acceptez les paiements de vos clients en un instant. Une seule intégration, tous les opérateurs RDC.",
    bullets: ["Paiement en 3 secondes", "Orange · Airtel · M-Pesa · Afrimoney · Carte", "Confirmation en temps réel", "Reçus automatiques", "Remboursements simples"],
  },
  {
    title: "Virements instantanés",
    badge: "Nouveau",
    desc: "Envoyez de l'argent à tout numéro mobile ou compte ZbossPay en moins de 3 secondes, partout en RDC.",
    bullets: ["Instantané 24h/24", "Paiements groupés", "Traçabilité complète"],
  },
  {
    title: "Solutions marchands",
    badge: "",
    desc: "Encaissez vos clients, gérez vos commandes et automatisez vos flux depuis un espace marchand dédié.",
    bullets: ["Caisse virtuelle", "Gestion des commandes", "Multi-utilisateurs"],
  },
  {
    title: "Tableau de bord analytics",
    badge: "",
    desc: "Visualisez vos flux en temps réel, exportez vos rapports et pilotez votre activité depuis un dashboard intuitif.",
    bullets: ["Graphiques temps réel", "Export CSV / PDF", "Alertes intelligentes"],
  },
];

function ProductsPage() {
  return (
    <SiteLayout>
      <section className="gradient-brand text-white">
        <div className="container-page py-16">
          <span className="chip bg-white/15 text-white border-white/20">Catalogue · Solutions de paiement</span>
          <h1 className="mt-4 text-4xl md:text-5xl font-bold">Voici nos produits</h1>
          <p className="mt-4 text-white/90 max-w-2xl">
            Des solutions pensées pour chaque besoin — particuliers, commerçants et développeurs — toutes propulsées par l'infrastructure ZbossPay.
          </p>
        </div>
      </section>

      <section className="container-page py-16 grid md:grid-cols-2 gap-6">
        {products.map((p) => (
          <article key={p.title} className="rounded-2xl border bg-card p-7 flex flex-col">
            {p.badge && <span className="self-start chip mb-3">{p.badge}</span>}
            <h2 className="text-2xl font-bold">{p.title}</h2>
            <p className="mt-2 text-muted-foreground">{p.desc}</p>
            <ul className="mt-5 space-y-2 text-sm">
              {p.bullets.map((b) => (
                <li key={b} className="flex gap-2"><Check size={18} className="text-[var(--cta)] flex-none mt-0.5" />{b}</li>
              ))}
            </ul>
            <Link to="/contact" className="mt-6 self-start rounded-full gradient-brand text-white px-5 py-2.5 font-semibold">
              Découvrir ce produit
            </Link>
          </article>
        ))}
      </section>
    </SiteLayout>
  );
}
