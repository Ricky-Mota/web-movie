import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";
import { applySecurityHeaders, isLocalhost } from "./lib/security-headers";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!body.includes('"unhandled":true') || !body.includes('"message":"HTTPError"')) {
    return response;
  }

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

function wrapServerResponse(request: Request, response: Response): Response {
  if (isLocalhost(request.url)) {
    return response;
  }
  return applySecurityHeaders(response);
}

/**
 * Redirige systématiquement :
 *  - HTTP  -> HTTPS
 *  - zbosspay.cd (apex) -> www.zbosspay.cd (URL canonique)
 * Renvoie une Response 301 si une redirection est nécessaire, sinon null.
 */
function canonicalRedirect(request: Request): Response | null {
  const url = new URL(request.url);

  // Ne jamais rediriger localhost ni les previews Lovable
  if (
    url.hostname === "localhost" ||
    url.hostname === "127.0.0.1" ||
    url.hostname.endsWith(".lovable.app")
  ) {
    return null;
  }

  const forwardedProto = request.headers.get("x-forwarded-proto");
  const isHttps = url.protocol === "https:" || forwardedProto === "https";

  let targetHost = url.hostname;
  if (targetHost === "zbosspay.cd") {
    targetHost = "www.zbosspay.cd";
  }

  const needsHttps = !isHttps;
  const needsHostSwap = targetHost !== url.hostname;

  if (!needsHttps && !needsHostSwap) {
    return null;
  }

  const target = new URL(url.toString());
  target.protocol = "https:";
  target.hostname = targetHost;
  target.port = "";

  return new Response(null, {
    status: 301,
    headers: {
      Location: target.toString(),
      "Cache-Control": "public, max-age=3600",
    },
  });
}


export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const redirect = canonicalRedirect(request);
      if (redirect) return wrapServerResponse(request, redirect);

      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      const normalized = await normalizeCatastrophicSsrResponse(response);
      return wrapServerResponse(request, normalized);
    } catch (error) {
      console.error(error);
      return wrapServerResponse(
        request,
        new Response(renderErrorPage(), {
          status: 500,
          headers: { "content-type": "text/html; charset=utf-8" },
        }),
      );
    }
  },
};
